# KERN Foundation Specification v0.5

**Status:** normative design specification plus reference artifacts. The Zig and Lean source files are *not claimed to compile* unless the validation report explicitly says so.

## 1. Scope and non-goals

KERN is a project-state language and evidence engine. KERN-D describes facts, dependencies, contracts, task declarations and provenance. KERN-X is a separately sandboxed execution layer. A KERN manifest can organize evidence and demand checks; it cannot make incomplete evidence complete by declaration.

KERN does not promise that generated code is universally correct, that arbitrary project builds finish in a fixed wall-clock time, or that memory-mapping has zero physical cost. Claims about performance must be benchmarked on a declared workload and machine.

## 2. Four-valued evidence state (Belnap–Dunn FOUR)

Represent a scoped proposition by support bits `(p,n) ∈ {0,1}²`:

| State | Pair | Meaning |
|---|---|---|
| `N` | `(0,0)` | no admitted positive or negative support |
| `T` | `(1,0)` | positive support only |
| `F` | `(0,1)` | negative support only |
| `B` | `(1,1)` | both positive and negative support |

Canonical packed encoding: bit 0 is `p`, bit 1 is `n`: `N=0b00`, `T=0b01`, `F=0b10`, `B=0b11`.

### 2.1 Operators (do not overload one generic combine function)

- Knowledge join / evidence aggregation: `joinK(a,b)=(p_a OR p_b, n_a OR n_b)`.
- Knowledge meet: `meetK(a,b)=(p_a AND p_b, n_a AND n_b)`.
- Truth negation: `notB(a)=(n_a,p_a)`.
- Truth conjunction: `andT(a,b)=(p_a AND p_b, n_a OR n_b)`.
- Truth disjunction: `orT(a,b)=(p_a OR p_b, n_a AND n_b)`.

`joinK(T,F)=B`; `andT(T,F)=F`. These operations have different meanings. `B` is contradictory support, not a crash, timeout, invalid certificate, or generic system error.

### 2.2 Separate state axes

A claim record MUST NOT collapse these into a single enum:

1. `BelnapValue`: admitted positive/negative support for an exact proposition and scope.
2. `CoverageState`: `not_scanned`, `partial`, `scanned_no_evidence`, `scanned_with_evidence`, `complete_under_policy`.
3. `VerificationVerdict`: `not_run`, `proved`, `counterexample`, `sat_witness`, `unsat`, `unknown`, `timeout`, `invalid_certificate`, `tool_error`, `out_of_fuel`.
4. `Lifecycle`: `draft`, `queued`, `blocked`, `accepted`, `rejected`, `superseded`.
5. `ExecutionOutcome`: process/runtime result, kept separate from evidence truth.

Coverage means only that the named corpus and checks were processed under a named policy. It is not proof of global completeness.

## 3. Admission gate and the `e=1` rule

`e(claim)=1` is computed by the trusted policy gate; source syntax, user text, an LLM reply, an arbitrary witness string, or a user-set status cannot force it.

Minimum admission requirements are claim-class-specific and include:

- canonical proposition and exact scope;
- an explicit policy specifying accepted evidence classes;
- integrity-bound evidence and source coordinates;
- provenance complete enough for that policy;
- the required checker actually ran and returned the required verdict;
- the checker input hash matches the current claim/artifact/contract;
- required coverage is `complete_under_policy`;
- the positive support bit is present and the negative support bit absent (`T`);
- no unresolved contradiction relevant to the claim.

A test passing supports only the tested property under its inputs/environment. A formal proof establishes only the encoded theorem under the proof system's assumptions. `B` schedules contradiction resolution only when there are two identified, admissible, scope-compatible contributions; otherwise create a diagnostic to inspect malformed state.

## 4. Correct interpretation of SMT results

The meaning of `sat`/`unsat` depends on the exact query.

### 4.1 Preconditions

Query `Pre(x)`:
- `SAT` with a parsed, solver-produced model independently evaluated against the same formula establishes that the encoded `Pre` is satisfiable.
- `UNSAT` establishes that no model satisfies the encoded `Pre`, subject to solver/theory/encoding assumptions; it identifies a vacuous/unreachable contract under this query, not automatically a false business claim.
- `UNKNOWN` or timeout is inconclusive.

### 4.2 Partial-correctness counterexample search

Query `Pre(x) ∧ ¬Post(x, f(x))` only if `f` has a supported encoding or a sound abstraction:
- `SAT` plus a validated model is a counterexample to the encoded postcondition.
- `UNSAT` says no counterexample exists in the encoded model, subject to assumptions.
- `UNKNOWN`/timeout says no conclusion.

Never infer theorem validity from a string like `model_sat_witness...`. A witness must be parsed and checked against the exact formula and domain. A string-presence check is not a solver.

### 4.3 Anti-vacuity policy

KERN may require that `Pre` be satisfiable when a contract policy requires at least one admissible input. This is a *policy check*, not a universal law that all unreachable/precondition-false contracts are erroneous. A satisfiability witness is necessary for that policy but is not sufficient to prove `Post` or program correctness.

## 5. PC3: proof-carrying code completion

For a policy-enabled task, an AI-generated edit is staged as:

`Completion = (canonical_AST, contract, dependency_interface_hashes, certificate_ref, checker_policy_hash, producer_metadata)`.

The certificate MUST be cryptographically/content-addressably bound to the exact AST and contract. The trusted checker verifies a property under a named proof calculus or verification-condition pipeline. The staged edit is not published until checks pass.

PCC is an established research direction; KERN-specific contribution must be demonstrated by its integration, policy, incremental operation and evaluation, not by claiming to have invented PCC. See prior art register.

No universal `O(|AST|)` checker bound is claimed. Complexity is stated per certificate format/checker and measured/derived from the chosen calculus. When no sound certificate/checker is available, code can remain staged/untrusted; it MUST NOT be labelled proven. It is also acceptable to use a combination of type checks, memory-safety guarantees, tests and explicit partial contracts, but the result must accurately state what is and is not proven.

## 6. Project graph and provenance

Maintain distinct graph projections:

- `G_src`: source/module/symbol dependencies. Cycles are allowed and analyzed (e.g., via SCC decomposition).
- `G_build`: build tasks and order constraints. A cycle is an error unless a declared fixed-point/recursive build semantics handles it.
- `G_prov`: immutable derivation records and artifact versions.

A provenance derivation has immutable input-version IDs, a derivation rule/tool fingerprint, output-version IDs, and a monotonically ordered transaction/epoch. Acyclicity must be enforced by the versioned event model (each output references only committed prior versions), not inferred from bipartiteness alone.

Hyperedge model: `Derivation = (Inputs: finite set of typed version IDs, RuleID, ParametersHash, Outputs: finite set of version IDs)`. Evidence and claims are separate object types. A source graph may be cyclic while the historical derivation graph remains acyclic.

For recursive rules, define a finite fixed-point semantics explicitly. Negation is allowed only under declared stratified semantics or a specified non-monotone semantics. A negative dependency inside a recursive SCC MUST be rejected or explicitly marked unsupported; do not mislabel every evaluation error as a Belnap conflict.

## 7. Differential update and retraction semantics

Each evidence contribution is identified independently:

`EvidenceEvent(event_id, proposition_id, evidence_id, polarity, action, source_hash, scope_hash, epoch)`

where `action ∈ {add, retract}` and retract must target a specific active evidence contribution. Replayed event IDs are idempotent; an invalid/double retraction is a diagnostic.

Do not subtract `BelnapValue` directly: `joinK` is idempotent and has no general inverse. On update, remove/add the designated contributions, recompute positive and negative support from the active admissible evidence set, then propagate changes to derived nodes using the provenance graph/dataflow engine.

The target cost is output-sensitive, e.g. `O(affected nodes + affected edges + transfer cost)`, not a universal `O(|delta|)` bound. For recursive positive Datalog-like rules, use a documented fixed-point/differential engine. For non-monotone rules, require stratification or a documented incremental semantics. Cross-epoch publication must be atomic so readers do not see transient inconsistent partial results.

## 8. KERN-X bounded execution

KERN-D is declarative and intentionally does not expose general unbounded user recursion or arbitrary effectful code. Parsing finite input must make progress and terminate; every phase needs explicit size/depth/resource limits for malformed/hostile input.

KERN-X tasks use a *global consumed-work budget*, not a copied per-recursive-call counter. A task policy may include:

- instruction/fuel budget;
- arena bytes and allocation quota;
- output bytes;
- recursion/depth bound;
- host-call count and host-call fuel;
- wall-clock deadline/cancellation enforced by the host/process supervisor;
- filesystem/network capabilities.

Fuel exhaustion is `out_of_fuel`, not `B`. Fuel can bound interpreter work under a defined cost model; it cannot by itself guarantee wall-clock completion of arbitrary external calls or protect against OS scheduling delays. External solver calls need independent timeout/cancellation or process isolation.

## 9. `.kbin` and memory-mapped representation

`.kbin` is an immutable, versioned snapshot. Recommended design:

- canonical little-endian scalar encoding;
- fixed header and section directory with checked offsets/lengths;
- 64-bit file-relative offsets for large files, or explicit chunk IDs plus per-chunk offsets for segmented append-only storage;
- strings interned in a byte table with explicit length and offset;
- SoA/CSR arrays for hot scans, with optional AoS records for cold metadata;
- content digest and versioned schema IDs;
- safe readers using bounds-checked accessors before exposing typed views.

Do not cast untrusted mmap bytes directly to native Zig structs before validating byte order, alignment, size and all nested ranges. A memory map does not imply that all pages are resident, no page faults occur, no heap allocations occur elsewhere, or reads cost zero time.

64-byte cache-line alignment and HugeTLB/THP are optional target-specific optimizations, not format correctness assumptions. HugePages require OS/host support and may fail; fallback to normal mapping is mandatory. Publish snapshots by writing a new immutable file and atomically switching the manifest/filename, rather than mutating bytes under concurrent readers.

## 10. Cache and semantic slicing

A task-specific cache key MUST include all semantically relevant inputs:

`BLAKE3(protocol_version || task_kind || canonical_slice || relevant_body_hashes || contracts_hash || dependency_interface_hashes || model_fingerprint || prompt_template_hash || generation_params || tool_fingerprints || retrieval_config || schema_hash || policy_hash || checker_version)`.

Interface-only slicing is permitted only for a task whose contract declares that implementation bodies are irrelevant. Otherwise include body/behavior hashes. Comments and formatting may be excluded only if the task's normalization policy proves them irrelevant.

For cyclic module dependencies, compute strongly connected components and hash a canonical SCC representation plus the DAG of components. A cache hit reuses a prior computed result; it is not a new execution or proof. A result cannot be reused if the checker, model, instructions, retrieval evidence, contract policy, dependency API, or relevant body changed.

Use a cryptographic digest as the correctness key. Non-cryptographic secondary hashes may accelerate lookup but must not decide correctness. Do not claim zero collision probability.

## 11. Collections and language types

KERN-D distinguishes:

- `seq[T]`: ordered sequence; duplicates permitted;
- `set[T]`: unordered unique members;
- `map[K,V]`: functional mapping with at most one value per key;
- `rel[A,B]`: binary relation, a subset of `A × B`.

Operations are typed; a sequence is not silently treated as a mathematical set. Set/map order for serialization is canonicalized where deterministic builds require it.

## 12. Canonical project manifest

The canonical data store is the indexed set of immutable source artifacts plus normalized records and derivations. `PROJECT_CANONICAL_SPEC.kern.md` is a generated dual-view report, not an independent authority.

It contains:
- a human report in Markdown;
- machine blocks fenced as `kern` with manifest format version and source snapshot hash;
- a status/coverage table generated from catalog values;
- source links to exact artifacts/ranges and verification run IDs;
- conflicts, unknowns and policy gaps.

Human prose cannot override machine claims. Example names, synthetic evidence and demonstration values must be marked `SYNTHETIC` and cannot be admitted as evidence about a real repository. Never hardcode a coverage percentage like `99.4%` or statuses `T` in a template; compute them from actual runs and use the correct denominator.

## 13. Performance claims and measurement protocol

Do not assert by design alone:
- zero allocations across the whole engine;
- zero page faults or zero TLB misses;
- 32 facts processed in one CPU cycle;
- 100% branch prediction;
- sub-millisecond startup independent of file size;
- million-line rebuilds in a fixed time;
- universally linear proof checking;
- cost proportional only to changed source bytes.

Benchmark against baselines on declared data sizes and distributions. Record CPU/architecture, OS/kernel, memory, filesystem/cache state, Zig version, optimization mode, thread count, warm/cold state, dataset hash, operation count, wall time, CPU time, page faults, peak RSS, bytes read and allocations (where instrumented). Report median and spread across repetitions.

## 14. Acceptance criteria for this revision

Required conformance tests are in `KERN_CONFORMANCE_TEST_PLAN_v0.5.md`. Minimum cases:
- exhaustive B4 operation tables and both lattice orders;
- coverage `not_scanned` distinct from complete-with-no-evidence;
- `SAT`/`UNSAT` interpretation depends on query kind;
- fake string witness is rejected;
- PC3 certificate binding fails when AST or contract hashes change;
- retractions target evidence IDs and recompute active support;
- source cycles do not imply provenance cycles;
- negative cycles are rejected unless semantics are explicitly supported;
- fuel exhausted during external call is handled by host timeout, not interpreter fuel alone;
- corrupt offset, overflow, unaligned view, unknown section and wrong endianness are rejected safely;
- cache invalidation includes relevant bodies/tool/model/policy changes;
- synthetic examples never become real project evidence.

## 15. Prior art and novelty discipline

KERN builds on established ideas including Belnap–Dunn bilattices, proof-carrying code, differential dataflow, content-addressed build/cache systems, memory-mapped data formats, SMT and proof assistants. These should be cited and implemented correctly. Any claim that KERN introduces a new mathematical object, new algorithm or improves prior art requires a definition, comparison, proof where applicable, and reproducible benchmarks. The combination may be novel in a particular integration, but that is a research hypothesis until literature review and evaluation support it.
