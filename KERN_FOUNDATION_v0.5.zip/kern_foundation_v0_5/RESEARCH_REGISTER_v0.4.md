# Research register — v0.4

1. Belnap–Dunn FOUR is the evidence logic; verify the two order structures separately. Reference overview: https://en.wikipedia.org/wiki/Four-valued_logic ; final formal publication claims should be anchored to primary logic literature.
2. Proof-carrying code is established prior art: Necula, POPL 1997, https://doi.org/10.1145/263699.263712. KERN's possible contribution is its concrete integration/contract and must be compared empirically.
3. Differential dataflow is established prior art: McSherry et al., CIDR 2013, https://www.microsoft.com/en-us/research/publication/differential-dataflow/. It does not imply every project update has O(delta) cost.
4. Linux HugeTLB requirements and caveats: https://docs.kernel.org/admin-guide/mm/hugetlbpage.html and https://man7.org/linux/man-pages/man2/mmap.2.html.
5. BLAKE3 official specification and design rationale: https://github.com/BLAKE3-team/BLAKE3-specs. Hashes provide content identity/integrity assumptions, not authenticity by themselves.
