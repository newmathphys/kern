# Technical audit of proposed KERN implementation

## A. Correct parts to preserve

- Belnap encoding with bit 0 = positive support and bit 1 = negative support is coherent.
- `NOT_B(p,n)=(n,p)`, `AND_T=(p_a&p_b,n_a|n_b)`, `OR_T=(p_a|p_b,n_a&n_b)`, `JOIN_K=(p_a|p_b,n_a|n_b)`, and `MEET_K=(p_a&p_b,n_a&n_b)` are the right independent operations for the stated encoding.
- An explicit `CoverageState` is necessary; “not scanned” must not be collapsed into “scanned and no evidence.”
- Provenance, verification verdict and belief state should remain separate.
- PC3, retractions, chunked binary snapshots and fuel are promising design directions when their contracts are made precise.

## B. Defects and overclaims

### B1. String-only SMT bridge is not verification

The sample `SmtBridge` does not invoke Z3 or parse SMT-LIB. Detecting substrings such as `unsat`, `false`, or `model_sat_witness` cannot establish satisfiability, validity or a counterexample. The sample must be a stub returning `not_run` until real solver IO, process exit/status parsing, model parsing and model validation exist.

### B2. SAT, UNSAT and truth need query-specific interpretation

SAT for `Pre` means a satisfying input exists for the encoded precondition. It says nothing by itself about postcondition correctness. To search for a partial-correctness counterexample, query `Pre ∧ ¬Post`; SAT gives a counterexample only after model validation, and UNSAT establishes the encoded property only under stated assumptions. Timeout/unknown proves neither side.

### B3. Nonempty witness string does not establish satisfiability

`witness.len > 2` or a prefix is merely textual presence. A witness must have a typed schema and must be evaluated by the appropriate checker against the exact formula, or verified with a proof object. Infeasible preconditions should yield `VACUOUS_OR_UNREACHABLE_SPECIFICATION`, not set the original proposition to Belnap F automatically.

### B4. Out-of-fuel is not Belnap conflict

A task that exhausts fuel has not produced contradictory evidence. Its execution outcome is `OUT_OF_FUEL`; its logical claim state remains unchanged or unverified until evidence is available.

### B5. The supplied DFS theorem is too weak for the performance claim

A theorem of the form `∃ res, f = res` is a tautological existence claim for the result of a total Lean definition; it does not quantify over machine steps or prove a practical cost bound. A fuel-decreasing recursive definition can terminate while still doing exponential work because each level may visit a high-branching dependency list. Charge each node visit, edge visit and library operation, and state the abstract cost model explicitly.

### B6. Differential updates do not make every update O(delta)

Incremental dataflow can maintain many computations efficiently, including iterative queries, but cost depends on affected tuples, joins, recursive propagation, data structures and rule semantics. Retractions cannot be implemented by a generic inverse of Belnap knowledge join; maintain per-evidence support/provenance and recompute the support bits or use deletion-aware provenance.

### B7. Bipartite does not imply DAG

A bipartite graph can contain cycles. Keep cyclic source dependency graphs as cyclic; use SCC algorithms. Make the immutable-version derivation history acyclic by construction. If recursive Datalog rules exist, define fixed-point semantics and require stratified negation or handle unstratified rules as blocked/diagnostic.

### B8. `.kbin` reference arithmetic needs correction

`chunk_id:u12 + offset:u20` gives at most 4096 * 1 MiB = 4 GiB, not 8 GiB. A 2 MiB chunk requires 21 offset bits; 12+21=33 bits and cannot fit in u32. v4 therefore uses `{ chunk_id:u32, offset:u32 }` or an explicitly defined 64-bit reference.

### B9. mmap is not zero cost and unchecked casts are unsafe

Mapping can avoid full deserialization, but page faults, verification, cache misses and query materialization still cost time. Validate all offsets/lengths before use. Do not cast arbitrary mapped bytes directly to Zig/C structs before checking bounds, alignment, version and endian assumptions. An immutable snapshot or atomic replacement is safer than concurrent mutation of a mapped file.

### B10. Huge pages and cache-line sizes are optimizations, not invariants

Linux HugeTLB depends on kernel configuration, page sizes and available reservations. Use optional huge-page hints/requests and fallback to ordinary mapping. Do not claim all current CPUs use 64-byte cache lines or that huge pages remove TLB misses entirely. Benchmark on target systems.

### B11. SIMD claims require assembly and measurement

The fact that four-valued values fit in two bits does not imply 32 facts are resolved in one CPU cycle. Specify a bit-plane layout, target ISA, actual instructions and throughput benchmark. Scalar correctness and SIMD equivalence tests are mandatory.

### B12. Cache projection must be task-sensitive

An interface-only semantic slice is valid only for tasks independent of function bodies. A correctness analysis, docstring analysis or runtime behavior query may depend on bodies and documentation. Include all semantically relevant inputs, tool versions, prompt/output schemas and checker policy. If the model version is opaque, label the cache weakly versioned and define revalidation/TTL.

### B13. PC3 is policy-relative

Proof-carrying code is established prior art (Necula, POPL 1997). KERN may integrate proof-carrying completions with project provenance and incremental verification, but cannot claim novelty merely from requiring a proof. Certificate checking complexity and guarantees depend on the proof system, semantics and trusted checker.

### B14. Linear types / scoped arenas do not automatically make all leaks impossible

Resource safety requires that every host resource is acquired within a tracked task scope and that every exit path closes/cancels it. Crashes, process termination, FFI behavior and external processes need separate handling. Use OS process isolation for untrusted or potentially non-terminating host operations.

### B15. Non-Turing completeness must be enforced formally

Merely banning `while` is insufficient; recursion, macro expansion or unbounded compile-time evaluation can restore general computation. KERN-D must use finite iteration over a statically known finite collection and prohibit general recursion/macros with unbounded expansion, or use a proved structural recursion checker. KERN-X fuel ensures finite metered VM steps, not universal wall-clock bounds for unbounded external calls.

## C. Required implementation order

1. Compile and test pure Belnap scalar operations.
2. Implement a real parser with explicit diagnostics; never silently skip unrecognized tokens.
3. Implement truth gate and coverage state.
4. Build the real SMT adapter with query-specific result mapping.
5. Implement `.kbin` reader bounds checks before the writer; fuzz reader inputs.
6. Implement immutable snapshots and stable relative references.
7. Implement evidence-ID deltas and compare incremental recompute with full recompute.
8. Implement PC3 schema binding and one proof checker integration before generalizing.
9. Benchmark SoA/CSR, SIMD, huge pages and cache projections against baselines.

## D. Primary references

- Necula, G. C. “Proof-Carrying Code.” POPL 1997. DOI: https://doi.org/10.1145/263699.263712
- McSherry et al. “Differential Dataflow.” CIDR 2013: https://www.microsoft.com/en-us/research/publication/differential-dataflow/
- Linux `mmap(2)`: https://man7.org/linux/man-pages/man2/mmap.2.html
- Linux HugeTLB documentation: https://docs.kernel.org/admin-guide/mm/hugetlbpage.html
- Official BLAKE3 specification: https://github.com/BLAKE3-team/BLAKE3-specs
- Belnap–Dunn FOUR overview: https://en.wikipedia.org/wiki/Four-valued_logic (use primary logical literature for final formal claims)
