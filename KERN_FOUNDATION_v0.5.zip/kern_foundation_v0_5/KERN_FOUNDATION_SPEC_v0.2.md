# KERN Foundation Specification v0.2

**Status:** design specification for implementation and review; not a claim of implemented functionality.  
**Language:** KERN-D (declarative project model); KERN-X (future bounded execution extension).  
**Native engine target:** Zig, with the exact toolchain version pinned in each build manifest.  
**Text encoding:** UTF-8.  
**Source extension:** `.kern`.  
**Indexed catalog:** `.kdb` (SQLite).  
**Portable binary snapshot:** `.kbin`, format family v2.

## 1. Scope

KERN represents software projects and their research trail as typed, versioned entities: artifacts, symbols, claims, observations, evidence, verification runs, proofs, metrics, decisions, blockers, questions, derivations, snapshots, and cache entries.

Version 0.2 adopts five design decisions:

1. Four-valued evidence aggregation is separate from operational verification verdicts.
2. Source/build dependencies and provenance derivations are different graphs with different invariants.
3. `.kbin` supports safe read-only memory mapping and offset-based access; it does not promise zero physical I/O, zero page faults, or zero allocation for every query.
4. Model-assisted analysis is cached using task-specific semantic slices and a full relevant execution fingerprint.
5. KERN-X tasks are bounded by fuel and additional resource limits; wall-time bounds require interruptible/cancellable host operations.

## 2. Normative language

`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are normative. An implementation MUST publish the conformance classes it has passed.

## 3. Language modes

### 3.1 KERN-D

KERN-D is declarative. Parsing, type checking, linking, and building a `.kern` file MUST NOT execute arbitrary user code, invoke a shell, access the network, load untrusted dynamic libraries, or modify the analyzed project.

### 3.2 KERN-X

KERN-X is a separate, optional task/execution extension. Its semantics must include capabilities, deterministic fuel charging, memory/output quotas, bounded host functions, cancellation, and atomic publication of outputs. KERN-D readers MUST reject unknown executable declarations rather than guess their intent.

### 3.3 Separation of concerns

The Zig engine can parse and index a KERN project without an AI service. An AI agent can propose claims, source links, and verification plans, but its self-description is not evidence that a fact is true. Actual execution and verification results are recorded by the tool boundary.

## 4. Core entity model

Minimum entities:

- `project`
- `artifact` / `artifact_version`
- `module`
- `symbol`
- `claim` / `claim_version`
- `observation`
- `evidence`
- `derivation`
- `verification_policy`
- `verification_run`
- `verdict`
- `proof`
- `metric`
- `relation`
- `decision`
- `blocker`
- `question`
- `snapshot`
- `cache_entry`
- `agent_packet`

Every persisted entity MUST have a stable identity, schema version, source/provenance metadata where applicable, and explicit distinction between declared content and computed state.

## 5. Belnap–Dunn four-valued evidence state

For each atomic claim, an evidence policy determines whether there is at least one admissible positive support and whether there is at least one admissible negative support. The resulting Belnap value is one of `N`, `T`, `F`, `B`:

| Value | Positive support | Negative support | Meaning |
|---|---:|---:|---|
| `N` / `NEITHER` | 0 | 0 | Neither admissible support for nor admissible support against has been registered within the evaluated scope. |
| `T` / `TRUE_ONLY` | 1 | 0 | Admissible positive support exists and admissible negative support does not. |
| `F` / `FALSE_ONLY` | 0 | 1 | Admissible negative support exists and admissible positive support does not. |
| `B` / `BOTH` | 1 | 1 | Admissible positive and negative support both exist. |

This is an evidence state, not a probability and not a model confidence score.

The engine MUST separately track scan/coverage state (`not_scanned`, `partial`, `scanned_no_evidence`, `scanned_with_evidence`, `complete_under_policy`). `N` MUST NOT conceal the difference between “not examined” and “examined but no admissible evidence was found.”

### 5.1 Evidence admissibility

Evidence is admissible for a claim only if its scope, target proposition, method, source provenance, and verification policy are appropriate. For example:

- A passing unit test supports the narrow claim that that test passed under its recorded code and environment; it does not by itself support the universal claim “the program is correct.”
- An SMT `sat` result can refute a precisely encoded universal assertion only if the returned model is a valid counterexample under the recorded encoding/assumptions. `unknown` is not a counterexample or proof.
- A formal proof result is scoped to its exact theorem, assumptions, checker, and dependency set.
- An LLM statement is a candidate interpretation or hypothesis by default, not admissible positive evidence that the proposition is true.

Different methods that address different propositions MUST NOT be merged into a conflict merely because their prose sounds inconsistent. Normalize claims to atomic statements and compare their formal scopes before aggregation.

### 5.2 Operational truth gate `e`

`e` is not the Belnap value. It is a Boolean acceptance gate derived from a claim-kind-specific policy:

`e(c) = 1` iff all required checks pass, provenance is complete enough for the declared claim type, the Belnap value is `T`, no unresolved applicable contradiction remains, and policy requirements are satisfied.

Otherwise `e(c) = 0`.

A value of `T` alone does not prove a theorem, guarantee general program correctness, or make an empirical claim universally true. The status and the evidence type remain part of the conclusion. A claim in state `B` MUST retain both sides and MUST create or update a `resolve_contradiction` task. No panic, crash, silent source selection, or overwrite is permitted.

## 6. Algebra definitions

Encode a Belnap value as two bits `(p,n)` where `p` indicates admissible positive support and `n` indicates admissible negative support:

- `N = (0,0)`
- `T = (1,0)`
- `F = (0,1)`
- `B = (1,1)`

For merging information from evidence sources, use the knowledge join:

`(p1,n1) JOIN_K (p2,n2) = (p1 OR p2, n1 OR n2)`.

The knowledge meet is:

`(p1,n1) MEET_K (p2,n2) = (p1 AND p2, n1 AND n2)`.

Belnap negation swaps the coordinates: `NOT_B(p,n) = (n,p)`.

Truth-functional connectives MUST use the Belnap–Dunn tables specified in `docs/KERN_BELNAP_SEMANTICS_v0.2.md`; they MUST NOT be confused with evidence aggregation. The token `and` in KERN expressions means the specified logical connective, not “merge all sources.” A separate built-in such as `merge_evidence` uses `JOIN_K`.

### 6.1 Do not conflate bilattice and provenance semiring

KERN v0.2 deliberately uses two separate mathematical objects:

1. `BelnapValue` / bilattice for incomplete and inconsistent evidence state.
2. `ProvenanceExpr` / provenance algebra for recording how output depends on source identifiers and derivation steps.

Provenance semirings are grounded in the algebraic requirements for annotated relational queries; a four-valued truth lattice does not automatically become a suitable semiring merely by naming two operators `⊕` and `⊗`. Any combined “Belnap semiring” extension MUST specify carrier, zero, one, addition, multiplication, and prove the required semiring identities and intended interpretation before acceptance. Until then, the implementation MUST keep these domains separate.

## 7. Graph model: three graphs, not one

### 7.1 Source and dependency graph `G_src`

Nodes include source files, symbols, modules, packages, tests, and external components. Edges include import, call, build-dependency, reference, and containment. `G_src` MAY contain cycles. Cycles are analyzed using strongly connected components (SCCs), not silently assumed absent.

### 7.2 Execution/build dependency graph `G_build`

This graph models actual scheduled operations. An acyclic build plan may be formed by topologically ordering its SCC-condensation graph, but a cyclic component needs a declared policy: legal recursive/fixed-point processing, supported strongly connected build unit, or an explicit cycle diagnostic. The engine MUST NOT claim termination just because nodes are typed as different kinds.

### 7.3 Provenance graph `G_prov`

`G_prov` records immutable versions and derivations:

`ArtifactVersion / ClaimVersion -> DerivationRun -> Evidence / ClaimVersion / ArtifactVersion`.

A derivation may have multiple input objects and multiple outputs; it is therefore modeled as a hyperedge or as a first-class `DerivationRun` node with typed input/output edges.

The provenance graph for one committed snapshot MUST be acyclic. This property is enforced by construction:

- source versions and claim versions are immutable;
- a derivation references only input versions that existed in its declared parent frontier;
- every derivation run has a monotonically increasing sequence within the snapshot lineage;
- outputs are assigned new version IDs and cannot be retroactively substituted for inputs;
- forward references and cycles in provenance edges are rejected.

Bipartite node types alone DO NOT guarantee acyclicity. If an algorithm is recursive or based on a logical fixed point, store the whole bounded fixed-point evaluation as a `DerivationRun` with its rules, seed state, iteration transcript, termination condition, and outputs. Internal recursive semantics are not represented by falsely claiming that every rule-level dependency is acyclic.

## 8. Provenance algebra

KERN may use a provenance semiring for monotone derivations, with source tokens as variables and:

- `a + b`: alternative derivations;
- `a * b`: joint requirement of inputs.

The baseline applies to the declared positive/monotone derivation fragment. Negation, absence-as-false, revocation, and non-monotonic rules require explicit semantics and MUST NOT be smuggled into the positive semiring without proof. Provenance tracks why a result was derived; Belnap tracks the state of positive/negative evidence. A typed bridge between these domains is allowed only through a specified mapping.

## 8.1 Relation registry

The initial relation registry includes `references`, `imports`, `calls`, `contains`, `depends_on`, `supported_by`, `refuted_by`, `tested_by`, `verified_by`, `proves`, `proposed_by`, `contradicts`, `derived_from`, `generates`, `updates`, and `blocked_by`. Each relation type declares legal source/target kinds and whether it contributes to provenance, source navigation, verification, or merely annotation. In strict mode, an unregistered relation type is a diagnostic. `proposed_by` does not itself add positive truth support.

## 9. KERN-D types and validation

The v0.1 primitive types remain: `String`, `Bool`, `Null`, `Int`, exact `Decimal` lexeme, `Array`, `Object`, typed `Reference`, and registered `Enum`.

Every claim records `claim_kind`, exact statement, scope, assumptions, limitations, and evidence policy. The computed fields `belnap_value`, `verdict`, `e`, coverage, and diagnostics MUST NOT be authorable directly in source declarations. Source declarations may record `declared_state` only.

A missing reference, invalid status, absent evidence, unresolved scope mismatch, or corrupt `.kbin` is a diagnostic with source location. Missing information is never silently coerced to `false`.

## 10. `.kbin` v2: safe memory-mappable layout

The binary layout is defined in `docs/KERNBIN_FORMAT_v0.2.md`. It uses:

- fixed-size header and section directory;
- explicit little-endian fields;
- 64-bit offsets and lengths for large-project headroom;
- section-relative offsets for string and record references;
- BLAKE3 section/root hashes with domain separation;
- 8-byte alignment as the correctness baseline;
- optional larger alignment only as a measured performance option;
- read-only mapping of immutable snapshots;
- bounds validation before every offset dereference.

Zero-copy means the reader may access compatible serialized buffers directly without unpacking every record into heap objects. It does not mean zero page faults, zero operating-system work, zero validation work, or zero allocation for all queries. The reader MUST NOT cast unchecked on-disk bytes to native structs and assume host alignment/endian compatibility. It MUST decode fields safely and validate integer overflow, overlapping ranges, alignment, file size, section hashes, string bounds and record bounds.

A 64-byte cache-line alignment is optional, not a universal correctness rule. It must be benchmarked per target hardware; aligning every tiny record to a cache line may waste substantial space. The v2 offsets are 64-bit; a future compact 32-bit profile is allowed only with explicit per-section size bounds and separate format flags.

## 11. Merkle semantic-slice cache

Every derived result, including LLM-assisted analysis, receives a content-addressed cache key based on the exact semantic inputs of that task.

Conceptually:

`K = BLAKE3(domain || task_kind || SemanticSliceHash || RequestHash || ModelFingerprint || GenerationParameters || PromptTemplateHash || ToolSchemaHash || InputSchemaVersion || OutputSchemaVersion || ExtractorVersion || VerificationPolicyHash || RetrievalConfigHash)`.

All fields use a versioned canonical encoding with length prefixes and domain separation. Hashes are not formed by ambiguous string concatenation.

### 11.1 Semantic slices

A slice profile MUST be explicit, e.g.:

- `interface`: public signatures, types, contracts, exported names and relevant API docs;
- `implementation`: normalized AST/body semantics for selected symbols and transitive required bodies;
- `documentation`: selected document sections and citations;
- `raw_source`: exact bytes for tasks where formatting/comments are meaningful;
- `experiment`: code/config/data/seed/environment/method/log inputs for a measurement;
- `full_context`: all actual bytes/tokens sent to the model, represented by source references and hash.

An interface-only cache key MUST NOT be used for a task whose conclusion depends on function bodies, runtime behavior, comments/docstrings that were supplied to the model, or other excluded inputs. Comment changes can be ignored only when comments were not semantically used by that task's pipeline.

### 11.2 Model fingerprint and cache policy

The fingerprint includes exact model/revision when available, provider, endpoint/protocol, tokenizer version where relevant, prompt/system-template hash, tool definitions, generation parameters (including seed when supported), output schema, and policy version. If a provider exposes only a moving alias, the entry must be marked `model_revision_unknown` and receive a configurable TTL/revalidation policy.

Cached model output is a reusable derived suggestion, not independent evidence and not a fresh verification. Verification results have their own cache keys including tool version and verification inputs. Failed, incomplete, or timed-out calls must not overwrite the last valid cache entry.

BLAKE3 is the proposed hash because its design supports tree-structured parallel and incremental hashing; final implementation still requires test vectors and independent validation. The source hash, semantic-slice hash, and model-output identity are separate fields.

## 12. KERN-X fuel and resource semantics

The full proposal is in `docs/KERNX_FUEL_SPEC_v0.1.md`.

Every KERN-X task declares:

- `fuel_limit: UInt64`;
- `arena_limit_bytes: UInt64`;
- `output_limit_bytes: UInt64`;
- `recursion_limit: UInt32`;
- allowed capabilities and host calls;
- per-host-call budget/deadline;
- cancellation policy;
- staged side-effect policy.

Every interpreted/VM instruction decrements fuel under a pinned cost schedule. Every host operation is either bounded and charged, or forbidden inside a deterministic phase. Filesystem/network/process host calls require explicit capabilities and deadlines, and must be cancellable or isolated such that a stuck call cannot block the engine indefinitely. Memory growth is checked before allocation. Staged writes are atomically committed only after successful completion; fuel exhaustion, timeout, or memory error leaves the last committed snapshot intact.

Fuel guarantees a finite instruction bound only if every execution step is metered and unbounded native/host calls cannot bypass the meter. It is not by itself a strict wall-clock guarantee because OS scheduling, page faults, device calls, and uninterruptible host functions are outside a simple instruction counter. The runtime reports `FUEL_EXHAUSTED`, `MEMORY_LIMIT`, `HOST_TIMEOUT`, `OUTPUT_LIMIT`, `CAPABILITY_DENIED`, `CANCELLED`, and `INTERNAL_ERROR` distinctly.

## 13. AI risk and conformal methods

KERN MAY use calibrated conformal-risk-control or conformal-generation methods to manage candidate-generation risk. These methods require a specified loss, data/calibration protocol, and their applicable assumptions. A statistical risk guarantee is not the same as a formal proof for an individual generated program or theorem. Model proposals still pass through typed checks, tests, or proof checkers appropriate to their claim type.

The model may return a set of candidate edits/invariants rather than a single edit. KERN should validate candidates in a sandbox and preserve their parent context, scores, rejection reasons, and calibration metadata. Selection and deployment policies must be explicit.

## 14. Incremental build and invalidation

Each derived object declares exact inputs and method version. On a change:

1. hash raw inputs;
2. recompute affected normalized representations;
3. update affected dependency edges;
4. compute impacted SCCs in `G_src`/`G_build`;
5. invalidate cache entries whose semantic slice or execution fingerprint changed;
6. preserve independent cache entries;
7. re-run only required checks;
8. atomically publish a new snapshot with coverage and diagnostics.

A changed comment may be irrelevant to an `interface` analysis but relevant to `documentation` or a model prompt that included it. Invalidation depends on declared semantics, not a universal “ignore comments” rule.

## 15. Required diagnostics

In addition to v0.1 diagnostics, add:

- `claim_scope_mismatch`
- `evidence_inadmissible`
- `belnap_conflict`
- `provenance_cycle`
- `source_dependency_scc`
- `cache_projection_unsafe`
- `model_revision_unknown`
- `kbin_bad_offset`
- `kbin_overlap`
- `kbin_hash_mismatch`
- `fuel_exhausted`
- `memory_limit`
- `host_timeout`
- `output_limit`
- `conformal_assumption_missing`
- `fixed_point_budget_exhausted`

Diagnostics are structured data with code, severity, source location, involved IDs, phase, and resolution state.

## 16. Status and truth-state API

The status API MUST expose at least:

- `belnap_value`: `N | T | F | B`;
- `coverage`: `not_scanned | partial | scanned_no_evidence | scanned_with_evidence | complete_under_policy`;
- `verdict`: a typed procedure-specific result;
- `e`: `0 | 1` policy acceptance gate;
- `conflict_task_id`: optional task to resolve contradiction;
- `evidence_positive_ids`, `evidence_negative_ids`;
- `verification_policy_id`;
- `last_verified_snapshot`.

These dimensions must not be collapsed into a single confidence number.

## 17. Research and novelty policy

KERN must be positioned as a synthesis/engineering proposal until a systematic literature and implementation review establishes novelty. It MUST NOT claim that no existing product or research system has a similar graph, logic, binary layout, AI loop, or cache without documenting a search protocol and comparison matrix. Existing work on provenance semirings, bilattices, incremental computation, zero-copy formats, bounded execution, and conformal risk control is prior art to study rather than relabel as novel.

## 18. Acceptance for v0.2 implementation

A compiler must pass the v0.1 parser/semantic tests plus all v0.2 tests before claiming v0.2 conformance. At minimum:

- complete Belnap truth-table and order-law tests;
- evidence-admissibility and scope-mismatch tests;
- conflict retention and task-generation tests;
- source-graph cycle and SCC tests;
- provenance DAG construction/rejection tests;
- `.kbin` bounds, overlap, hash, truncation, and round-trip tests;
- mmap lifetime/immutability tests;
- semantic-slice cache key tests;
- model-fingerprint and stale-cache tests;
- fuel/memory/host-timeout/atomic-publication tests;
- report metrics calculated from actual run records.

## 19. Research sources

- Belnap–Dunn four-valued logic: Stanford Encyclopedia of Philosophy, “Truth Values”: https://plato.stanford.edu/entries/truth-values/
- Provenance semirings: Green, Karvounarakis, Tannen, PODS 2007: https://www.cs.ucdavis.edu/~green/papers/pods07.pdf
- FlatBuffers direct-access serialization: https://github.com/google/flatbuffers
- BLAKE3 specification and implementation: https://github.com/BLAKE3-team/BLAKE3 and https://github.com/BLAKE3-team/BLAKE3-specs
- Conformal generation: Loaiza-Ganem et al., ICML 2026, PMLR 306: https://proceedings.mlr.press/v306/loaiza-ganem26a.html
- Well-founded recursion and termination: Lean 4 theorem-proving documentation: https://lean-lang.org/theorem_proving_in_lean4/Induction-and-Recursion/
- Incremental computation: Adapton project and PLDI 2014 paper: https://adapton.org/

These references support specific techniques; they do not establish that KERN as a whole is novel or that its proposed integration is correct. Those remain engineering and research obligations.
