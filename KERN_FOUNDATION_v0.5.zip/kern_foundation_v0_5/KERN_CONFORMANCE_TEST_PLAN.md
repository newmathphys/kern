# Current conformance plan

Current version: `KERN_CONFORMANCE_TEST_PLAN_v0.5.md`.
Older v0.2/v0.3 plans are retained for history only.
