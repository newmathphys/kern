# KERN Foundation Specification v0.4

**Status:** implementation-oriented specification and reference modules; not a claim that the Zig or Lean files have been compiled in this environment.
**Native runtime target:** Zig, exact toolchain version pinned by the repository build manifest.
**Logic kernel:** Belnap–Dunn FOUR as evidence support; source provenance, verifier verdict, coverage and lifecycle remain separate dimensions.

## 1. Purpose of v0.4

Version 0.4 turns the v0.3 ideas and the proposed code into a stricter implementation contract. It corrects invalid inferences and preserves the useful architecture:

1. Belnap four-valued support with separate truth-order and knowledge-order operations.
2. A truth-admission gate distinct from evidence aggregation.
3. Differential updates over provenance-aware evidence records, with explicit retraction semantics.
4. Proof-carrying completion (PC3) bound to the exact AST, contract, environment and checker policy.
5. A chunked, offset-based `.kbin` format suitable for read-only memory mapping.
6. Task-specific semantic Merkle caching.
7. KERN-X metering that distinguishes fuel exhaustion from logical contradiction.

## 2. Belnap value and bit encoding

Each proposition is represented by two support bits `(p,n)`:

- `N = (0,0)`: neither positive nor negative support is admitted;
- `T = (1,0)`: positive support only;
- `F = (0,1)`: negative support only;
- `B = (1,1)`: both positive and negative support.

Canonical scalar encoding:

| Value | p bit | n bit | two-bit value |
|---|---:|---:|---:|
| N | 0 | 0 | `00b` |
| T | 1 | 0 | `01b` |
| F | 0 | 1 | `10b` |
| B | 1 | 1 | `11b` |

`p` is bit 0; `n` is bit 1. For a given proposition and scope:

- evidence aggregation / knowledge join: `JOIN_K(a,b) = (p_a OR p_b, n_a OR n_b)`;
- knowledge meet: `MEET_K(a,b) = (p_a AND p_b, n_a AND n_b)`;
- truth negation: `NOT_B(a) = (n_a,p_a)`;
- truth conjunction: `AND_T(a,b) = (p_a AND p_b, n_a OR n_b)`;
- truth disjunction: `OR_T(a,b) = (p_a OR p_b, n_a AND n_b)`.

These operations have different semantics and MUST NOT share a generic `combine` API. `JOIN_K(T,F)=B`, while `AND_T(T,F)=F`. The value `B` is a state of conflicting evidence, not an execution failure and not, by itself, a proof that a source is incorrect.

## 3. Four independent axes

Never collapse the following into one enum:

1. `BelnapValue`: admitted positive/negative support for a precisely scoped proposition.
2. `VerificationVerdict`: outcome of a specific verification job (`proved`, `counterexample`, `unknown`, `timeout`, `invalid_certificate`, `not_run`, `tool_error`).
3. `CoverageState`: whether the relevant corpus and policy-required checks were scanned (`not_scanned`, `partial`, `scanned_no_evidence`, `scanned_with_evidence`, `complete_under_policy`).
4. `ClaimLifecycle`: workflow state (`draft`, `queued`, `blocked`, `accepted`, `rejected`, `superseded`).

A timeout is not `F`; a corrupt proof certificate is not evidence that the proposition is false; a resource exhaustion is not a Belnap conflict; a passed test is empirical evidence for its tested scope, not a universal proof of program correctness.

## 4. Truth gate

`e(c)=1` is derived, never assigned by source syntax or an LLM. Admission requires a type-specific policy, exact scope, complete enough provenance, appropriate verifier success, policy-compliant coverage, integrity checks, and `BelnapValue.T` under the configured evidence policy. `B` creates a contradiction-resolution task. `N`, `F`, partial coverage, unknown verdicts and timeouts cannot be admitted as proven.

A passed test can add positive empirical support only for its bounded tested property. A formal proof can add positive formal support only for the proposition actually encoded. The policy decides which evidence classes are sufficient for each claim class.

## 5. Solver result interpretation

These are distinct queries:

### Precondition feasibility
Solve `Pre(x)`.

- `SAT` plus a model independently evaluated against the same encoding: `PRECONDITION_FEASIBLE`.
- `UNSAT`: `VACUOUS_OR_UNREACHABLE_SPECIFICATION`; this does not automatically make the original business claim false.
- `UNKNOWN`/timeout: `FEASIBILITY_UNKNOWN`.

### Partial-correctness counterexample search
Solve `Pre(x) AND NOT Post(x, f(x))` using a sound encoding of the program semantics.

- `SAT` plus a validated model: a counterexample is found for the encoded property.
- `UNSAT`: no counterexample exists in the supported encoded model, subject to the solver, theory and encoding assumptions.
- `UNKNOWN`/timeout: no conclusion.

A string such as `"model_sat_witness..."`, a nonempty byte string, or an LLM assertion is not a satisfiability witness. A witness must be parsed and evaluated against the exact formula; a solver integration must invoke a real solver or return `NOT_RUN`.

## 6. PC3 acceptance

When enabled by policy, an AI completion is staged as:

`Completion = (canonical_AST, contract, proof_certificate, interface_environment, producer_metadata)`.

The certificate is bound to hashes of the exact AST, contract, imported interfaces, target model and verifier policy. The trusted checker validates that the certificate proves a declared property of that exact artifact. Failure means the staged edit is not published. PC3 does not prove unspecified business correctness and does not automatically prove every program property. Complexity claims for certificate checking must name a proof calculus and encoding; no general `O(AST)` guarantee is assumed.

## 7. Graphs and incremental changes

Keep separate graph projections:

- `G_src`: source dependencies; cycles are allowed and recorded;
- `G_build`: build tasks; scheduling cycles require an explicit error or fixpoint semantics;
- `G_prov`: immutable derivation records. Edges reference immutable input versions and newly created output versions; this makes the versioned derivation history acyclic by construction.

Bipartiteness alone does not imply acyclicity. SCC decomposition is used on source/module graphs. Recursive logical rules require explicitly defined finite fixed-point semantics; negation requires stratification or a specified non-monotone semantics.

Differential events reference individual evidence IDs and carry a signed multiplicity/change. Retractions remove the designated contribution; they do not attempt to invert `JOIN_K`, because knowledge join is idempotent and has no general inverse. Recompute the two support bits from the active admissible evidence set, or use a deletion-aware provenance representation. A delta event may invalidate derived rows transitively; no universal `O(|delta|)` time bound is promised for arbitrary analyses.

## 8. KERN-X resource semantics

A task budget may include `fuel_remaining`, `arena_limit_bytes`, `output_limit_bytes`, `recursion_limit`, host-call count, and optional wall deadline. Fuel is charged for every VM instruction and every bounded host/library operation. Host I/O and external process calls need explicit timeouts/cancellation or process isolation; a VM fuel counter alone cannot bound an arbitrary external call or guarantee wall-clock time on an overloaded host.

Fuel exhaustion returns a resource outcome (`OUT_OF_FUEL`), never `BelnapValue.B`. Task-scoped arenas own temporary allocations and are released as a whole at task exit/failure. Only successful completion publishes a new snapshot; failures leave the prior committed snapshot available.

## 9. `.kbin` v4 safety rules

See `format/KERNBIN_V4.md`. Canonical integer encoding is little-endian; offsets and lengths are 64-bit in file tables. Chunk references use `(chunk_id:u32, offset:u32)`, avoiding the impossible 33-bit-in-u32 encoding in the previous proposal. The offset must be within the designated chunk and all range checks must avoid overflow.

The reader validates magic, format version, file size, section table, bounds, alignment, section hash and each referenced record before exposing typed views. It must not cast unchecked mmap bytes directly to native structs. Zero-copy typed views are allowed only when host endianness/alignment and schema constraints make them valid; otherwise use safe accessors/byte decoding.

Use immutable snapshot publication (`write temporary file -> flush/sync as supported -> atomic rename`) so readers never observe a file being truncated or mutated under a live mapping. HugeTLB/THP is optional runtime tuning with a normal-page fallback. Cache-line alignment and page size are not universal correctness assumptions.

## 10. Semantic Merkle cache

The cache key is derived from a task-specific canonical projection, not an arbitrary guess at the code's meaning. Minimum key inputs:

`Key = BLAKE3(schema_version || task_kind || canonical_input_slice || prompt_template_hash || output_schema_hash || model_fingerprint || generation_params || tool_fingerprints || retrieval_config || policy_version || checker_version)`.

If a task depends on implementation bodies, comments/docstrings, build flags, dependency versions or runtime behavior, those inputs must be included. Interface-only slicing is valid only when task semantics explicitly declare that bodies are irrelevant. Cyclic dependency graphs are processed by SCC decomposition and canonical component hashing. A cache hit is reuse of a prior result, not fresh execution or proof.

## 11. Performance policy

No fixed claims such as “0 allocations for the entire engine,” “no TLB misses,” “32 claims in one CPU cycle,” “100% branch prediction,” or “incremental update always costs O(delta)” are part of the normative specification. They are experiment hypotheses to test against baselines under a declared CPU, OS, dataset, access pattern, thread count and measurement protocol.

## 12. Required acceptance tests

- exhaustively validate all 16 input pairs for each binary Belnap operation;
- prove/test the two orders and their lattice laws;
- ensure `JOIN_K(T,F)=B` and `AND_T(T,F)=F`;
- reject forged string-only satisfiability witnesses;
- distinguish precondition SAT from postcondition verification;
- test retractions where other positive evidence remains active;
- compare incremental results with full recomputation on randomized update sequences;
- detect SCCs and reject/diagnose unstratified negation cycles;
- fuzz `.kbin` ranges, offset overflow, malformed sections and truncated files;
- test atomic snapshot replacement with concurrent readers;
- test cache invalidation for body, interface, prompt, model, tools and policy changes;
- test fuel exhaustion is a resource status, not a logical conflict;
- test PC3 certificates are invalidated by any bound artifact/policy change.

## 13. Scope of current package

This release includes reference Zig modules for Belnap operations, the truth gate, fuel accounting, safe relative references/range checks and typed SMT result interpretation, plus a Lean source for core algebraic identities and test vectors. No Zig or Lean toolchain was available in the creating environment; therefore these source files are not claimed to have compiled there. Implementation completion requires toolchain installation/pinning, compilation, fuzzing and benchmark results.
