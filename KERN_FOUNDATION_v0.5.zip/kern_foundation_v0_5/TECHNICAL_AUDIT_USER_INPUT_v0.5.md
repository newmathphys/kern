# Technical audit of the latest KERN proposal (v0.5)

This audit separates sound ideas from claims that are incorrect, underspecified or cannot be accepted without an implementation/experiment.

## Accepted with precise semantics

1. **Belnap–Dunn FOUR.** Encoding `(p,n)` with p in bit 0 and n in bit 1 is consistent. `NOT`, truth-order `AND_T`/`OR_T`, and knowledge-order `JOIN_K`/`MEET_K` must have different APIs.
2. **Coverage is orthogonal.** `N + not_scanned` differs from `N + complete_under_policy`.
3. **PC3/PCC gate.** An AI edit can be staged with AST, contract and certificate; it is published only after a trusted checker verifies a property bound to exact hashes.
4. **Provenance derivation graph.** Immutable input/output versions provide auditable causal history. This graph is separate from source dependencies, where cycles can occur.
5. **Evidence event retractions.** Retractions must refer to the exact event/contribution and trigger recalculation; they cannot invert `JOIN_K` itself.
6. **mmap + relative offsets.** Suitable for read-only, offset-addressed snapshots if headers, ranges, endianness and schema are checked.
7. **Fuel and quotas.** Useful for a VM/DSL interpreter when all work and host operations are accounted for.
8. **SoA/CSR/SIMD.** Worth benchmarking for hot scans, but must be measured versus a baseline.

## Corrections required

### A. The proof checker is not universally O(AST)

PCC is established (Necula, POPL 1997). Efficient checking depends on the certificate calculus and representation. State complexity per checker/certificate format; do not assume linearity for arbitrary Lean, SMT, Hoare or generated proofs.

### B. SAT does not by itself prove a program correct

`SAT(Pre)` establishes precondition feasibility for the formula. `SAT(Pre ∧ ¬Post)` yields a counterexample only if the formula accurately encodes the program property and the model is validated. `UNSAT(Pre ∧ ¬Post)` supports partial correctness only under the solver/theory/encoding assumptions. A non-empty string is not a witness.

### C. Anti-vacuity is a policy, not a universal theorem about software correctness

A false precondition makes a Hoare triple vacuously valid, but the appropriate response depends on policy. Some contracts intentionally describe unreachable states. If the policy requires a reachable input, check satisfiability and validate a model; do not mark the business proposition `F` merely because the contract is unsatisfiable.

### D. Fuel does not prove a whole OS process halts within a wall-clock bound

A global VM work counter bounds only operations covered by its charging model. Filesystem operations, SMT processes, blocking I/O and OS scheduling need host-side deadlines, cancellation, process isolation and separate memory/IO quotas. A per-recursive-call copy of fuel is not a global budget and may still allow exponential fan-out.

### E. B4 is not a provenance semiring by itself

Belnap truth support and provenance annotation algebra are related but separate structures. The implementation must define which algebra annotates derivations and how it maps to positive/negative support. Do not assert semiring laws without proving them for the chosen carrier and operators.

### F. Differential updates are not universally O(delta)

Differential dataflow supports incremental and iterative computation, but the cost depends on affected state, join fan-out, recursive rules, retractions and data distribution. A more defensible bound is output-sensitive and workload-specific; arbitrary whole-graph properties can require large recomputation.

### G. mmap is not instant and not automatically zero-allocation

Mapping establishes a virtual address mapping. Pages can fault in lazily; the OS page cache, I/O, address translation, range validation, scratch buffers and graph indexes still cost time/memory. A zero heap-allocation reader path is possible by design but must be instrumented and demonstrated.

### H. HugePages are optional, not a universal guarantee

Linux `MAP_HUGETLB` requires supported huge-page sizes and available/configured pages; mapping can fail. Provide a regular mmap fallback. Claims about TLB misses or 30–40% CPU time are hardware/workload measurements, not constants of physics.

### I. Cache key projections must be sound for the task

Excluding function bodies is unsafe when the task depends on behavior. Use explicit task dependency declarations; include all relevant implementation, ABI, compiler, model, prompt, tools and retrieval evidence hashes. SCC decomposition solves recursive hashing mechanics but does not itself prove semantic dependency completeness.

### J. The sample canonical manifest contains illustrative assertions

Statements such as "99.4% VERIFIED", 64-byte alignment, 128-bit entropy and named counterexamples must be generated from a real scan/run and exact evidence. Never place invented measurements, placeholder witness strings or synthetic claims in a canonical manifest without `SYNTHETIC` labels.

### K. Some microarchitecture claims are overstated

- 64-byte cache lines are common on current x86 systems but not an architectural universal.
- SIMD does not universally process 32 claims in one cycle; throughput depends on instruction, layout, ISA and dependency chain.
- CSR/SoA can reduce pointer chasing, but not guarantee 100% branch prediction or zero DRAM latency.
- A `u32` offset cannot address arbitrary >4 GiB files without segmentation or wider offsets.
- A packed offset bit allocation must account for chunk size exactly; 20 offset bits address at most 1 MiB, not 2 MiB.

### L. The sample Lean termination theorem can be tautological

A theorem of the shape `∃ res, f ... = res := by exact ⟨f ..., rfl⟩` proves that a total Lean expression returns its own value; it does not prove graph traversal correctness, resource complexity, or a runtime bound. The proof must establish the intended semantic property and derive the termination measure for the actual function.

### M. Cross-language snippets require compilation and differential tests

Zig, Lean, Rust, C++ and Python implementations should share canonical truth tables and cross-language vectors. Do not claim equivalence because implementations look similar. Avoid unsafe enum transmute in Rust when a checked conversion is simple. The actual compiler versions and test outputs must be recorded.

## Sources

- Necula, *Proof-Carrying Code*, POPL 1997: https://doi.org/10.1145/263699.263712
- McSherry et al., *Differential dataflow*, CIDR 2013: https://www.microsoft.com/en-us/research/publication/differential-dataflow/
- Differential dataflow repository: https://github.com/TimelyDataflow/differential-dataflow
- Linux mmap manual, including `MAP_HUGETLB`: https://www.man7.org/linux/man-pages/man2/munmap.2.html
- Linux huge-page documentation: https://docs.kernel.org/admin-guide/mm/hugetlbpage.html
- Lean termination overview (fuel pattern): https://academy.lean4.dev/tactics/automation/termination

## Review of the code snippets included in the proposal

### Belnap Zig snippet

The scalar operations in `BelnapValue` are consistent with the `(p,n)` encoding when `p` is bit 0 and `n` is bit 1. Keep them as separate operators and use exhaustive tests. The `TruthGate` sample should be extended to bind verdicts to exact query/claim hashes and a policy; a boolean named `verifier_succeeded` is insufficient metadata for an auditable decision.

### Lean proof snippets

The B4 identities are finite and appropriate for proof by cases. However, a theorem of the form `∃ res, f inputs = res := by exists (f inputs)` is tautological for a total Lean expression. It does not prove the intended algorithm is correct or that its cost is bounded. A fuel-recursive function returning `B` on fuel exhaustion also confuses epistemic conflict with a resource outcome. Use a separate `EvalOutcome = completed B4 | out_of_fuel`.

### Parser sample

The sample lexer/parser is illustrative only and cannot be treated as a complete parser:
- it accepts one simplified `claim` body, not the full grammar;
- it silently advances over unknown tokens/fields instead of rejecting malformed input;
- it does not robustly reject unterminated strings or define string escape handling;
- line/span reporting needs start and end offsets and precise error positions;
- it uses a witness-string length to choose `T`, which is unsound;
- malformed declarations can be partially accepted.

A normative parser must reject unknown required constructs, support versioned extensions, and produce structured diagnostics. No status is assigned based on witness-string presence.

### SMT bridge sample

The displayed bridge is a mock, not an SMT integration: it ignores the formula and infers outcomes from substrings such as `unsat`, `false` or `model_sat_witness`. It must not be linked into `kernc` except as an explicitly named fake test double. The real bridge needs process/API invocation, query-kind metadata, captured stdout/stderr, exit status, timeout/cancellation, solver/version/configuration hashes, parse of the actual solver response, and independent validation of models/certificates. Solver failure is `tool_error`; timeout is `timeout`; neither is F or B by itself.

### Binary emitter sample

The shown emitter is not production-safe:
- `std.mem.asBytes` writes host-native representation, not guaranteed canonical little-endian bytes;
- `BelnapVector32` represents only 32 statuses but appears to stand in for an arbitrary number of claims;
- offsets cast with `@intCast` require explicit overflow checks;
- offsets and lengths need range validation before reading;
- alignment in the shown routine is only 8 bytes in places, despite claims of 64-byte alignment;
- hash coverage and self-hash conventions must be specified precisely;
- creating/truncating a final output path directly can leave a torn snapshot on failure;
- casting an untrusted mmap pointer to a native struct assumes alignment/layout/endianness and bypasses validation.

Write canonical bytes explicitly, validate first, write to a temporary file, validate the completed artifact, then atomically publish it.

### C ABI example

A C ABI should expose fixed-width supported ABI types such as `uint8_t`/`uint32_t`, not Zig `u2` in exported function signatures. Validate that the numeric value is in `0..3` before decoding. The C header and Zig exports require an actual ABI integration test.

### Rust example

`transmute` is unnecessary for mapping a two-bit operation result to a four-variant enum. Prefer checked `match`/`TryFrom` logic; unsafe code increases the trusted computing base and is not justified here.

### Canonical report example

The proposed `99.4% VERIFIED`, `T` for a memory-alignment assertion, and named entropy/counterexample statuses are illustrative claims, not real project observations unless produced from a real scan and recorded check runs. Keep such material in explicitly `SYNTHETIC` examples. The canonical report generator must calculate all counts and make coverage denominators visible.

## Novelty and prior art check

The proposal's building blocks are not all new inventions:

- Proof-Carrying Code dates to George C. Necula, *Proof-Carrying Code*, POPL 1997: https://doi.org/10.1145/263699.263712
- Proof-Carrying Code Completions (PC³) is explicitly proposed in a UC Davis vision paper (ASE Workshops 2024): https://web.cs.ucdavis.edu/~cdstanford/doc/2024/ASEW24b.pdf and a research prototype is available at https://github.com/DavisPL/PCCC.
- Proof-Carrying Agent Actions (PCAA) has a 2026 arXiv preprint: https://arxiv.org/abs/2606.04104.
- Differential dataflow was published at CIDR 2013 and is implemented in the timely/differential-dataflow ecosystem: https://www.microsoft.com/en-us/research/publication/differential-dataflow/ and https://github.com/TimelyDataflow/differential-dataflow.
- Conformal prediction sets for deep generative models have a 2025 PMLR paper: https://proceedings.mlr.press/v286/shahrokhi25a.html.
- Linux memory mapping and HugeTLB behavior is documented in `mmap(2)` and kernel documentation: https://www.man7.org/linux/man-pages/man2/munmap.2.html and https://docs.kernel.org/admin-guide/mm/hugetlbpage.html.

Therefore KERN must not claim to have invented PC³, PCAA, differential dataflow, B4, PCC or conformal prediction. A research contribution may lie in the precise integrated semantics, implementation, incremental proof/evidence maintenance, canonical format, performance/safety results and comparative evaluation. Novelty requires a more exhaustive literature review.

## Additional mathematical corrections to the supplied equations

### Bilattice product and orders

The representation `B4 ≅ Bool × Bool` and the coordinatewise knowledge order are valid. The truth order reverses the negative-support coordinate. In this encoding the knowledge bottom is N and top is B; the truth bottom is F and top is T. Keep the order relations explicitly defined in tests, not only the operator names.

### A derivation DAG is not guaranteed by “finite hypergraph” alone

A finite directed graph can still contain cycles. The desired result follows only after the implementation enforces a strict rank/epoch relation on provenance edges, or rejects any cycle during commit. The condition must be checked by the validator/runtime; it is not automatic from the type `E ⊆ P(V) × V`.

### Complexity of bounded graph evaluation

A depth/fuel parameter decremented for each recursion level proves a depth bound, but if each visited node recursively explores multiple children it can still do exponentially many visits in the depth. Use one shared work budget charged for every node/edge/operation (plus explicit quotas for joins and host calls). The complexity bound is then tied to consumed work and bounded primitive operation costs, not simply `O(|U|·F)` without defining `U` and the cost model.

### The packed `u2` enum and struct layout

The value `enum(u2)` is useful for logical encoding but does not imply a portable raw-file layout for enclosing Zig structs. Struct padding, host endianness, pointer size and ABI rules must not be part of the canonical file representation. Use explicit wire-format readers/writers; compile-time size assertions can protect an in-memory optimization but do not replace format validation.

### Linear types and race freedom

Linear/affine types can constrain resource use under a specified type system, but they do not automatically establish thread-race freedom for an arbitrary runtime. The runtime needs a defined ownership/borrowing and concurrency model, synchronization rules, and tests/formal results at the relevant boundaries.

### Conformal coverage

Conformal prediction sets for generative models can provide statistical coverage under their calibration assumptions. This is not a logical truth value and not a formal proof that generated code is correct. Record the calibration set, admissibility predicate, exchangeability/sampling assumptions, target miscoverage level and empirical behavior separately from B4 and PC3 results.

### “Zero hallucinations” and “100% correct” must not be stated as guarantees

A policy can prevent an unverified candidate from being published through the controlled KERN path. It cannot stop a model from generating false text, guarantee correctness of an incomplete specification, or protect modifications made outside the controlled filesystem boundary. The security guarantee is scoped to the enforcement path and the checked property.
