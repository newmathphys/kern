# KERN Foundation v0.5

This package integrates the latest user proposal while correcting overclaims around proof-carrying code, differential deletion, memory mapping, HugePages, fuel, and anti-vacuity.

## Main files

- `KERN_FOUNDATION_SPEC_v0.5.md` — normative architectural and semantic contract.
- `TECHNICAL_AUDIT_USER_INPUT_v0.5.md` — line-by-line conceptual audit.
- `KERN_CONFORMANCE_TEST_PLAN_v0.5.md` — required test matrix.
- `docs/KERN_CANONICAL_MANIFEST_SPEC_v0.1.md` — generated human/machine manifest contract.
- `docs/KERN_PC3_ACCEPTANCE_v0.2.md` — staged proof-carrying completion.
- `docs/KERN_DIFFERENTIAL_SEMANTICS_v0.2.md` — evidence events and retractions.
- `docs/KERN_MEMORY_FORMAT_NOTES_v0.1.md` — mmap/relative-reference safety.
- `src/core/belnap_v05.zig`, `truth_gate_v05.zig`, `fuel_v05.zig`, `src/format/rel_ref_v05.zig`, `src/verifier/smt_result_v05.zig` — reference Zig modules.
- `formal/KernBelnapV05.lean` — intended finite algebra formalization; not compiled here.
- `tools/verify_foundation.py` — executable finite reference checks using Python standard library; not a substitute for Zig/Lean compilation.

## Run the reference checks

```bash
python3 tools/verify_foundation.py
```

Expected output says reference checks passed and explicitly warns that Zig/Lean are not compiled by this script.

## Important implementation status

This is a specification and prototype-source package. A native `kernc` compiler, real SMT integration, `.kbin` reader/writer, differential runtime, LSP and PC3 proof checker remain implementation tasks. Do not label any of them completed until code is built and tested with pinned toolchain versions.
