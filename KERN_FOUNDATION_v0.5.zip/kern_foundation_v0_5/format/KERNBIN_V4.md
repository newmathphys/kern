# KERN `.kbin` v4 wire-format draft

**Status:** format contract for implementation; not yet accompanied by a native reader/writer.

## Wire invariants

- Magic: ASCII `KERN`.
- Canonical integer byte order: little-endian.
- Fixed header size: 128 bytes.
- Section descriptor size: 40 bytes.
- 64-bit unsigned offsets and lengths in the file directory.
- Record references use two independent 32-bit fields: `chunk_id:u32`, `offset:u32`.
- A chunk has an implementation-declared maximum size; for 2 MiB chunks, `offset:u32` is ample. Chunking is not encoded as `u12 + u20` because that would make the offset only 1 MiB and cannot represent a 2 MiB in-chunk offset.
- The file is immutable while any reader maps it. New snapshots are written to a temporary file and atomically published by rename.
- Digest algorithm and scope are identified in the header. Digest is checked before a parsed view is trusted.

## Header fields (byte offsets)

| Offset | Width | Field |
|---:|---:|---|
| 0 | 4 | magic `KERN` |
| 4 | 2 | major format version, LE |
| 6 | 2 | minor format version, LE |
| 8 | 4 | header size (128), LE |
| 12 | 4 | flags; unknown mandatory flags reject |
| 16 | 8 | file size, LE |
| 24 | 8 | section directory offset, LE |
| 32 | 4 | section count, LE |
| 36 | 4 | target/layout profile id |
| 40 | 32 | BLAKE3 root digest of canonical payload according to this format version |
| 72 | 32 | snapshot content/root identity digest |
| 104 | 8 | build epoch/snapshot sequence, LE |
| 112 | 8 | reserved, must be zero in v4.0 |
| 120 | 8 | reserved, must be zero in v4.0 |

## Section descriptor (40 bytes)

| Offset | Width | Field |
|---:|---:|---|
| 0 | 4 | section type id |
| 4 | 4 | flags |
| 8 | 8 | offset |
| 16 | 8 | stored length |
| 24 | 8 | logical record count |
| 32 | 4 | alignment requirement (power of two, >= 1) |
| 36 | 4 | schema version |

Section types must be registered. Unknown optional sections may be skipped; unknown mandatory sections reject. Section ranges must be within the file and must not overlap the header or directory or illegally overlap another section. Check `offset <= file_size` before checking `length <= file_size - offset`; never rely on `offset + length` without overflow checking.

## Chunk references

`RelRef = { chunk_id:u32, offset:u32 }` is a wire-level pair, not a native pointer. The reader validates:

1. `chunk_id < chunk_count`;
2. `offset < chunk.logical_length` (unless a null/sentinel reference is explicitly defined);
3. record header and complete payload fit within that chunk;
4. the record's alignment and schema requirements;
5. the referenced record ID/type matches the reference's declared type.

No reference is dereferenced through an unchecked cast. Use accessors that decode little-endian bytes after validating bounds. On a little-endian target, aligned immutable sections may expose typed read-only views only if the layout is explicitly specified as ABI-independent and all validation passes. Big-endian targets must decode fields or use a canonical accessor path; claiming both direct native typed views and zero-conversion big-endian support is not valid simultaneously.

## Alignment and huge pages

Logical format alignment is limited to the alignment declared by each section and record schema. 64-byte placement may be selected by an encoder profile for hot arrays, but is not a semantic requirement. Huge pages are a runtime mapping optimization only; the file format does not require HugeTLB/THP.

## Safe publication

1. Create a unique temporary file in the target directory.
2. Write header placeholder, directory and sections.
3. Flush user-space buffers and request file sync when durability policy requires it.
4. Compute and write canonical payload digest/header.
5. Reopen/read back and validate the written image in tests.
6. Atomically rename the file into its published snapshot name.
7. Readers open a published immutable version and keep that file identity until unmapping.

This avoids mutating/truncating a file while another process has mapped it. Atomic rename semantics and durability behavior are OS/filesystem-dependent and must be tested on supported targets.

## Integrity is not authenticity

BLAKE3 detects accidental/corrupt changes with high probability; it does not authenticate an artifact against a malicious writer unless keyed hashing or a signature with a separately managed trust key is used. Do not confuse content identity with provenance authenticity.
