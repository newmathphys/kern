#!/usr/bin/env python3
"""Independent standard-library reference checks for KERN v0.5.

This is not a proof assistant and does not compile or validate the Zig/Lean files.
It exhaustively checks finite Belnap FOUR identities and several reference policies.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class B4(IntEnum):
    N = 0b00
    T = 0b01
    F = 0b10
    B = 0b11

    @property
    def p(self) -> bool:
        return bool(int(self) & 1)

    @property
    def n(self) -> bool:
        return bool(int(self) & 2)

    @classmethod
    def from_pn(cls, p: bool, n: bool) -> "B4":
        return cls((int(n) << 1) | int(p))

    def neg(self) -> "B4":
        return B4.from_pn(self.n, self.p)

    def and_t(self, b: "B4") -> "B4":
        return B4.from_pn(self.p and b.p, self.n or b.n)

    def or_t(self, b: "B4") -> "B4":
        return B4.from_pn(self.p or b.p, self.n and b.n)

    def join_k(self, b: "B4") -> "B4":
        return B4.from_pn(self.p or b.p, self.n or b.n)

    def meet_k(self, b: "B4") -> "B4":
        return B4.from_pn(self.p and b.p, self.n and b.n)

VALUES = tuple(B4)

def leq_k(a: B4, b: B4) -> bool:
    return (not a.p or b.p) and (not a.n or b.n)

def leq_t(a: B4, b: B4) -> bool:
    return (not a.p or b.p) and (not b.n or a.n)

def assert_lattice(less_equal, meet, join, values, label):
    for a in values:
        for b in values:
            m, j = meet(a, b), join(a, b)
            assert less_equal(m, a) and less_equal(m, b), (label, "meet lower bound", a, b, m)
            assert less_equal(a, j) and less_equal(b, j), (label, "join upper bound", a, b, j)
            for z in values:
                if less_equal(z, a) and less_equal(z, b):
                    assert less_equal(z, m), (label, "greatest lower bound", z, a, b, m)
                if less_equal(a, z) and less_equal(b, z):
                    assert less_equal(j, z), (label, "least upper bound", a, b, j, z)
    for a in values:
        for b in values:
            for c in values:
                assert meet(a, join(b, c)) == join(meet(a, b), meet(a, c)), (label, "meet distributes over join", a, b, c)
                assert join(a, meet(b, c)) == meet(join(a, b), join(a, c)), (label, "join distributes over meet", a, b, c)

@dataclass(frozen=True)
class GateInput:
    value: B4
    coverage_complete: bool
    policy_present: bool
    provenance_complete: bool
    checker_succeeded: bool
    scope_resolved: bool
    input_hash_matches: bool

def admit(g: GateInput) -> tuple[bool, bool]:
    """Return (admitted, enqueue_conflict_resolution)."""
    if g.value == B4.B:
        return False, True
    return (
        g.value == B4.T and g.coverage_complete and g.policy_present
        and g.provenance_complete and g.checker_succeeded
        and g.scope_resolved and g.input_hash_matches,
        False,
    )

def check_belnap():
    assert tuple(int(v) for v in VALUES) == (0, 1, 2, 3)
    for a in VALUES:
        assert a.neg().neg() == a
        assert a.join_k(B4.N) == a
        assert a.meet_k(B4.B) == a
        assert a.and_t(B4.T) == a
        assert a.or_t(B4.F) == a
        assert a.join_k(a) == a
        assert a.meet_k(a) == a
        for b in VALUES:
            assert a.join_k(b) == b.join_k(a)
            assert a.meet_k(b) == b.meet_k(a)
            assert a.and_t(b) == b.and_t(a)
            assert a.or_t(b) == b.or_t(a)
            assert a.join_k(b) == B4.from_pn(a.p or b.p, a.n or b.n)
            assert a.meet_k(b) == B4.from_pn(a.p and b.p, a.n and b.n)
            assert a.neg().and_t(b.neg()) == a.or_t(b).neg()
            assert a.neg().or_t(b.neg()) == a.and_t(b).neg()
    assert B4.T.join_k(B4.F) == B4.B
    assert B4.T.and_t(B4.F) == B4.F
    assert B4.N.or_t(B4.T) == B4.T
    assert B4.B.and_t(B4.T) == B4.B
    assert_lattice(leq_k, B4.meet_k, B4.join_k, VALUES, "knowledge")
    assert_lattice(leq_t, B4.and_t, B4.or_t, VALUES, "truth")
    vectors = []
    for a in VALUES:
        for b in VALUES:
            vectors.append({
                "a": a.name, "b": b.name,
                "not_a": a.neg().name,
                "and_t": a.and_t(b).name,
                "or_t": a.or_t(b).name,
                "join_k": a.join_k(b).name,
                "meet_k": a.meet_k(b).name,
            })
    (ROOT / "tests/v0.5/belnap_vectors_exhaustive.json").write_text(
        json.dumps(vectors, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert len(vectors) == 16
    return len(vectors)

def check_gate():
    base = GateInput(B4.T, True, True, True, True, True, True)
    assert admit(base) == (True, False)
    for field in ("coverage_complete", "policy_present", "provenance_complete", "checker_succeeded", "scope_resolved", "input_hash_matches"):
        kwargs = base.__dict__.copy()
        kwargs[field] = False
        assert admit(GateInput(**kwargs)) == (False, False), field
    assert admit(GateInput(B4.N, True, True, True, True, True, True)) == (False, False)
    assert admit(GateInput(B4.F, True, True, True, True, True, True)) == (False, False)
    assert admit(GateInput(B4.B, True, True, True, True, True, True)) == (False, True)

def check_delta_retraction():
    """Reference semantics: retract a specific active contribution, then recalc bits."""
    events = {
        "ev-test-pass": {"polarity": "positive", "active": True},
        "ev-smt-counterexample": {"polarity": "negative", "active": True},
    }
    def status():
        return B4.from_pn(
            any(e["active"] and e["polarity"] == "positive" for e in events.values()),
            any(e["active"] and e["polarity"] == "negative" for e in events.values()),
        )
    assert status() == B4.B
    events["ev-smt-counterexample"]["active"] = False
    assert status() == B4.T
    events["ev-test-pass"]["active"] = False
    assert status() == B4.N

def check_relative_ranges():
    def valid(chunk_len: int, off: int, length: int, alignment: int) -> bool:
        return (alignment > 0 and alignment & (alignment - 1) == 0
                and off <= chunk_len and length <= chunk_len - off and off % alignment == 0)
    assert valid(1024, 64, 64, 8)
    assert not valid(1024, 1025, 0, 1)
    assert not valid(1024, 1000, 25, 1)
    assert not valid(1024, 3, 8, 8)

def check_schema_json():
    # Parse all JSON files and confirm key schema files are valid JSON.
    json_files = sorted(ROOT.rglob("*.json"))
    parsed = 0
    for path in json_files:
        # Exclude archived package content only if any future archive is unzipped here.
        json.loads(path.read_text(encoding="utf-8"))
        parsed += 1
    return parsed

def main():
    try:
        n = check_belnap()
        check_gate()
        check_delta_retraction()
        check_relative_ranges()
        json_count = check_schema_json()
    except Exception as exc:
        print(f"KERN v0.5 reference check: FAIL: {exc}", file=sys.stderr)
        return 1
    print("KERN v0.5 reference check: PASS")
    print(f"Belnap operation vectors: {n} input pairs × 5 outputs")
    print("Knowledge/truth lattice laws: PASS (finite exhaustive checker)")
    print("Truth-gate cases: PASS")
    print("Evidence retraction cases: PASS")
    print("Relative-reference bounds cases: PASS")
    print(f"JSON files parsed: {json_count}")
    print("NOTE: this does not compile Zig/Lean or prove the full engine correct.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
