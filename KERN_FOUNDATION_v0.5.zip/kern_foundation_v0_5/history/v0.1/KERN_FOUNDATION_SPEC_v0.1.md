# KERN Foundation Specification v0.1

**Status:** Draft for implementation  
**Language family:** KERN-D (declarative project/evidence language)  
**Native implementation target:** Zig 0.17.0, explicitly version-pinned per build  
**Text encoding:** UTF-8  
**Source extension:** `.kern`  
**Canonical local catalog:** `.kdb` (SQLite)  
**Portable snapshot:** `.kbin`  

## 1. Scope and non-goals

KERN-D is a typed declarative language for representing project artifacts, symbols, claims, observations, evidence, verification runs, proofs, metrics, relations, decisions, blockers, questions, snapshots, and cache metadata. It compiles into a canonical project graph and reproducible reports.

KERN-D v0.1 is deliberately **not Turing-complete** and does not execute arbitrary user code during parsing, validation, or build. This is a safety and determinism boundary, not a limitation on the eventual system: a future, separately specified KERN-X execution extension may provide controlled computation. A `.kern` file must never trigger shell execution, network requests, dynamic library loading, or arbitrary filesystem writes merely by being opened or built.

This specification defines format and semantics; it does not claim that a production Zig compiler already exists. The reference implementation must pass the conformance fixtures in this package before it is described as conforming.

## 2. Normative terminology

The words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are normative requirements.

- **Artifact:** an identifiable file, directory, dataset, binary, log, source excerpt, or external resource.
- **Claim:** an atomic proposition about the project.
- **Observation:** data directly recorded by a named source or operation.
- **Evidence:** a source or observation offered in relation to a claim.
- **Verification run:** a recorded invocation of a checker, test, compiler, experiment, or other verification method.
- **Verdict:** a result computed by the verifier, not an arbitrary value supplied by a model.
- **Proof:** a formal derivation accepted by a specified proof checker under recorded assumptions.
- **Relation:** a typed, directed edge between two identified entities.
- **Provenance:** the chain from source data through transformations to a derived result.
- **Snapshot:** an immutable logical view of a particular corpus state.
- **Cache entry:** a reusable derived result keyed by all inputs that affect it.

## 3. Language layers

### 3.1 KERN-D

The v0.1 normative language. It declares entities, fields, links, imports, and restricted predicates. It is data, not a program.

### 3.2 KERN-X (reserved, not specified in v0.1)

A future execution extension. Its syntax, capabilities, resource budgets, sandbox semantics, determinism, and failure model require a separate specification. The v0.1 parser MUST reject `exec`, `shell`, `eval`, `plugin`, or other unknown executable declarations rather than guessing their meaning.

### 3.3 Native engine

The Zig executable `kernc` implements parsing, normalization, type checking, link resolution, graph construction, persistence, cache validation, snapshotting, diffing, and export. Native implementation language is not part of KERN-D semantics.

## 4. Lexical model

1. Source files MUST be UTF-8. Invalid UTF-8 is a diagnostic; it must not be silently replaced.
2. Newlines are LF or CRLF. Line/column positions are one-based. Column counting is Unicode-scalar-based in diagnostics, with byte offsets also preserved.
3. `#` starts a line comment outside string literals.
4. Strings use double quotes. Supported escapes are `\\`, `\"`, `\n`, `\r`, `\t`, and `\u{HEX}`. Invalid escapes are errors.
5. Identifiers start with ASCII letter or `_`, followed by ASCII letters, digits, `_`, or `-`. Identifiers are case-sensitive. A declaration ID is quoted in source but MUST conform to this identifier grammar in v0.1; this keeps references unambiguous. File paths belong in fields such as `path`, never in entity IDs.
6. Keywords are recognized only in grammar positions; an identifier used as a string value must be quoted unless it is a defined enum literal.
7. Integer and decimal literals are parsed exactly as decimal lexemes. The parser MUST NOT silently convert decimal literals to binary floating-point. Numeric evaluation requires explicit type/range rules.
8. Booleans are `true` and `false`; null is `null`.
9. The operators `=`, `->`, `@`, `{`, `}`, `[`, `]`, `(`, `)`, `,`, `;`, `.`, comparison operators, and expression keywords are tokens.

## 5. Core grammar

The complete EBNF is in `KERN_GRAMMAR_v0.1.ebnf`. The core is:

```kern
project "example" {
  version = "0.1.0"
  root = "."
}

artifact "source.main" {
  path = "src/main.zig"
  kind = source
}

claim "claim_build" {
  statement = "The project builds with the recorded toolchain."
  claim_kind = execution_result
  declared_state = hypothesis
  sources = [@artifact.source_main]
}

link @claim.claim_build -> @artifact.source_main {
  type = supported_by
}
```

### 5.1 Declarations

A declaration has the form `KIND STRING { FIELD* }`. The string is the stable local ID for that entity kind. The field block is terminated by `}`. Field assignments use `key = value`; semicolons MAY be used after assignments. Repeated field keys are an error unless the schema explicitly declares that field repeatable. Prefer arrays for multi-valued fields.

### 5.2 Includes

`include "relative/path.kern"` includes another KERN-D source. Paths resolve relative to the including file and MUST remain inside the configured project root after canonicalization. Include cycles are errors. Include order does not change entity identity or semantics. Repeated inclusion of the same canonical file is de-duplicated within one compilation unit and recorded in diagnostics/provenance.

### 5.3 References

A reference is `@KIND.ID`, e.g. `@artifact.source_main`. References use the declared entity kind and ID. An unresolved reference produces a diagnostic and unresolved-reference record; it MUST NOT be silently converted to a string or guessed from a basename.

### 5.4 Relations

A relation uses `link SOURCE -> TARGET { type = RELATION_TYPE }`. Both ends are typed references. Multiple edges between the same pair are allowed. A self-edge is allowed only if the relation registry explicitly permits it; otherwise it is a semantic error.

## 6. Primitive types and values

KERN-D v0.1 supports:

- `String`: UTF-8 text;
- `Bool`: true/false;
- `Null`;
- `Int`: signed 64-bit integer when a schema field requires Int;
- `Decimal`: exact base-10 numeric lexeme retained canonically;
- `Array<T>`: ordered homogeneous or schema-defined heterogeneous values;
- `Object`: string-keyed map with unique keys;
- `Reference<K>`: typed reference to entity kind K;
- `Enum<E>`: value from a registry for the respective field.

The general parser preserves number lexemes until schema-directed type checking. Overflow is a diagnostic, never wraparound. Arrays preserve order. Object key order is not semantically significant; canonical serialization sorts object keys by UTF-8 byte order.

## 7. Core entity schemas

All entities have a stable `id`, a `kind`, source provenance, and an internal deterministic entity key. Declaration ID is the string immediately after the entity kind. Duplicate `(kind, id)` pairs are fatal semantic errors unless an explicit future merge construct is used.

### 7.1 `project`
Required fields: `version: String`, `root: String`. Optional: `description: String`, `tags: Array<String>`, `policy: Reference<policy>`.

### 7.2 `artifact`
Required: `path: String`, `kind: Enum<artifact_kind>`. Optional: `sha256: String`, `size_bytes: Int`, `media_type: String`, `language: String`, `external_uri: String`, `status_note: String`.

`path` is relative to project root unless `external_uri` is explicit. A file's current content hash is an observation made by the engine, not proof that historical contents were identical.

### 7.3 `module`
Required: `purpose: String`. Optional: `path: String`, `language: String`, `entrypoints: Array<String>`, `depends_on: Array<Reference<module>>`.

### 7.4 `symbol`
Required: `name: String`, `symbol_kind: Enum<symbol_kind>`, `artifact: Reference<artifact>`. Optional: `signature: String`, `start_line: Int`, `end_line: Int`, `visibility: Enum<visibility>`.

### 7.5 `claim`
Required: `statement: String`, `claim_kind: Enum<claim_kind>`. Optional: `declared_state: Enum<declared_state>`, `scope: String`, `assumptions: Array<String>`, `limitations: Array<String>`, `sources: Array<Reference<artifact>>`.

A claim's declaration may record what a source or human asserts. It MUST NOT directly set the engine's computed `verdict` or `e` value. These are computed in verification records.

### 7.6 `evidence`
Required: `evidence_kind: Enum<evidence_kind>`, `source: Reference<artifact>`. Optional: `location: String`, `sha256: String`, `excerpt_hash: String`, `observation: String`, `execution: Reference<execution>`.

Evidence establishes that a source or observation exists and what it contains; its sufficiency for a claim is determined by the verification policy.

### 7.7 `execution`
Required: `operation: String`, `execution_kind: Enum<execution_kind>`. Optional: `command: Array<String>`, `exit_code: Int`, `started_at: String`, `finished_at: String`, `environment_fingerprint: String`, `stdout_artifact: Reference<artifact>`, `stderr_artifact: Reference<artifact>`, `result_artifact: Reference<artifact>`.

A declaration is not a runtime record by itself. The engine marks it observed only after collecting execution evidence from a real run or a trusted imported log.

### 7.8 `proof`
Required: `system: String`, `source: Reference<artifact>`, `proof_kind: Enum<proof_kind>`. Optional: `theorem: String`, `assumptions: Array<String>`, `checker_version: String`, `execution: Reference<execution>`.

### 7.9 `metric`
Required: `name: String`, `value: Decimal | Int`, `unit: String`. Optional: `sample_count: Int`, `method: String`, `context: Object`, `variance: Decimal`, `confidence_interval: Array<Decimal>`.

### 7.10 `decision`
Required: `choice: String`, `rationale: String`. Optional: `alternatives: Array<String>`, `evidence: Array<Reference<evidence>>`, `reversal_condition: String`.

### 7.11 `blocker`
Required: `reason: String`, `blocker_state: Enum<blocker_state>`. Optional: `impact: String`, `next_step: String`, `evidence: Array<Reference<evidence>>`.

### 7.12 `question`
Required: `question: String`. Optional: `importance: Enum<importance>`, `related: Array<Reference<claim>>`, `needed_evidence: Array<String>`.

### 7.13 `snapshot`
Required: `snapshot_kind: Enum<snapshot_kind>`, `root_hash: String`. Optional: `parent: Reference<snapshot>`, `created_at: String`, `engine_version: String`.

### 7.14 `invariant`
Required: `expression: Expression`, `scope: String`. Optional: `severity: Enum<severity>`, `description: String`.

## 8. Enumeration registries

Initial enums are versioned and extensible only through explicit registry updates:

- `artifact_kind`: `source`, `document`, `test`, `proof`, `log`, `dataset`, `configuration`, `binary`, `model`, `database`, `report`, `unknown`.
- `claim_kind`: `existence`, `content`, `execution_result`, `correctness`, `mathematical_theorem`, `benchmark`, `causal`, `security`, `architecture`, `history`, `decision`, `other`.
- `declared_state`: `asserted`, `hypothesis`, `retracted`, `unknown`.
- `evidence_kind`: `source_excerpt`, `hash_observation`, `test_result`, `build_result`, `proof_checker_result`, `measurement`, `external_primary_source`, `execution_log`, `human_attestation`, `other`.
- `execution_kind`: `scan`, `test`, `build`, `benchmark`, `proof_check`, `static_analysis`, `migration`, `other`.
- `proof_kind`: `formal`, `symbolic`, `numerical`, `empirical`, `informal`.
- `visibility`: `public`, `internal`, `private`, `unknown`.
- `blocker_state`: `open`, `in_progress`, `resolved`, `accepted_risk`.
- `importance`: `low`, `normal`, `high`, `critical`.
- `snapshot_kind`: `full`, `incremental`, `imported`.
- `severity`: `info`, `warning`, `error`, `fatal`.

Unknown enum literals MUST be rejected in strict mode. A future-compatible mode MAY retain them as unresolved extension values but MUST NOT assign semantics to them.

## 9. Expression semantics

KERN-D expressions are pure and bounded. The initial expression language supports literals, references, field access, `not`, `and`, `or`, `==`, `!=`, `<`, `<=`, `>`, `>=`, `in`, and a registry of pure built-ins such as `exists(ref)`, `count(collection)`, and `has_relation(source, type, target)`.

- Boolean operators require Bool operands.
- Comparisons require compatible types; no implicit text-to-number coercion is allowed.
- `and`/`or` use short-circuit evaluation.
- Missing field/reference yields a typed `Unknown` result, not false by default.
- Arithmetic is not in the v0.1 expression core. It may be added through a versioned extension with exact overflow and numeric semantics.
- Expressions MUST NOT perform filesystem, network, clock, randomness, or process operations.
- Invariants evaluating to `Unknown` are unresolved diagnostics, not passes.

## 10. Truth and verdict model

`e` is a computed acceptance gate, not a confidence score and not a user-authored property.

For every claim, the engine stores:

- `declared_state`: what the source says;
- `verdict`: computed `proven`, `refuted`, `verified`, `tested`, `compiled`, `empirical`, `hypothesis`, `blocked`, `unknown`, or `not_yet_reproducible`;
- `e`: integer `0` or `1`;
- `verification_policy_id`;
- `evidence_ids`;
- `diagnostic_ids`.

`e=1` is permitted only if the claim's typed verification policy passes and provenance requirements are met. No source-level declaration can force `e=1`. A file existence claim requires an actual filesystem observation; a build claim requires a recorded build; a theorem claim requires evidence of the specified proof checker accepting the theorem under recorded assumptions; a benchmark claim requires measurement inputs and method. One universal evidence rule is forbidden.

`verdict=proven` is reserved for proof obligations whose declared proof policy is satisfied. Test success is not a proof of whole-program correctness. If sources conflict or required evidence is absent, `e=0` and the unresolved state must be retained.

## 11. Identity and canonicalization

- Entity identity is `(project_id, kind, local_id)`; path is not a stable identity because files can move.
- File content is identified by SHA-256 of exact bytes.
- Normalized derived payloads use a versioned canonical encoding.
- Array order is preserved; object keys are sorted for canonical output.
- Timestamps are metadata, not identity.
- IDs MUST NOT be silently reassigned on incremental rebuild.
- If an artifact moves, record a move relation where safely inferred; preserve old snapshot identity.

## 12. Dependency and invalidation semantics

The project graph is a directed multigraph. An edge has `source`, `target`, `type`, `origin`, `confidence_class`, `source_location`, and `status`.

On artifact change, invalidate all derived cache entries whose dependency key includes that artifact's new hash. Do not invalidate unrelated entries. Cache keys MUST include every semantically relevant input, including parser/compiler version, schema version, configuration, transitive dependency hashes, method version, model ID/version where a model was called, prompt/template hash, and relevant source references.

A cached result is reusable only if every required dependency key matches. Cached AI output is a derived claim or suggestion, never primary evidence by itself.

## 13. Storage and formats

### 13.1 SQLite `.kdb`
SQLite is the indexed local catalog. It stores entities, edges, source locations, diagnostics, verification runs, snapshots, cache entries, schema/compiler versions, and FTS index where FTS5 is available. Database transactions must be atomic. Enable foreign keys and configure journaling explicitly.

### 13.2 KERN-Blob `.kbin`
`.kbin` is a portable snapshot container; it is not the live query engine. All multi-byte integers are unsigned or signed as declared and little-endian. All offsets are absolute byte offsets from the beginning of the file. The format uses SHA-256 for integrity.

#### Header (exactly 80 bytes)

| Offset | Width | Field | Rule |
|---:|---:|---|---|
| 0 | 8 | `magic` | Bytes `KERNKB1\0` |
| 8 | 2 | `major` | `1` for v0.1 container family |
| 10 | 2 | `minor` | `0` for v0.1 container layout |
| 12 | 4 | `header_size` | Must be `80` |
| 16 | 4 | `flags` | Unknown bits MUST be zero in v0.1 |
| 20 | 4 | `section_count` | Number of section records |
| 24 | 4 | `reserved0` | Must be zero |
| 28 | 8 | `section_table_offset` | Usually `80`; 8-byte aligned |
| 36 | 8 | `file_size` | Must equal actual file length |
| 44 | 32 | `manifest_sha256` | SHA-256 over raw section-table bytes in stored order |
| 76 | 4 | `reserved1` | Must be zero |

#### Section table record (exactly 64 bytes)

| Field | Width | Rule |
|---|---:|---|
| `tag` | 4 bytes | ASCII uppercase tag |
| `flags` | 4 bytes | Bit 0 = REQUIRED; all other bits zero in v0.1 |
| `offset` | 8 bytes | Absolute section start; 8-byte aligned |
| `length` | 8 bytes | Exact stored byte length |
| `sha256` | 32 bytes | SHA-256 of exact section payload bytes |
| `reserved` | 8 bytes | Must be zero |

The section table has `section_count * 64` bytes. In v0.1, sections are uncompressed, so stored length equals uncompressed length. Header, table, and section ranges MUST NOT overlap. Every addition/multiplication used to calculate a range MUST be checked for integer overflow before use. A section must be inside `[0, file_size)`. Section hashes are verified before records are consumed. `manifest_sha256` is verified before accepting the table.

If an unknown section has REQUIRED set, the reader MUST fail with `unsupported_required_section`; otherwise it MAY skip the section after bounds and hash checks. Unknown section tags are not interpreted. Duplicate section tags are rejected in v0.1. Records within sections use an explicit versioned encoding defined by the relevant section schema; readers MUST NOT cast arbitrary bytes to native Zig structs.

Initial section tags: `STRS`, `OBJS`, `RELS`, `CLMS`, `EVID`, `EXEC`, `METR`, `DIAG`, `CACH`, `SRCS`, `INDX`. Section order is canonical lexicographic tag order in canonical builds. Compression is postponed until a versioned codec registry exists.

### 13.3 JSONL
JSONL is the streaming interchange format. One complete UTF-8 JSON object per line. Invalid records are reported with line numbers. No single line may be silently truncated.

### 13.4 Human report
Markdown is derived output. It is never the canonical database.

## 14. Memory and resource semantics of the Zig engine

- Every long-lived allocation has explicit ownership and release policy.
- Compiler phases should use per-invocation arenas where appropriate; persistent objects are copied into owned storage before arena release.
- No reference into temporary parser buffers may survive past their lifetime.
- File processing should be stream-oriented where practical; an implementation MAY impose configurable resource limits, but any limit must be recorded in the run manifest and unprocessed inputs must be enumerated.
- “Unlimited” mode means no arbitrary PTE count/depth/truncation limit; it does not mean infinite RAM, disk, execution time, OS permissions, or infinite file size.
- For SQLite, reads may be concurrent subject to the chosen SQLite/runtime configuration; use one coordinated writer per database unless the implementation documents and tests a different safe model.

## 15. Error model

Every diagnostic contains `code`, `severity`, `message`, `source_uri`, `byte_start`, `byte_end`, `line`, `column`, `phase`, and optional `entity_id`/`related_diagnostics`.

Minimum codes: `invalid_utf8`, `parse_error`, `duplicate_id`, `unknown_kind`, `unknown_field`, `invalid_type`, `invalid_enum`, `unresolved_reference`, `include_cycle`, `include_outside_root`, `hash_mismatch`, `missing_evidence`, `policy_failed`, `contradiction`, `cache_stale`, `corrupt_kbin`, `section_bounds`, `permission_denied`, `unsupported_format`, `resource_exhausted`.

Fatal parse/format errors must prevent publishing a supposedly valid complete snapshot. Partial results MAY be emitted but must be marked partial and accompanied by diagnostics.

## 16. Security requirements

- Parsing `.kern` must be inert.
- No network access occurs by default.
- No secrets are copied to handoff packets or ordinary reports.
- Symlink traversal, path traversal, include escapes, malformed lengths, decompression bombs, and corrupt hashes must be detected.
- External AI requests require explicit caller authorization and a recorded data-egress policy.
- Test execution is a separate command, never an implicit side effect of `build`.

## 17. Determinism and reproducibility

Canonical output order is: entity kind, entity ID, field key, then edge source/type/target. A deterministic build over the same canonical inputs and tool versions should produce identical canonical records and manifest hashes. Wall-clock timestamps and non-deterministic logs must be separated from canonical semantic content.

Every verification run records tool name/version, input hashes, command/parameters, start/end time if available, exit result, raw log artifact and environment fingerprint.

## 18. Conformance classes

- **Parser-conforming:** lexes and parses valid fixtures, rejects invalid syntax with source locations.
- **Semantic-conforming:** type checks entities, validates refs and expressions, enforces status/e rules.
- **Storage-conforming:** round-trips canonical records through SQLite and `.kbin`, validates bounds/hashes.
- **Incremental-conforming:** invalidates affected cache entries and preserves unaffected results for unchanged dependencies.
- **Handoff-conforming:** emits a schema-valid agent packet with stable references and explicit unknowns.
- **Full-conforming:** passes every test suite above and emits conformance report with implementation/toolchain versions.

A compiler MUST declare exactly which conformance classes have passed. Passing parser tests alone is not full conformance.

## 19. Versioning

KERN language version is `major.minor.patch`. A change that alters syntax, typing, truth semantics, canonical serialization, ID semantics, or `.kbin` layout incompatibly requires a major version or explicitly versioned format section. Additive fields and optional sections can be minor changes if old compilers safely reject or preserve them according to strict/future-compatible mode. Bug fixes preserving semantics are patch changes.

## 20. Implementation target and build record

The language semantics are independent of Zig's syntax and library APIs. The reference engine should pin and report an exact Zig compiler version and target triple. The specification package targets Zig 0.17.0 as the current stable release at the specification date; build compatibility must be checked with the official release notes rather than assuming source compatibility across Zig versions.

## 21. Minimal complete example

See `examples/project.kern`. A conforming parser must produce stable entity IDs, typed edges, source locations, and no computed `e=1` unless verification records exist.

## 22. Open items deliberately postponed

- Complete KERN-X executable extension and sandbox ABI.
- Custom arithmetic and query planner beyond core expressions.
- Signed `.kbin` manifests and key management.
- Compression codec registry.
- Distributed multi-writer database protocol.
- Standardized embedding/vector index ABI.
- Cross-language code symbol extraction beyond implemented parsers.

These are explicit extension points, not implied existing capabilities.
