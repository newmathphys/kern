# KERN-D v0.1 conformance test plan

A real compiler implementation must execute these tests. The fixtures in this package are test inputs, not proof that a compiler exists.

## Positive tests

1. Parse `tests/valid/minimal.kern` successfully.
2. Preserve UTF-8 strings and line/column/byte positions.
3. Resolve `@artifact.a` to exactly `(artifact, a)`.
4. Preserve array order and normalize object-key order.
5. Emit no computed `e=1` in the absence of a recorded verification.
6. Re-compile the same inputs into identical canonical semantic records.
7. Round-trip records through SQLite and `.kbin` without changing stable IDs.

## Negative tests

1. Reject duplicate `(kind,id)` pairs (`tests/invalid/duplicate-id.kern`).
2. Reject unknown strict enum value (`tests/invalid/unknown-status.kern`).
3. Reject an unterminated string.
4. Reject malformed UTF-8.
5. Reject an include escaping the project root.
6. Reject include cycles.
7. Report unresolved references; do not silently resolve by basename.
8. Reject incompatible comparisons in expressions.
9. Produce `Unknown`, not false, for missing fields where the expression rules say Unknown.
10. Reject `.kbin` sections whose offsets overflow, overlap, or exceed file size.
11. Reject any attempt to author `e` or a computed `verdict` directly in a claim.
12. Ensure `.kern` build does not execute shell code or access network.

## Incremental/cache tests

1. Unchanged dependency keys produce a cache hit.
2. Changing an input hash invalidates every dependent derived result.
3. Changing unrelated files does not invalidate unrelated cached records.
4. Updating compiler, schema, extraction method, model ID/version, prompt hash or transitive dependency hashes invalidates affected results.
5. A failed run never replaces the last valid snapshot with a falsely complete snapshot.

## Required report fields

`compiler_version`, `language_version`, `target`, `tests_discovered`, `tests_run`, `tests_passed`, `tests_failed`, `tests_skipped`, `diagnostics`, `conformance_classes_passed`.
