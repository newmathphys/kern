# KERN Foundation v0.1 package

This package is the formal design/specification, not a claim that a production compiler already exists.

## Files

- `KERN_FOUNDATION_SPEC_v0.1.md` — normative language and semantic specification.
- `KERN_GRAMMAR_v0.1.ebnf` — core EBNF grammar.
- `kern_spec_v0.1.json` — machine-readable specification manifest.
- `examples/project.kern` — example source file.
- `tests/valid/` and `tests/invalid/` — parser/semantic conformance fixtures.
- `CONFORMANCE_TEST_PLAN.md` — expected behaviors and failure cases.
- `decisions/` — architecture decisions that are binding for v0.1.

## Current implementation status

- Spec package: authored.
- Zig compiler: not included in this package yet.
- Compiler conformance tests: specified as fixtures; they are not claimed to have passed against a Zig compiler.
- Implementation target: Zig 0.17.0, with exact toolchain version recorded in every build manifest.

## First implementation milestone

Implement lexer/parser and source-located diagnostics in Zig, then pass every parser fixture before adding SQLite, `.kbin`, graph resolution, and cache invalidation.
