# ADR-0001: Declarative KERN-D core; execution is a separate extension

- **Status:** Accepted for v0.1
- **Decision:** Opening, parsing, validating, or building a `.kern` file cannot execute arbitrary code, access the network, or write to the target project.
- **Reason:** The project engine must safely inspect unknown projects and create reproducible snapshots. Implicit execution makes inspection unsafe and non-deterministic.
- **Trade-off:** Automation requires an explicitly invoked runner or a future separately specified KERN-X extension.
- **Reversal condition:** A future version may add an execution layer only with a sandbox model, capability declaration, resource budget, deterministic I/O contract, and separate conformance tests.
