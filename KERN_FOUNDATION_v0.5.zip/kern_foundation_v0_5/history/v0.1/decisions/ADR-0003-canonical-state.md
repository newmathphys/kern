# ADR-0003: One canonical catalog, multiple derived outputs

- **Status:** Accepted for v0.1
- **Decision:** The indexed semantic catalog is canonical for queries; `.kern` remains the human-authored source for declared project knowledge. `.kbin`, JSONL, Markdown and agent packets are derived artifacts.
- **Reason:** Independent manually-maintained exports drift and contradict one another.
- **Cache rule:** Every derived entry records all inputs and tool/model/schema versions that affect the result.
