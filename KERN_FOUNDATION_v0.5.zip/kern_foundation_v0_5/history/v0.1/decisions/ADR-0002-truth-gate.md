# ADR-0002: Verdict and e are computed, never authored

- **Status:** Accepted for v0.1
- **Decision:** KERN source can declare an assertion or hypothesis but cannot force `verdict=proven` or `e=1`.
- **Reason:** A language model or author must not promote a statement to truth merely by writing a status field.
- **Rule:** `e=1` is emitted only by the verifier when the type-specific policy, provenance rules, and conflict checks pass.
- **Trade-off:** Importing historical claims requires preserving their original status as an attributed assertion, not as a computed verdict.
