# Changelog

## v0.2.0 — research-integrated redesign

- Added Belnap–Dunn B4 evidence values (`N/T/F/B`) and kept coverage/verdict/acceptance `e` separate.
- Defined claim-scoped evidence admissibility and contradiction-resolution tasks.
- Separated source, build, and provenance graphs; specified the invariant required for provenance DAG acyclicity.
- Added `.kbin` v2 header/directory and safe memory-mapped reading rules.
- Added task-specific semantic-slice BLAKE3 cache identity.
- Added fuel, memory, output, recursion, and host-call limits to the KERN-X proposal.
- Added conformance tests and research register distinguishing established background from KERN design hypotheses.

## v0.1.0

Archived in `history/v0.1/`.
