# KERN Foundation v0.2 — research-integrated specification package

**Status:** design revision; implementation is not yet claimed.

This release extends v0.1 with five core changes:

1. Belnap–Dunn four-valued evidence logic for incomplete and conflicting support.
2. Separate source/dependency graph and provenance/derivation graph.
3. A versioned, bounds-checked, memory-mappable `.kbin` layout.
4. Semantic-slice Merkle cache keys for model-assisted analysis.
5. A fuel- and resource-bounded KERN-X execution proposal.

## Start here

- `KERN_FOUNDATION_SPEC_v0.2.md` — integrated normative specification.
- `docs/KERN_BELNAP_SEMANTICS_v0.2.md` — exact four-valued model and operators.
- `docs/KERN_PROVENANCE_GRAPH_v0.2.md` — graph distinctions and acyclicity conditions.
- `docs/KERNBIN_FORMAT_v0.2.md` — binary layout and safe zero-copy access.
- `docs/KERN_CACHE_SPEC_v0.2.md` — semantic slices and cache invalidation.
- `docs/KERNX_FUEL_SPEC_v0.1.md` — execution metering proposal.
- `KERN_CONFORMANCE_TEST_PLAN_v0.2.md` — required conformance tests.
- `RESEARCH_REGISTER.md` — evidence base, assumptions, and claims not yet established.
- `docs/PRIOR_ART_MATRIX.md` — adjacent systems and the limits of novelty claims.
- `docs/FOUNDATIONS_AND_ASSUMPTIONS.md` — precise interpretation of computability, hardware, algebra and statistical guarantees.
- `tests/belnap_vectors.json` — exhaustive truth-table vectors for four-valued operations.
- `schemas/belnap_claim_state.schema.json` — machine schema for claim state and consistency constraints.
- `schemas/kbin_format_v2.json` — machine-readable binary header, directory and section registry.
- `schemas/cache_entry.schema.json` — machine schema for semantic-slice cache entries.

## Important limits

This package is a specification and conformance-test plan, not a production compiler. It does not claim that `.kbin` is faster than FlatBuffers/Cap'n Proto, that all derivation graphs are automatically acyclic, or that conformal risk control proves each individual model output correct. Those are either design properties to enforce or claims to test.

The `history/v0.1/` directory preserves the previous specification package for comparison. Where v0.2 differs, v0.2 controls for the new behaviors described here.
