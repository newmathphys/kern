# KERN v0.2 Conformance Test Plan

These are required tests for a future implementation. Their existence in this package does not mean a Zig compiler has already passed them.

## A. Belnap truth model

1. Verify all 16 pairs for `JOIN_K`, `MEET_K`, `AND_T`, and `OR_T` against `tests/belnap_vectors.json`.
2. Verify `NOT_B` for all four values.
3. Verify `JOIN_K` commutativity, associativity, idempotence, and identity `N`.
4. Verify `MEET_K` commutativity, associativity, idempotence, and identity `B`.
5. Verify `B` evidence state retains both positive and negative source IDs.
6. Verify out-of-scope evidence is not used to set either support bit.
7. Verify an LLM response alone cannot set positive support for a factual/verification claim.
8. Verify passing a narrow test cannot support a broad universal correctness claim without an explicit justified policy.
9. Verify `N + not_scanned` differs from `N + complete_under_policy`.
10. Verify `B` sets `e=0` and creates/updates `resolve_contradiction` work.

## B. Provenance and graphs

1. A source graph containing import cycle A↔B is ingested and its SCC is reported without corrupting provenance.
2. A provenance edge to a future version is rejected.
3. A provenance cycle injected into a snapshot is rejected before commit.
4. A DerivationRun with 3 inputs and 2 outputs is represented without flattening away its hyperedge semantics.
5. Fixed-point execution records rule hash, seed hash, iteration count, termination status and budget.
6. Recursive/fixed-point exhaustion does not produce a successful proof/claim.
7. SCC condensation is acyclic and its topological order is validated.

## C. `.kbin` memory-mapped format

1. Verify fixed header size 128 and directory entry size 80.
2. Reject wrong magic, unsupported mandatory flags, wrong file size, and nonzero reserved fields.
3. Reject multiplication/addition overflow in directory and section range calculations.
4. Reject section/header/directory overlap, misalignment, out-of-bounds lengths and invalid section hashes.
5. Reject truncated strings and records whose relative offsets point outside their section.
6. Verify a snapshot reads correctly regardless of mapped virtual base address.
7. Verify reader holds mapping lifetime while typed views are live.
8. Verify atomic replacement does not mutate data currently mapped by a reader.
9. Round-trip records and preserve stable IDs/hashes.
10. Benchmark cold/warm open, random reads, allocations, resident memory, size, and validation cost against SQLite and an established zero-copy format.

## D. Merkle semantic cache

1. Identical canonical task identity yields identical cache key.
2. Interface change invalidates interface-dependent analysis.
3. Body-only change preserves an interface-only key only if the body was excluded from the actual model context and analysis contract.
4. Body change invalidates implementation-sensitive analysis.
5. Comments/docstrings in the actual model prompt invalidate that prompt result.
6. Model ID/revision, generation settings, tool schema, prompt, output schema, retrieval config or policy changes invalidate affected entries.
7. Unknown provider revision records `model_revision_unknown` and obeys freshness policy.
8. Cache hit never counts as a new execution or independent verification.
9. Cache keys are unambiguous for Unicode and strings containing delimiters.
10. Failed/incomplete model calls do not overwrite the last complete result.

## E. KERN-X fuel

1. Every opcode consumes fuel according to the pinned schedule.
2. Infinite loop ends within fuel and reports `fuel_exhausted`.
3. Memory/output/recursion quotas are enforced before side effects commit.
4. External host calls require capabilities and timeouts.
5. Uninterruptible native calls are prohibited inside deterministic sandbox tasks or executed in an isolated process.
6. Failure leaves the previous committed snapshot unchanged.
7. Output, logs, and budget use are recorded.
8. Same deterministic input and toolchain create the same logical state.

## F. Conformal/risk-control integration

1. No conformal risk result is emitted without calibration method, dataset/split, loss, target risk, sample count and applicable assumptions.
2. Distribution-shift or exchangeability assumptions are surfaced.
3. The output is labeled a statistical risk-control result, not a per-instance formal proof.
4. Candidate acceptance still requires the claim-specific verification policy.

## G. Performance reports

Every benchmark records hardware, OS/kernel, compiler/runtime versions, data size and hash, cold/warm state, repetitions, statistic and raw samples. No speedup claim is accepted without baseline runs under comparable conditions.
