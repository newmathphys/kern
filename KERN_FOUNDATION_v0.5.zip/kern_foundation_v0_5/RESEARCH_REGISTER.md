# KERN research register — v0.2

This register separates established background from KERN hypotheses and implementation obligations.

## R1. Belnap–Dunn logic

**Supported background:** the four values are neither, true-only, false-only and both; the system is a four-valued logic/bilattice for incomplete and inconsistent information. The values can be modeled as subsets of `{T,F}`.  
**KERN design choice:** store positive and negative support separately and keep coverage as another dimension.  
**Not claimed:** that B4 alone guarantees factual correctness or automatically makes all model/test/verifier results commensurable. Evidence must be scope-checked and policy-admitted.  
Source: https://plato.stanford.edu/entries/truth-values/

## R2. Provenance semirings

**Supported background:** semirings provide a common algebraic framework for provenance/annotations in relational algebra and certain Datalog calculations. Green, Karvounarakis and Tannen, PODS 2007.  
**KERN design choice:** maintain a provenance expression/semiring separately from the Belnap evidence-state lattice.  
**Not claimed:** that the proposed Belnap operators form a provenance semiring. Such an extension requires a carrier, identities, operation definitions and proofs of the axioms.  
Source: https://www.cs.ucdavis.edu/~green/papers/pods07.pdf

## R3. Zero-copy / memory mapping

**Supported background:** FlatBuffers is designed to access serialized data without parsing/unpacking it first.  
**KERN design choice:** an offset-based, versioned `.kbin` section format accessed read-only through memory mapping where supported.  
**Not claimed:** sub-millisecond open, zero allocations in every query, a universal 64-byte alignment optimum, or 10–100x speedup. Those require comparative measurements.  
Source: https://github.com/google/flatbuffers

## R4. BLAKE3 and Merkle structure

**Supported background:** BLAKE3 uses a tree structure and supports parallel hashing; it has a public specification and implementations.  
**KERN design choice:** use BLAKE3-256 over domain-separated canonical encodings for section hashes and cache identities.  
**Obligation:** validate with official test vectors and review stable-ID/domain-separation policy.  
Sources: https://github.com/BLAKE3-team/BLAKE3 and https://github.com/BLAKE3-team/BLAKE3-specs

## R5. Conformal methods for generative models

**Supported background:** Conf-Gen (ICML 2026) adapts conformal risk control to generative tasks and discusses statistical guarantees under its assumptions.  
**KERN design choice:** optional statistical candidate-risk control before deterministic verification.  
**Not claimed:** a conformal method proves an arbitrary individual generated program mathematically correct with probability `1-epsilon` without assumptions, calibration data, a defined loss and a valid application of the theorem.  
Source: https://proceedings.mlr.press/v306/loaiza-ganem26a.html

## R6. Fuel and termination

**Supported background:** well-founded recursion and finite decreasing measures can justify termination of specified recursive definitions; runtime fuel bounds executed VM transitions if every transition is metered.  
**KERN design choice:** finite fuel plus memory/output/recursion/host-call bounds.  
**Not claimed:** fuel alone bounds wall-clock time for unbounded or uninterruptible host calls or operating-system effects.  
Source: https://lean-lang.org/theorem_proving_in_lean4/Induction-and-Recursion/

## R7. Incremental computation

**Supported background:** Adapton studies demand-driven incremental computation and rebuilding dependent computations after changes.  
**KERN design choice:** dependency-keyed cache invalidation by explicit semantic slices.  
**Obligation:** test hit/miss correctness, not just performance; stale cache reuse is a correctness bug.  
Source: https://adapton.org/

## R8. Novelty statement

No claim is made that KERN is the first system to combine proof artifacts, provenance, AI-assisted verification, cache invalidation, graph data, or memory-mapped storage. A novelty claim requires a dated search protocol, comparison against prior art and existing implementations, and peer review. At present KERN is an engineering synthesis proposal.
