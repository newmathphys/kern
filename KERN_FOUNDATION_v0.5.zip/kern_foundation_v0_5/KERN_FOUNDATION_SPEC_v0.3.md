# KERN Foundation Specification v0.3

**Status:** architecture/specification package; not a claim that the Zig engine is implemented or benchmarked.  
**Native target:** Zig, toolchain version pinned per build.  
**Source language:** KERN-D, declarative and termination-bounded by grammar/semantics.  
**Execution extension:** KERN-X, metered VM or isolated process; not arbitrary native code inside the trusted engine.  
**Truth model:** Belnap–Dunn B4 evidence state, separate from verification verdict and provenance algebra.  
**Incrementality:** signed input deltas and differential maintenance, with deletion-aware provenance and explicit recursive semantics.  
**AI completion model:** optional policy-gated Proof-Carrying Code Completion (PC3); certificates bind to exact AST, policy and environment.  
**Binary snapshot:** `.kbin` v3 layout defined in `docs/KERNBIN_FORMAT_v0.3.md`; v2 snapshots are not byte-compatible.  

## 1. Scope and non-goals

KERN stores a typed, versioned model of a project: artifacts, symbols, claims, evidence, derivation runs, verifier results, metrics, decisions, deltas and snapshots. One canonical machine catalog generates the human report and agent handoff. KERN is not claimed to be the first system to combine these individual ideas; it specifies a particular integrated design whose novelty and performance must be evaluated against prior art.

The following are explicitly **not** guaranteed by the specification alone: zero runtime cost, zero page faults, universal linear-time proof checking, nanosecond incremental builds, absolute truth, or universal superiority to existing formats.

## 2. Layer architecture

- **L0 — physical/storage interface:** files, read-only mmap views, page/huge-page policy, checksums, append-only chunks and safe offset decoding.
- **L1 — typed data and compute primitives:** bounded integers, sequences, sets, maps, relations, status bitplanes, resource budgets.
- **L2 — KERN-D:** declarations, references, contracts, fixed finite iteration over declared collections; no general unbounded recursion or ambient side effects.
- **L2X — KERN-X:** explicit tasks/handlers executed by an instrumented VM or isolated worker, with fuel, memory, output and host-call budgets.
- **L3 — project and provenance model:** source dependency graph, build graph, immutable artifact versions, derivation runs and signed input deltas.
- **L4 — verification and AI boundary:** typed verification policies, Belnap aggregation, proof-carrying completions, calibration/risk reports and agent handoff.

## 3. Truth is not one status field

KERN separates four concepts:

1. `BelnapValue ∈ {N,T,F,B}` tracks admitted positive and negative evidence for an exact proposition and scope.
2. `VerificationVerdict` records a particular checker result: `proved`, `counterexample`, `unknown`, `timeout`, `invalid_certificate`, etc.
3. `CoverageState` records how completely the relevant sources and checks were examined.
4. `ClaimLifecycle` records workflow state: `draft`, `queued`, `blocked`, `accepted`, `rejected`, `superseded`.

The support bits are `(positive, negative)`: N=(0,0), T=(1,0), F=(0,1), B=(1,1). Evidence aggregation uses knowledge join `JOIN_K`; Boolean-like connectives use truth order `AND_T`/`OR_T`. They are not interchangeable. The provenance semiring is a separate type and must not be treated as Belnap B4 unless a specific algebra and its axioms are separately defined and verified.

`SAT` for a precondition establishes existence of a model for that precondition only. It does not prove code correctness. For postcondition checking, the common counterexample query is `Pre ∧ ¬Post`; SAT yields a counterexample model, while UNSAT supports the property only relative to the encoding, solver assumptions and supported theory. Timeout/unknown stays unknown.

`e=1` is a derived gate result, never a field the source language can assign. It requires claim-type policy, adequate provenance, successful appropriate validation, policy-compliant coverage, no unresolved negative support and no unresolved scope ambiguity.

## 4. Proof-Carrying Code Completion (PC3)

When a verification policy requires PC3, an agent proposes a tuple:

`Completion = (AST, Contract, ProofCertificate, ProducerMetadata)`.

The certificate is bound to canonical hashes of the AST, contract, imported interface environment, checker/policy version and target assumptions. The verifier checks that the certificate proves a stated property of that exact program under that exact policy. Invalid/missing certificates prevent publication of the staged edit. The old source/snapshot remains intact.

PC3 is policy-scoped: memory safety, bounds safety, type/refinement invariants or a specific functional theorem are distinct properties. PCC does not magically prove arbitrary business correctness. Certificate verification complexity depends on the selected proof calculus and encoding; O(|AST|+|π|) may be claimed only for a specified format and a proven/benchmarked checker. General proof search can be intractable and is not run by the small checker.

Precondition feasibility is a separate obligation:

- `SAT` + independently validated model → `PRECONDITION_FEASIBLE` for that encoded model/domain;
- `UNSAT` → `VACUOUS_SPECIFICATION` unless the contract is explicitly intended to describe unreachable code;
- `UNKNOWN/TIMEOUT` → `FEASIBILITY_UNKNOWN`.

Do not convert an infeasible contract automatically into Belnap `F` for the original claim. A nonempty precondition is necessary for a useful reachable contract, but is not sufficient to prove postcondition correctness.

## 5. Provenance and differential maintenance

Three graph projections are kept separate: `G_src` (source dependencies; may be cyclic), `G_build` (scheduled operations; cycles need an explicit policy), and `G_prov` (immutable derivation records across snapshot frontiers). Tarjan/Kosaraju SCC detection is used where relevant. A bipartite graph is not inherently acyclic; the committed provenance graph is acyclic because inputs are immutable prior versions and outputs are new later versions.

Updates are recorded as signed deltas over typed records. Retractions are handled by a deletion-aware differential engine (signed multiplicities and/or provenance tokens), not by applying an inverse to Belnap `JOIN_K`: B4 knowledge join is idempotent and has no general inverse. Evidence support bits are recomputed from the active, admissible support set after retraction. If logic-programming rules include negation, require stratified negation or a separately specified fixed-point semantics. Negative cycles inside an SCC produce a diagnostic/blocked rule set; they do not automatically get a mathematically justified `conflict` status merely because they cycle.

No universal complexity bound such as O(|ΔG|) is guaranteed for all project algorithms. Each operator must declare its assumptions, index/arrangement costs, affected region, and complexity; benchmarks must show actual behavior. Differential dataflow is prior art for incremental updates and iterative computations.

## 6. `.kbin` v3: chunked zero-copy-oriented snapshot

The canonical v3 wire format is specified separately. It uses explicit little-endian decoding, 64-bit section offsets/lengths, chunk IDs, typed record references and a chunk directory. Readers validate every range, alignment, version, reference and digest before exposing views. Never cast unchecked mmap bytes directly into native structs.

A read-only mmap can avoid copying/deserializing the entire object graph, but OS page faults, validation, random access, decoded query outputs and caches still have costs. Immutable snapshot publication uses write-temp → fsync as supported → atomic rename; a reader must not consume a file that is concurrently mutated/truncated.

SoA/CSR layouts are used for hot arrays when the workload benefits. Cache-line alignment (often 64 B on contemporary CPUs) is a tuning parameter, not a universal correctness law. Linux HugeTLB/THP is optional: attempt only when supported/configured, then fall back cleanly. Page sizes, privileges, reservation and fragmentation affect success; benchmark both paths.

## 7. Semantic Merkle cache

Every cached derivation declares a task-specific dependency projection. Interface-only slices can omit implementation bodies only when the task contract states that bodies are irrelevant; correctness checks, documentation analysis and body-sensitive tasks must include the relevant body/docstring/config. For cyclic source dependencies, compute SCCs, canonicalize member local hashes/internal edges, then hash the acyclic condensation graph.

A response-cache key includes at minimum: key-schema version, task/prompt template hash, canonical input-slice hash, output schema, model/provider fingerprint and revision availability, generation parameters, tool definitions and versions, retrieval settings, policy/checker versions, and relevant environment. If model revision is opaque or output nondeterministic, mark it and apply revalidation/TTL policy. A cache hit is reuse, not fresh execution and not proof.

## 8. KERN-X resource model

Each task receives `fuel_limit`, `arena_limit_bytes`, `output_limit_bytes`, `recursion_limit`, capabilities, host-call budgets and optional wall deadline. Every VM instruction and bounded library operation is charged. Host operations must be forbidden, independently bounded, deadline/cancellable, or isolated in a process that can be terminated. Fuel guarantees a finite number of metered VM steps, not by itself a strict wall-clock bound for arbitrary OS/device calls.

Use task-scoped arenas and staged effects. Only successful completion publishes outputs/snapshots; failures retain the previous committed snapshot.

## 9. Incremental acceptance flow

`scan → parse → normalize → resolve → build source graph → compute SCCs → create typed derivations → verify → publish snapshot → emit exports`.

On change: calculate artifact delta; identify affected dependency projections; retract invalidated derivation outputs; recompute affected rules/queries; run required verification; then atomically publish the new snapshot. Results with stale source hashes cannot be silently reused.

## 10. Conformance and evidence

The package defines test vectors for Belnap operators, PC3 bindings, precondition feasibility, deltas/retractions, SCC and stratification diagnostics, binary format bounds, endian decoding, concurrent snapshot publication, cache invalidation, and resource exhaustion. Tests of the reference model do not substitute for the native Zig implementation tests.

The implementation is complete only after Zig tests, fuzzing of parser/binary reader, differential-vs-full-recompute equivalence tests, independent binary reader checks and controlled performance benchmarks. No performance claim is accepted from layout reasoning alone.
