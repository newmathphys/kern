# Current changelog

Current version: KERN Foundation v0.5. Detailed notes: `CHANGELOG_v0.5.md`.
See the versioned specs and `history/` for prior drafts included in this package.
