# KERN Resource and Memory Model v0.3

## Memory and execution claims

- `mmap` avoids mandatory full deserialization; it does not eliminate virtual-memory bookkeeping, page faults, validation, decode operations or allocations made by queries.
- A `.kbin` reader may be zero-copy for validated byte slices. Scalar values use explicit little-endian accessors. Query outputs may allocate.
- 64-byte cache-line alignment, 2 MiB chunks, SoA and SIMD are target/profile decisions, not universal truths about every architecture.
- HugePages are attempted only when configured, permitted and supported; otherwise ordinary mappings are used.
- Per-thread staging buffers reduce false sharing risk; they do not mathematically eliminate every cache-coherence cost.
- CSR adjacency enables contiguous traversal, but branch predictor accuracy depends on actual control flow/data; no 100% prediction claim is made.

## Resource envelope

`TaskBudget = {fuel:u64, memory_bytes:u64, output_bytes:u64, recursion:u32, host_calls:u64, wall_deadline_ns:?u64}`.

Every VM transition and proportional-cost builtin is metered. Host I/O is either disallowed in deterministic evaluation or exposed as a declared capability with timeout/cancellation/isolation. Fuel exhaustion is `FUEL_EXHAUSTED`, not a Belnap contradiction.

## Snapshot concurrency

Prefer immutable mmap snapshots and atomic replacement over concurrent mutation of mapped files. If read-copy-update or live shared mapping is introduced later, define an epoch protocol with publication/commit words and verify memory ordering on supported targets. Acquire/release fences do not fix a writer modifying a record already reachable by a reader; data must not become visible until fully initialized.

## Portable offsets

Use file-relative `u64` section offsets and `{chunk_id:u32, offset:u32}` references within chunks limited to `u32::MAX`. Never serialize process virtual addresses. Check additions/multiplications for integer overflow before bounds checks.
