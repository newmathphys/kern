# KERN Differential Provenance Engine v0.1

## 1. Records and signed updates

A delta is an event over an exact versioned relation, not a sign applied to a Belnap status:

```text
DeltaEvent {
  epoch: u64,
  relation_id: StableId,
  tuple_id: StableId,
  multiplicity_delta: i64,  # non-zero
  provenance_token: StableId,
  source_snapshot: SnapshotId,
  reason: add | retract | replace
}
```

For set semantics, active membership is derived from support-token multiplicity/count; repeated identical events must be deduplicated by event ID. For bag/multiset semantics, the declared count is maintained. Invalid underflow or retraction of an unknown token is a diagnostic, not silent negative support.

## 2. Why B4 cannot be subtracted

`JOIN_K` is bitwise OR of support planes and is idempotent. There is no general inverse: e.g., `JOIN_K(T,F)=B`, but from `B` alone one cannot tell which evidence token to remove. KERN therefore stores active support/provenance tokens and recomputes the B4 aggregate for the affected claim after token retraction, or uses a differential multiset representation that retains enough multiplicity/source identity.

## 3. Full and incremental evaluation

Each rule/query declares:
- input relations and semantic versions;
- monotonicity and negation mode;
- output relations;
- indexes/arrangements used;
- fixed-point policy if recursive;
- cost model and resource budget.

The engine supports:
- full recomputation as reference oracle;
- incremental delta propagation;
- fallback recomputation for unsupported rules;
- differential equivalence tests comparing incremental output with full recompute after random add/retract sequences.

## 4. Cycles and negation

Source import/call graph cycles are represented as SCCs and are not automatically invalid. For logic rules, positive recursion may use a declared least-fixed-point algorithm over a finite lattice/finite domain. Negation requires stratification by dependency strata or a separately specified semantics. A negative dependency cycle inside an SCC is rejected as `UNSTRATIFIED_NEGATION` unless a later version defines a supported well-founded/stable-model semantics. It is not automatically translated to Belnap `B`.

## 5. Epoch protocol

All input deltas for one logical epoch are collected. Outputs are not published until all affected inputs and derivations for that epoch reach a consistent commit frontier. This prevents temporary false statuses in diamond-shaped dependencies. A transaction records the previous frontier and new frontier; failure restores the previous snapshot.

## 6. Complexity

The complexity depends on query shape, indexes, join selectivity, recursion, SCC changes, multiplicities and affected output size. KERN records actual visited nodes/edges, joins, emitted deltas, invalidations and fallback recomputations. Do not state a universal `O(|ΔG|)` bound unless proved for a restricted rule class.

## 7. Required tests

- add → expected output;
- retract → output disappears only when all valid support is removed;
- duplicate add/retract is idempotent by event ID;
- retraction cannot underflow support count;
- differential result equals full recomputation;
- diamond graph commits no intermediate inconsistent status;
- positive recursive SCC reaches declared fixed point or exhausts budget;
- negative dependency cycle is rejected/blocked under stratified semantics;
- stale epoch cannot overwrite newer committed output.
