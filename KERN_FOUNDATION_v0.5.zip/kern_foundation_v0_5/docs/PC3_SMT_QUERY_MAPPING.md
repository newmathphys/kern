# PC3 and SMT query mapping

## Do not conflate solver queries

| Obligation | Query / evidence | Meaning |
|---|---|---|
| Is the precondition reachable? | `Pre(x)` | SAT plus checked model establishes a feasible encoded input; UNSAT identifies an infeasible/vacuous precondition under that model. |
| Does there exist a counterexample? | `Pre(x) ∧ ¬Post(x, f(x))` | SAT plus a model validated against the encoding gives a counterexample; UNSAT excludes encoded counterexamples under solver/encoding assumptions. |
| Is a claimed theorem proven? | proof certificate in a specified proof calculus | Only the trusted proof checker can accept the certificate under the declared assumptions and policy. |
| Did a test pass? | actual test execution record | Empirical result for the tested cases and environment only. |

A Boolean `sat` result has meaning only with its exact query. `SAT(Pre)` does not prove `Post`; `UNSAT(Pre)` does not prove the original business claim false; `UNSAT(Pre AND NOT Post)` is not automatically a proof of native machine code unless the program-to-formula encoding is sound and covers relevant semantics.

## Minimum SmtBridge interface

The adapter should return a typed record:

- `query_kind`: `precondition_feasibility` or `counterexample_search`;
- `solver_id`, `solver_version`, `theory_set`;
- `query_hash` and `program/contract hash`;
- `result`: `sat`, `unsat`, `unknown`, `timeout`, `tool_error`;
- model/proof artifact IDs, if present;
- model validation result;
- stdout/stderr hashes and exit code;
- resource usage and limits;
- assumptions/unsupported constructs.

A stub or unavailable solver returns `not_run`/`tool_error`; it must never infer results from strings inside a user-supplied witness.
