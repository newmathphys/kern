# `.kbin` memory-format notes v0.1

## Layout principles

- Use little-endian on-disk encoding regardless of host.
- Use checked 64-bit file offsets or `(chunk_id:u32, chunk_offset:u32)` references in a segmented format.
- Never claim that `offset:u20` can address a 2 MiB chunk: 20 bits address at most 1 MiB.
- Keep hot fields in SoA/CSR tables when sequential scans are a measured workload; keep long evidence blobs and cold metadata in separate sections.
- Add a header with magic, format version, schema digest, file length, directory offset/count, root content digest and feature flags.
- Each section directory entry declares type, required/optional feature, offset, length, count, alignment and digest.

## Reader contract

1. Check file length before reading header.
2. Decode little-endian integers through checked helpers.
3. Validate every `offset <= limit` and `length <= limit - offset` before computing a view.
4. Validate alignment against actual file-relative offsets; mapping base alignment alone does not validate internal structure.
5. Validate UTF-8 only in fields declared UTF-8.
6. Validate section and record digests.
7. Expose borrowed byte slices only after validation; convert fields with accessors rather than unchecked casts from untrusted bytes.
8. Unknown optional sections can be skipped; unknown required sections cause a safe version error.
9. Publish immutable snapshots via temporary output + flush/sync as supported + atomic rename/manifest switch.

## mmap, HugePages, zero-copy

`mmap` maps file-backed pages into virtual address space; page faults and I/O may occur lazily. A reader can avoid allocating an object graph on its hot path, but the full process still has allocations elsewhere unless measured otherwise. HugeTLB/THP is optional and may fail or not be available; standard page mapping is mandatory fallback. Cache line sizes vary and are not correctness properties of the file format.
