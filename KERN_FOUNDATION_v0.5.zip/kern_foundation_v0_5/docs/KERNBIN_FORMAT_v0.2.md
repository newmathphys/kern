# KERN-Blob `.kbin` Format v0.2

**Purpose:** portable immutable snapshot with safe memory-mapped access, stable references, and section-level validation. This is a proposed format, not a benchmarked production implementation.

## 1. Design goals

- Direct access to indexed records without reconstructing a full heap object graph.
- Large-project support through 64-bit offsets and lengths.
- Read-only mapping of immutable snapshots.
- Bounds, overlap, version and checksum validation before exposing records.
- Forward-compatible optional sections.
- Canonical output when inputs and implementation version match.

`mmap` is not “zero cost”: mapping has OS overhead and data pages may fault in from storage. “Zero-copy” means the implementation can reference bytes in the mapped serialized region without first copying/unpacking every field. Decoded query results, strings converted to other formats, graph algorithms and caches may allocate.

## 2. Byte order, alignment and offset model

- All fixed-width integers are unsigned/signed as declared and little-endian.
- Offset and length fields use `u64`.
- Relative offsets in a section are measured from that section's first byte, not from the process's virtual address.
- Every section starts on an 8-byte boundary in v0.2. Larger alignments may be selected for hot sections as a builder option only after benchmarking.
- 64-byte cache-line alignment is not a universal correctness requirement and must not be applied blindly to every record.
- Strings are length-prefixed byte slices; NUL termination is not required.
- Readers MUST NOT cast unchecked bytes directly to native structs. Use explicit little-endian decoding or generated accessors, and validate all boundaries before slicing.

## 3. Header: exactly 128 bytes

| Offset | Size | Field | Rule |
|---:|---:|---|---|
| 0 | 8 | `magic` | ASCII bytes `KERNKB2\0` |
| 8 | 2 | `format_major` | `2` |
| 10 | 2 | `format_minor` | `0` for this layout |
| 12 | 4 | `header_size` | Must be `128` |
| 16 | 4 | `flags` | Unknown mandatory flags cause rejection |
| 20 | 4 | `section_count` | Number of directory entries |
| 24 | 4 | `directory_entry_size` | Must be `80` |
| 28 | 4 | `reserved0` | Must be zero |
| 32 | 8 | `file_size` | Must equal actual file size |
| 40 | 8 | `directory_offset` | Normally 128; must be 8-byte aligned |
| 48 | 32 | `root_hash` | BLAKE3 digest, definition below |
| 80 | 16 | `build_id` | Opaque build/snapshot identifier bytes |
| 96 | 8 | `created_unix_ns` | Informational timestamp; not part of semantic identity |
| 104 | 2 | `min_reader_major` | Minimum reader major version |
| 106 | 2 | `min_reader_minor` | Minimum reader minor version |
| 108 | 2 | `hash_algorithm` | `1` = BLAKE3-256 |
| 110 | 2 | `id_algorithm` | `1` = KERN stable-ID v1 |
| 112 | 8 | `feature_flags` | Unknown required features cause rejection |
| 120 | 8 | `reserved1` | Must be zero |

## 4. Section directory: exactly 80 bytes per entry

| Relative offset | Size | Field | Rule |
|---:|---:|---|---|
| 0 | 4 | `section_kind` | Registered numeric tag |
| 4 | 4 | `section_flags` | Mandatory/optional, sorted/compressed flags; unknown mandatory flags reject |
| 8 | 8 | `offset` | Absolute file offset of section payload |
| 16 | 8 | `length` | Stored section length |
| 24 | 8 | `uncompressed_length` | Equal to `length` when uncompressed |
| 32 | 8 | `item_count` | Number of records, if record-based; otherwise 0/defined by section |
| 40 | 4 | `alignment` | Must be a power of two and at least 8 in v0.2 |
| 44 | 2 | `codec` | `0` = none; unregistered codec rejected |
| 46 | 2 | `hash_algorithm` | `1` = BLAKE3-256 |
| 48 | 32 | `section_hash` | BLAKE3 digest over stored section bytes |

Directory entries are sorted by `section_kind` and section kinds are unique in v0.2. Chunked/duplicate kinds require a later format feature flag. Section directory range and every payload range MUST be in file bounds and MUST NOT overlap each other, the header, or the directory. `section_flags` bit 0 means the section is required; bit 1 is reserved for compression but MUST be zero in v2.0. All reserved bits MUST be zero.

## 5. Recommended section kinds

Numeric IDs are part of the registry; unknown optional sections may be skipped after validating range/hash, while unknown mandatory sections cause rejection.

- `STRS` — interned UTF-8 strings;
- `OBJS` — entity records;
- `REFS` — typed references;
- `RELS` — typed relation records;
- `CLMS` — claims and declared scope;
- `EVDS` — evidence records and polarity;
- `DERV` — derivation records;
- `VERF` — verification policies and verdicts;
- `RUNS` — execution records;
- `METR` — measurements;
- `CACH` — cache metadata, not authoritative evidence;
- `MANF` — canonical manifest and snapshot metadata.

The v2.0 numeric registry is fixed as follows (values are unsigned little-endian `u32`):

| Tag | Numeric ID | Required in a full snapshot |
|---|---:|---|
| `STRS` | `0x00000001` | yes |
| `OBJS` | `0x00000002` | yes |
| `REFS` | `0x00000003` | yes |
| `RELS` | `0x00000004` | yes |
| `CLMS` | `0x00000005` | yes |
| `EVDS` | `0x00000006` | yes |
| `DERV` | `0x00000007` | no |
| `VERF` | `0x00000008` | yes |
| `RUNS` | `0x00000009` | no |
| `METR` | `0x0000000A` | no |
| `CACH` | `0x0000000B` | no |
| `MANF` | `0x0000000C` | yes |

The `section_kind` field MUST use these IDs. Human-readable four-letter tags are used in reports only; they are not stored instead of the numeric IDs in the directory. “Required” means the section has the REQUIRED flag when present in a complete full snapshot; an incremental packet may use a future explicitly specified profile. v2.0 has no such alternate profile yet.

## 6. Canonical hashing

Use BLAKE3-256 with domain separation:

- section: `BLAKE3("KERN-KBIN-SECTION-v2\0" || kind_le || payload_bytes)`;
- integrity root: `BLAKE3("KERN-KBIN-ROOT-v2\0" || header[0:48] || header[80:120] || exact_directory_bytes)`.

The root field `[48,80)` is omitted to avoid self-reference. Unkeyed hashes detect accidental corruption but do not authenticate the publisher; signed manifests or MACs are a separate future feature. The formula includes `build_id` and `created_unix_ns`, so the integrity root changes when those envelope fields change. The `MANF` section separately carries `semantic_root`, computed from canonical semantic projections of section records. Every schema field is semantic by default; only a field explicitly tagged `semantic=false` is excluded. The semantic root includes section kinds and canonical semantic record bytes in stable ID order, but omits volatile build-envelope fields such as `created_unix_ns` and `build_id`. Thus integrity identity and semantic reproducibility are not conflated. Section hashes are committed by the exact directory bytes; do not append them a second time unless a new version specifies it.

## 7. Reader safety algorithm

1. Open snapshot read-only and record file identity/size.
2. Map or stream the file according to platform support.
3. Validate minimum file size and magic.
4. Decode the header field-by-field; validate version, sizes, reserved fields and flags.
5. Checked-multiply `section_count * 80`; checked-add directory offset/size.
6. Validate directory bounds before reading entries.
7. Validate every section offset/length with overflow-safe arithmetic, alignment, non-overlap and file-size bounds.
8. Verify root and section hashes according to policy before returning a section as trusted input.
9. Validate referenced string/record offsets at access time or in a validation pass.
10. Expose typed views that keep the mapping lifetime alive; reject access after unmap.

A file that is concurrently truncated or mutated while mapped is unsafe. KERN opens immutable snapshots and should use atomic temp-file + rename publication; writers never modify a snapshot in place. If the platform cannot guarantee immutability, use file locks or a read-copy-update snapshot protocol.

## 8. Data record references

Use section-relative offsets plus lengths, not process pointers. A record reference has `{section_kind:u32, offset:u64, length:u64, record_kind:u32, flags:u32}`. Every resolution validates section existence and range. Offsets remain valid if the file is mapped at a different virtual address.

## 9. Compatibility

- Readers reject unsupported major versions.
- Minor versions may add optional sections/fields only under explicit feature flags and compatibility rules.
- Reserved values must remain zero until assigned by a later specification.
- Compression is not enabled in v0.2. Any future codec needs decompression limits and bomb-resistance tests.

## 10. Performance acceptance

Do not promise “instant,” “sub-millisecond,” “zero allocation,” “1–2 orders faster,” or universal cache-line benefits without benchmark results. Benchmark at least:

- cold-open time;
- warm-open time;
- time to retrieve 1, 100, and 10,000 records;
- memory resident set and bytes mapped;
- allocations and bytes allocated per query;
- sequential and random-access throughput;
- snapshot size;
- validation cost;
- corruption detection overhead.

Compare against SQLite queries and one established zero-copy format under the same dataset, machine, operating system, and verification requirements.
