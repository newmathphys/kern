# KERN Graph and Provenance Model v0.2

## 1. Do not use one graph for every relation

KERN maintains distinct graph projections over shared stable entity IDs.

### `G_src` — source graph

Contains source files, modules, symbols, imports, calls, package links, tests and build declarations. Cycles are legal observations. Find strongly connected components (SCCs), record their members and reasons, and do not call the graph a DAG unless that has been checked for the relevant edge subset.

### `G_build` — operation graph

Contains operations the engine plans to schedule. It may only be executed by a scheduler after cycle analysis. For ordinary acyclic stages, schedule topologically. For an SCC, require an explicit policy: supported cycle unit, fixed-point algorithm with termination/budget, or diagnostic. The SCC-condensation graph is acyclic, but that does not mean the nodes inside an SCC have an acyclic dependency relation.

### `G_prov` — provenance graph

Records immutable versions and derivations. A `DerivationRun` is a first-class node with N typed input edges and M typed output edges; semantically this is a provenance hyperedge.

```text
ArtifactVersion A ─┐
ClaimVersion C1 ────┼──> DerivationRun D ───> Evidence E
ConfigVersion Q ───┘                     └──> ClaimVersion C2
```

## 2. Acyclicity invariant

Bipartite node types alone do not imply a DAG. KERN enforces provenance acyclicity with immutable causal versions:

- a derivation can only cite input versions in its parent frontier;
- it creates new, immutable outputs in a later frontier;
- a result cannot be edited retroactively to become an input to its own derivation;
- each derivation and output carries an ordinal within the snapshot lineage;
- forward references are rejected;
- commit runs an explicit DAG/cycle validation before publishing the snapshot.

The graph is acyclic because of these construction constraints, not because it is bipartite.

## 3. Recursive and fixed-point methods

Some logic-programming and graph algorithms are intentionally recursive. Do not fake acyclicity by suppressing real dependencies. Represent each bounded fixed-point evaluation as a `DerivationRun` containing:

- the rule-set hash;
- seed-state hash;
- iteration count;
- termination condition;
- monotonicity assumptions if relevant;
- fuel/budget consumed;
- converged or exhausted status;
- output snapshot hashes;
- optionally, a compressed iteration transcript.

Internal recursive steps may have their own graph, which can be cyclic or represented algebraically. The committed provenance DAG points to the run artifact and its outputs. If complete proof trees are required, store finite derivation witnesses for each output or a formal recurrence descriptor; do not claim a finite tree for an infinite unfolding.

## 4. Provenance algebra

A provenance expression over source variables can use `+` for alternative derivations and `*` for joint dependencies, under a precisely chosen semiring. This is the classical provenance-semiring approach for relational queries (Green, Karvounarakis, Tannen, PODS 2007). It is not identical to Belnap evidence aggregation.

- `BelnapValue`: `N/T/F/B` — evidence support state.
- `ProvenanceExpr`: lineage formula — how output depends on source facts.
- `VerificationVerdict`: result of a typed checker.

An evidence source can be recorded in lineage whether or not it is accepted for the positive or negative support of a claim. The policy decides admissibility separately.

Baseline provenance expressions are defined for positive monotone derivations. Negation and absence-as-false require an explicit non-monotonic semantics.

## 5. Incremental invalidation

A source change invalidates:

1. the normalized representation of that source if changed;
2. directly dependent symbol/module summaries;
3. derivations whose declared input IDs/hashes include the changed version;
4. claims whose verification policy requires those outputs;
5. reports/agent packets depending on changed records.

Do not invalidate unrelated facts merely because they are nearby in the filesystem. Conversely, do not skip invalidation when a transitive semantic dependency changed.

## 6. Impact queries

Supported queries:

- trace a claim backwards to raw source/run artifacts;
- list descendants of a changed artifact in `G_src` or `G_build`;
- find every claim whose support derives from a failed run;
- show SCCs in the source graph;
- find all claims contradicted by a new result;
- show which cache entries became stale;
- compare provenance between snapshots.

## 7. Optional paired annotation (not named a semiring)

A later implementation may attach both fields to a derivation result:

`AnnotatedEvidence = { belnap_value: BelnapValue, lineage: ProvenanceExpr }`.

For **alternative observations**, update the truth-state with `JOIN_K`; combine lineages with provenance addition (`+`). For **joint prerequisites in a single derivation**, apply the appropriate truth-functional rule required by the claim semantics and combine lineages with provenance multiplication (`*`). Store the operation kind explicitly. This paired record is an annotation product, not a claim that the paired operators satisfy the semiring axioms. An integrated algebra may be standardized only after its laws and interpretation are proven.
