# Optional conformal layer for model-generated candidates

Conformal prediction may be used to produce statistically calibrated candidate sets or control selected risks for a black-box generative model. It is an optional L4 ranking/risk layer, not part of the trusted formal proof kernel.

## Required metadata

- model fingerprint and sampling configuration;
- calibration dataset hash and sampling process;
- candidate admissibility function/version;
- nonconformity score and threshold;
- target miscoverage/risk level;
- assumptions required by the method;
- test/evaluation set and reported coverage with uncertainty;
- software version and random seeds where meaningful.

## Trust rule

A conformal coverage guarantee is statistical and assumption-dependent. It does not establish that each accepted code artifact is correct. PC3/SMT/Lean checks remain separate gates for the formal property, and test results remain empirical evidence. If calibration assumptions drift, the conformal guarantee may no longer apply.

## Research source

Shahrokhi et al., “Conformal Prediction Sets for Deep Generative Models via Reduction to Conformal Regression,” UAI/PMLR 286, 2025: https://proceedings.mlr.press/v286/shahrokhi25a.html
