# Cross-language conformance strategy

## Principle

Zig is the native implementation authority for the initial runtime. Lean is the formal algebra model. Python is an executable reference/oracle for finite test generation only. Rust and C++ are optional integration adapters, not independent semantic authorities.

All implementations consume the same canonical B4 vectors and contract tests. No implementation is called equivalent until its actual compiler/test output is recorded for a pinned toolchain.

## ABI rule

Use C ABI types such as `uint8_t` for a Belnap tag (valid range 0..3), then validate before conversion. Do not expose a language-specific 2-bit integer as a C ABI type. Avoid unchecked `transmute` when a checked enum conversion is trivial.

## Release gate

For each toolchain, record:

- compiler version and target triple;
- optimized/debug mode;
- test command, exit code and raw output;
- generated operation-vector hash;
- build artifact hash.

The release pipeline fails when any language adapter disagrees with the reference vectors. A successful finite truth-table suite establishes agreement on those tested finite operations only; it does not verify the full KERN engine.
