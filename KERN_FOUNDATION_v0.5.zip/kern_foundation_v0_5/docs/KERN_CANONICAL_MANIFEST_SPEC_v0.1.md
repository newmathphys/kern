# KERN canonical project manifest

## Purpose

`PROJECT_CANONICAL_SPEC.kern.md` is a generated dual-view report: readable by engineers and selectively consumable by agents. It is generated from a versioned project snapshot and catalog, not hand-maintained as a second source of truth.

## Trust partition

1. **Machine block**: fenced `kern` block with a declared schema and snapshot hash; parsed and validated by `kernc`.
2. **Human commentary**: Markdown explanation; informative but non-authoritative for e(c).
3. **Source links**: exact relative path, content digest, line/byte span or immutable external ID.
4. **Evidence record**: checker/tool identity, input digest, command/query kind, output digest and result.
5. **Synthetic examples**: explicitly marked `SYNTHETIC`; never admitted as project evidence.

## Required front matter

```yaml
---
kind: kern-canonical-manifest
manifest_schema: 0.1
project_id: "<derived-stable-id>"
snapshot_id: "<immutable-snapshot-id>"
root_digest: "blake3:<digest>"
generated_by: "kernc/<version>"
provenance_status: complete|partial
---
```

Front matter is metadata for this generated report; the canonical source model remains the KERN catalog and immutable artifact snapshot.

## Machine block

A machine block declares schema version and references:

```kern
manifest snapshot="SYNTHETIC:example-snapshot" schema="kern/0.5" {
  artifact id="A1" path="src/example.zig" digest="SYNTHETIC:content-hash"
  claim id="C1" statement="example proposition" value=N coverage=partial
  evidence id="E1" source="A1" kind="source_span" span="1:1-1:20" admissible=false
  relation id="R1" from="C1" to="E1" kind="candidate_support"
}
```

This is an illustrative grammar fragment, not necessarily accepted by the current parser. The normative parser grammar must be versioned separately.

## Required report sections

- corpus scope and exclusions;
- scanned / parsed / failed / skipped counts and denominator definitions;
- project/module/symbol map;
- claims grouped by Belnap state and coverage;
- evidence provenance and verification runs;
- contradictions and their resolution tasks;
- formal proofs and their exact statement scope;
- empirical metrics with setup and repetition counts;
- stale cache entries and invalidation reasons;
- unknowns, blockers and unsupported formats;
- next-agent handoff packet reference.

## Prohibited behavior

- Never hardcode a percentage such as `99.4% verified` in a template.
- Never assign `T` or `e=1` because the generating model writes it in source.
- Never treat a textual witness label as a proof object.
- Never hide failed, skipped, or unsupported artifacts from coverage accounting.
- Never merge separate projects merely because one chat mentions them together.
