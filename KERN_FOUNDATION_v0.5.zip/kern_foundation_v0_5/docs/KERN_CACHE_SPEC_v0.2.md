# KERN Semantic-Slice Merkle Cache v0.2

## 1. Goal

Reuse expensive parsing, analysis, and model-assisted results only when all semantically relevant inputs match. Do not invalidate a model result for a source change that was demonstrably excluded from that task's input; do not reuse a result when a hidden dependency actually changed.

## 2. Canonical cache-key structure

The key is:

`BLAKE3("KERN-CACHE-KEY-v1\0" || CanonicalEncode(CacheIdentity))`

`CacheIdentity` contains:

- `task_kind` and version;
- `project_snapshot_id` or explicit semantic slice;
- `semantic_slice_profile` and `semantic_slice_hash`;
- exact question/task payload hash;
- system/developer prompt-template hashes;
- model provider, model ID, exact revision/fingerprint if exposed;
- tokenizer version if it affects counted/truncated input;
- generation settings (temperature, top-p, max tokens, penalties, seed where supported);
- tool names, tool-schema hashes, and tool implementation versions;
- retrieval/query-plan/configuration hash;
- input and output schema versions;
- extractor/compiler version;
- verification policy hash;
- redaction/privacy policy version;
- any execution environment fields required by the task.

Encoding MUST be canonical and length-delimited, with domain separation. Never concatenate unescaped strings ambiguously.

## 3. Slice profiles

### `interface`

Public names, signatures, types, contracts, exported schemas, and selected API docs. Appropriate only for tasks whose conclusion depends on interfaces rather than implementation behavior.

### `implementation`

Normalized AST/body semantics for selected symbols plus the transitive dependency closure selected by the analysis plan. It may ignore formatting-only differences if the parser proves the normalized AST is unchanged.

### `documentation`

Selected document sections, headings, citations, and any prose included in the model context. A changed comment/docstring invalidates the cache if the comment/docstring was part of this slice.

### `raw_source`

Exact bytes. Use for tasks that depend on source formatting, exact prompt text, embedded literals, or source-level forensic comparison.

### `experiment`

Code hash, data hash, configuration, seed, hardware/software environment, command, dependencies, and method hash. A benchmark cannot be reused after any required input or environment dependency changes.

### `full_context`

A record of all source objects actually provided to the model, including ordered context fragments and truncation decisions. The model must not claim to have inspected sources that were not in this context or in separately recorded tool calls.

## 4. Semantic mask / projection

The task specification declares a projection `P_task(inputs)`. Then:

`SemanticSliceHash = BLAKE3("KERN-SEMANTIC-SLICE-v1\0" || CanonicalEncode(P_task(inputs)))`.

The projection is a formal dependency declaration, not an LLM guess made after the response. The extractor may propose a smaller projection, but it must validate it against the actual retrieved context and analysis method.

For example, an interface-only query may intentionally ignore changes to a function body. A correctness query generally cannot ignore the implementation body. A documentation answer cannot ignore a docstring that was given to the model. If uncertain, choose the conservative larger slice.

## 5. Cache record

Each entry stores:

- key and schema version;
- task and slice profiles;
- all component hashes;
- model and tool fingerprints;
- creation time and optional expiry;
- source response ID/trace ID where available;
- raw model output artifact reference;
- parsed output and schema-validation result;
- token/latency/cost data where available;
- independent verification status and its own run ID;
- staleness/revalidation state.

The cache must distinguish `reused_output` from `fresh_execution`. A cache hit is not a newly executed command and is not proof of correctness.

## 6. Opaque or moving model aliases

If the provider does not expose an immutable model revision, record `model_revision_unknown`. Such entries may have a shorter TTL or require explicit revalidation after provider changes. Do not claim bit-for-bit reproducibility for a moving alias.

## 7. Invalidation

Invalidate when any input included by the slice projection changes, or when relevant schema, prompt, model, tool, policy, tokenizer, retrieval configuration, extraction method, or compiler version changes.

Preserve unrelated entries when the dependency graph proves their input slice is unaffected. Record each invalidation's reason.

## 8. Separate caches

Use distinct namespaces for:

- parse/AST cache;
- symbol/interface cache;
- document/chunk cache;
- search query/result cache;
- LLM request/response cache;
- verification-run cache;
- benchmark/experiment cache;
- report/agent-packet cache.

Never let an LLM-response cache overwrite a verifier result or raw evidence. Model output is derived material and remains subject to truth-gate evaluation.

## 9. Tests

- identical canonical identity -> same key;
- a relevant signature/type/contract change invalidates interface analysis;
- unrelated implementation body change does not invalidate a strictly interface-only task;
- implementation change invalidates an implementation-sensitive task;
- changed prompt, tool schema, model revision, retrieval context, or output schema invalidates the response cache;
- docstring change invalidates a task whose context included the docstring;
- an unversioned provider alias is marked unknown and obeys TTL/revalidation policy;
- cached output never changes claim truth state without the normal evidence policy;
- canonical encoding is unambiguous under strings with separators/Unicode;
- stale evidence produces a cache miss or explicit stale status, never silent reuse.

## 10. Merkle treatment of cyclic dependency components

A naïve recursive Merkle hash cannot hash a cyclic `G_src` by simply asking each node to hash its children. KERN MUST first compute strongly connected components (SCCs) of the dependency-edge subset used by the task, then hash the acyclic condensation graph.

For an SCC `S`, calculate:

`SCCHash(S) = BLAKE3("KERN-SCC-SLICE-v1\\0" || CanonicalEncode(sorted(local_semantic_hashes(S), internal_typed_edges(S), outgoing_dependency_SCC_hashes(S))))`.

The member order and internal-edge order are canonical. Per-node slice keys may then combine the node's local hash with the SCC hash and relevant outgoing slice hashes. This produces a deterministic hash for a cyclic dependency component without pretending that its internal edge graph is acyclic.

The semantic edge subset is task-specific. A module interface query can hash exported signatures/contracts and internal SCC interfaces; an implementation correctness task must include relevant bodies and runtime-sensitive dependencies. Tests must demonstrate that the projection is not accidentally omitting behaviorally relevant inputs.

## 11. Integrity, identity and authenticity are distinct

- **Content hash:** identifies exact bytes under a selected hash algorithm.
- **Semantic slice hash:** identifies a canonical selected projection for a task.
- **Cache key:** identifies one derived computation over that projection and its execution fingerprint.
- **Integrity root:** detects corruption relative to the stored hashes.
- **Signature/MAC:** if needed, authenticates the publisher/key-holder. Unkeyed BLAKE3 alone does not prove who created a snapshot; an attacker able to rewrite the file can recompute unkeyed hashes.

## 12. Do not conflate three kinds of cache

1. **KERN semantic-result cache:** durable project cache keyed by semantic slice, task, model/tool fingerprint and schema. It stores structured derived results and references to source outputs.
2. **Provider prompt cache:** provider-managed reuse of repeated prompt prefixes, if supported by that API. It can reduce inference work/cost but is neither durable KERN knowledge nor a substitute for a result cache.
3. **Model KV cache:** inference-runtime state used during token generation. It is generally tied to a live inference session/runtime and must not be treated as a project artifact unless a runtime explicitly defines a safe persistence format.

Report these metrics separately. A hit in one cache is not evidence of a hit in another.
