# KERN Foundations: precise scientific assumptions

This document prevents foundational concepts from being used as metaphors that overstate what the implementation guarantees.

## 1. Computability

Turing completeness describes expressive power relative to a computational model; it does not imply that all programs terminate, that all computable problems are feasible in practice, or that languages have the same runtime, memory use, tools, or ergonomics.

KERN-D is restricted and side-effect free, but “not Turing-complete” alone is not a complete termination proof. The implementation must also bound include expansion, expression evaluation, graph traversals, parsing/resource usage, fixed-point procedures, and any user-configurable recursion. KERN-X is separately metered.

## 2. Digital hardware abstraction

A logical bit is an abstraction implemented by electrical ranges and timing constraints. A CMOS transistor is a physical device with analog behavior, not a perfect philosophical switch that only exists in two literal physical states. Logic gates and circuits use voltage margins, timing, noise tolerance, and physical signal behavior to implement discrete computation.

KERN L0 may record processor architecture, endianness, alignment, cache properties and OS behavior, but must not infer a universal cache line size or universal device behavior without detection or documented target parameters.

## 3. Memory and zero-copy

A memory-mapped file maps file-backed pages into a process virtual address space. It can remove the need to copy/unpack every serialized record, but pages still need to become resident, validation still takes time, and materialized query results may allocate. Mapping is a mechanism, not a performance theorem.

A serialized byte layout is not a native in-memory struct layout. Alignment and endian rules must be decoded explicitly. A reader must validate offsets, lengths, arithmetic overflow and mapping lifetime before access.

## 4. Mathematical structures

- Boolean algebra models two-valued logical operations.
- Belnap–Dunn B4 models four evidence states: neither, true-only, false-only, both.
- Set operations apply to sets, not automatically to arrays or ordered lists.
- A semiring requires a carrier plus specified operations, identities, associativity and distributivity laws. The name “semiring” does not follow merely from defining two symbols.
- A directed bipartite graph may still contain cycles. Acyclicity must be checked or enforced by a versioning/causality invariant.

## 5. Curry–Howard and formal claims

The Curry–Howard correspondence relates propositions to types and proofs to terms in particular typed calculi. KERN's `claim` record is not itself a formal proposition accepted by Lean/Z3. A bridge must provide a translation, exact assumptions, encoding and proof/checking result. The engine must preserve the boundary between a natural-language claim and its formalized proposition.

## 6. Tests and empirical claims

A successful test establishes the tested behavior under that test's inputs, build and environment. It does not establish universal correctness of the whole system. A benchmark must include method, data, environment, repetitions and raw samples. A solver counterexample is scoped to the encoded formula and assumptions. An LLM explanation is a hypothesis until independently checked.

## 7. Statistical calibration

Conformal risk control can offer finite-sample statistical guarantees under specified methods, data assumptions and loss definitions. It does not replace formal verification and does not, without further assumptions, prove an arbitrary individual program correct. Distribution shift and calibration mismatch must be recorded as explicit risks.

## 8. Evidence state versus truth in the world

Belnap value `T` means admissible positive support exists and admissible negative support does not in the declared evidence corpus and scope. It does not establish metaphysical or context-free “absolute truth.” KERN's `e=1` means “accepted under this explicit verification policy and scope”; the policy, evidence corpus, tool versions and limitations remain visible.

## 9. Novelty

The integrated KERN architecture may be new as a particular implementation, but a claim that no previous system has a similar capability is an empirical literature/product-comparison claim. It requires a systematic, dated comparison against prior art.
