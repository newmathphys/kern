# KERN `.kbin` Format v3 — Chunked Mapped Snapshot

**Status:** proposed wire format; needs an independent reader implementation and fuzzing before production use.

## 1. Goals

- immutable snapshots suitable for read-only memory mapping;
- append-only segment/chunk design so new entities do not shift old references;
- `u64` offsets in file/directory, bounded `u32` offsets inside chunks;
- explicit little-endian fields and no unchecked native-struct casts;
- section-level integrity and semantic-root distinction;
- optional page-size-aware layouts, not a hard dependency on HugeTLB.

## 2. Header (128 bytes)

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 8 | magic `KERNKB3\0` |
| 8 | 2 | format_major = 3 |
| 10 | 2 | format_minor = 0 |
| 12 | 4 | header_size = 128 |
| 16 | 4 | flags |
| 20 | 4 | directory_entry_count |
| 24 | 4 | directory_entry_size = 96 |
| 28 | 4 | reserved = 0 |
| 32 | 8 | file_size |
| 40 | 8 | directory_offset (normally 128) |
| 48 | 32 | integrity_root BLAKE3-256 |
| 80 | 16 | build_id |
| 96 | 8 | created_unix_ns (envelope metadata only) |
| 104 | 2 | min_reader_major |
| 106 | 2 | min_reader_minor |
| 108 | 2 | hash_algorithm (1 = BLAKE3-256) |
| 110 | 2 | id_algorithm (1 = stable ID v1) |
| 112 | 8 | feature_flags |
| 120 | 8 | reserved = 0 |

All integers are little-endian. Unknown required features cause rejection; unknown optional sections may be skipped after bounds and hash validation.

## 3. Directory entry (96 bytes)

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 4 | section_kind |
| 4 | 4 | section_flags |
| 8 | 8 | section_offset |
| 16 | 8 | stored_length |
| 24 | 8 | logical_length |
| 32 | 8 | item_count |
| 40 | 4 | alignment (power of two; minimum 8) |
| 44 | 2 | codec (0 = none in v3.0) |
| 46 | 2 | hash_algorithm |
| 48 | 32 | section_hash |
| 80 | 4 | chunk_id |
| 84 | 4 | section_schema_version |
| 88 | 8 | reserved = 0 |

Directory entries sort by `(section_kind, chunk_id)`. Chunk IDs are unique per section kind. File offsets and lengths use checked arithmetic; all payload ranges must be in bounds and non-overlapping.

## 4. Stable references and chunk geometry

```text
ChunkRef = { chunk_id: u32, offset_in_chunk: u32 }
```

The reader resolves `chunk_id` via the directory, then checks `offset_in_chunk < chunk_length` and validates the target record length. Chunk payload is limited to `u32::MAX` bytes; a typical target chunk is around 2 MiB, but the exact size is a builder profile, not semantic law. A 20-bit intra-chunk offset cannot address a 2 MiB chunk; v3 does not use that incorrect layout.

Stable entity identity is independent of byte offset. Repacking must not change an entity's stable ID. Hash IDs are derived from a canonical kind/namespace/qualified key; collision resolution is explicit and checked. Offset is only a storage locator.

## 5. Sections and hot layout

Required for a full snapshot: `STRS`, `OBJS`, `REFS`, `RELS`, `CLMS`, `EVDS`, `VERF`, `MANF`. Optional: `DERV`, `RUNS`, `METR`, `DELT`, `CACH`, `SYMB`, `CSR0`, `BEL4`.

For query-heavy graph operations, a builder may create:
- `CSR0`: compressed sparse row adjacency (`row_offsets:u64[n+1]`, edge records contiguous);
- `BEL4`: separate positive/negative support bitplanes for a stable claim-index order;
- `DELT`: signed update logs for committed epochs.

SoA is an optional layout profile selected by benchmark. `BelnapValue` state is not the same as provenance multiplicity; BEL4 is recomputed from active support records.

## 6. Hashes

- `section_hash = BLAKE3("KERN-KBIN3-SECTION\0" || section_kind_le || chunk_id_le || payload)`.
- `integrity_root` commits to all header fields except itself and the exact directory bytes, whose entries include section hashes.
- `semantic_root` (in MANF) hashes canonical semantic records in stable ID order and excludes only fields explicitly marked non-semantic.

Unkeyed hashes detect corruption relative to a trusted expected root; they do not authenticate authorship. Signatures/MACs are separate and optional.

## 7. Reader algorithm

1. Open an immutable snapshot read-only.
2. `mmap` if supported; otherwise use positional reads.
3. Validate size, magic, version, header size, reserved fields and features.
4. Checked-multiply directory count × 96 and validate range.
5. Decode each field explicitly as little-endian; validate sections, alignments, lengths, ordering, overlap and hashes.
6. Resolve each `ChunkRef` through bounds-checked accessors.
7. Keep mapping lifetime tied to returned views.
8. Never expose a typed record before its section and referenced ranges pass validation.
9. If file identity/size changes unexpectedly, abort and reopen the immutable snapshot.

Do not `@ptrCast` arbitrary file bytes into `extern struct` and assume host endian/alignment. Generated accessors can be zero-copy for byte slices, while scalar fields are decoded safely.

## 8. Huge pages

HugeTLB/THP is optional and OS-specific. `MAP_HUGETLB` may fail when unsupported, unconfigured, unreserved or out of suitable pages. The engine must support ordinary page mmap and positional-read fallback. `MADV_HUGEPAGE` is only a hint where supported. Never require root privileges or modify system hugepage pools automatically.

Do not claim lower TLB miss percentage or improved wall time without measurement. Huge pages may help large/random access workloads and can hurt small or memory-constrained workloads.

## 9. Concurrency and publication

Published snapshots are immutable. Writers create a new temp snapshot and atomically publish it; they never mutate records in place while readers map them. Append-only chunks are assembled before the new manifest/root is committed. This avoids relying on memory fences to make a concurrently-mutated mapped file safe. If a future shared-memory live mode is added, it needs a separate protocol with atomic commit words, epoch validation and acquire/release ordering.

## 10. Acceptance benchmark

Compare `.kbin` v3 against v2 and SQLite on identical generated datasets at 10k, 100k, 1M and (if resources permit) 10M claims/edges. Record cold/warm open, page faults, RSS, first query, sequential scan, random lookup, delta update, allocations per query, full validation time, file size and hardware/OS/toolchain. Report median and spread over repeated runs. No performance number is part of the format standard until measured.
