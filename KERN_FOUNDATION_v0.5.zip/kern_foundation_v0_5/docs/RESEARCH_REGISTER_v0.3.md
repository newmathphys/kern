# KERN research register v0.3

This register identifies prior art. It does not claim that KERN's proposed integration is unprecedented.

- **Belnap/Dunn four-valued logic:** represent evidence for and against separately; distinguish the knowledge order from the truth order. The v0.2 semantics defines the operational table used by KERN; this v0.3 audit adds tests to avoid confusing evidence aggregation with conjunction.
- **Provenance semirings:** Green, Karvounarakis, Tannen, “Provenance Semirings,” PODS 2007. Relational provenance annotations use semiring operations; KERN must separately prove any proposed combination with B4.
- **Differential dataflow:** McSherry et al., CIDR 2013 and later docs, incremental maintenance under updates with iterative computations. KERN adopts the pattern but does not claim general O(delta) complexity.
- **Proof-carrying code:** Necula, POPL 1997; Necula & Lee, 1998 chapter. Receiver checks a certificate that the exact code meets a declared safety policy. This is prior art, not an invention by KERN.
- **Memory-mapped zero-copy formats:** FlatBuffers documents direct access to serialized data without parsing/unpacking. KERN proposes a domain-specific section/chunk layout and must benchmark against existing formats.
- **Linux HugeTLB:** the kernel documentation describes supported/configured page sizes, reserved pools and allocation constraints. KERN treats it as optional optimization with fallback.

## Sources
- https://www.cs.ucdavis.edu/~green/papers/pods07.pdf
- https://www.microsoft.com/en-us/research/publication/differential-dataflow/
- https://doi.org/10.1145/263699.263712
- https://doi.org/10.1007/3-540-68671-1_5
- https://github.com/google/flatbuffers
- https://www.kernel.org/doc/html/latest/admin-guide/mm/hugetlbpage.html
- https://man7.org/linux/man-pages/man2/mmap.2.html
