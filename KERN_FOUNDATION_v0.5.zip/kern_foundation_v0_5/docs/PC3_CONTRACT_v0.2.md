# PC3 / Proof-Carrying Completion — contract v0.2

## Completion tuple

`Completion = (canonical_ast_hash, contract_hash, interface_env_hash, proof_system_id, checker_policy_id, certificate_bytes, producer_metadata)`.

## Accept procedure

1. Parse the proposed code with the authoritative parser.
2. Canonicalize the AST deterministically.
3. Recompute AST, contract and interface hashes; reject mismatches.
4. Load a known proof checker for the declared proof system/version.
5. Verify the certificate against the exact AST semantics and required policy.
6. Confirm any required precondition-feasibility obligation separately.
7. Run additional policy-required checks (e.g. compilation, tests, bounds checks).
8. Stage output; publish only after all required gates pass.

## Rejection outcomes

`missing_certificate`, `malformed_certificate`, `ast_hash_mismatch`, `contract_hash_mismatch`, `interface_hash_mismatch`, `checker_unavailable`, `proof_rejected`, `precondition_unsat`, `feasibility_unknown`, `resource_limit`, `policy_failed`.

These outcomes are execution/verdict values, not Belnap values by themselves.

## Guarantees and non-guarantees

PC3 can prove only properties encoded in the chosen sound proof system, under its trusted checker, axioms, semantics and assumptions. A proof of memory safety does not prove business correctness. A certificate checker may be small and cheaper than proof search, but linear-time verification is not universal; state the specific calculus, certificate format and measured complexity.

A proof of a Hoare triple `{Pre} code {Post}` does not establish that `Pre` is satisfiable. If meaningful reachability is required by policy, separately solve/verify `exists x, Pre(x)` and retain the model or proof. Do not infer satisfiability by checking for a non-empty string.

## Threat model

Treat code, ASTs, certificates and producer metadata as untrusted. Check sizes and nesting before parsing; apply fuel/memory/output limits to the checker; reject unknown mandatory proof formats; never let certificate metadata alone assert success.
