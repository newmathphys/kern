# KERN-X Fuel and Resource Metering Proposal v0.1

**Status:** proposed semantics; KERN-X is not implemented by this document.

## 1. Task envelope

Each task must declare or inherit explicit budgets:

```kern
budget "bounded_analysis" {
  fuel_limit = 1000000
  arena_limit_bytes = 67108864
  output_limit_bytes = 1048576
  recursion_limit = 256
  wall_time_ms = 30000
}
```

The example values are illustrative only. Production defaults must be selected using measured workloads and documented policy.

## 2. Fuel definition

Fuel is a non-negative integer counter. Before each VM/bytecode operation, the runtime checks that the operation cost is within the remaining fuel, then subtracts the specified cost. The instruction-cost table is versioned and part of the runtime fingerprint. Changing the cost schedule can change reproducibility and therefore invalidates affected cache keys.

Every loop iteration, recursive transition and internal library operation executed by KERN-X must be charged. A built-in with O(n) work must charge proportionally to the work actually performed or use a bounded algorithm with a known cost model. Calling a large native function for one unit is prohibited unless the function is independently bounded and has its own resource meter.

## 3. Other budgets

- **Memory:** allocation requests must be checked against `arena_limit_bytes` or a declared allocation domain.
- **Output:** records/logs/artifacts written by the task cannot exceed `output_limit_bytes` without a controlled failure.
- **Recursion/stack:** recursion depth and stack or VM stack are bounded.
- **Host calls:** filesystem, process, network, database, GPU and external-tool calls require explicit capabilities and per-call deadlines/quotas.
- **Wall time:** optional deadline triggers cancellation where supported. The engine must not claim strict wall-time termination if a host call cannot be interrupted.
- **Concurrency:** task count, worker slots, handles and file descriptors are bounded.

## 4. Termination claim

If every VM transition consumes a positive finite amount of fuel and the starting fuel is finite, the number of VM transitions is finite. This does not by itself bound time spent inside host operations, operating-system scheduling, page faults, GPU kernels, device drivers, or uninterruptible calls. A practical bounded execution guarantee therefore also requires host-call accounting, deadlines/cancellation or process isolation, memory/resource quotas, and bounded publication behavior.

For untrusted KERN-X extensions, the preferred production boundary is an instrumented VM or a separately sandboxed process rather than arbitrary native plugin code in the main engine.

## 5. Failure semantics

Recognized terminal outcomes:

- `success`
- `fuel_exhausted`
- `memory_limit`
- `output_limit`
- `recursion_limit`
- `host_timeout`
- `capability_denied`
- `cancelled`
- `host_failure`
- `invalid_program`
- `internal_error`

Every result records task/source hash, runtime version, budget envelope, fuel consumed, memory high-water mark where observable, host-call counts, logs, and staged output artifact IDs.

## 6. Atomic publication

Tasks write outputs to a staging area. Only `success` permits atomic publication of outputs and snapshot advancement. Budget exhaustion, timeout, cancellation, verifier failure, or internal error MUST leave the last committed snapshot intact. Partial logs may be retained with a `partial` status but cannot replace a valid artifact under the same stable ID without a new version.

## 7. Determinism

Deterministic tasks must not depend on unrecorded clock values, ambient randomness, iteration order of unordered maps, network results, or unspecified host behavior. If such inputs are needed, they must be explicit task inputs and recorded. Fuel determinism is instruction-budget determinism, not a guarantee that wall-clock times match across machines.

## 8. Tests

- infinite VM loop ends with `fuel_exhausted`;
- recursive task respects recursion budget;
- oversized allocation fails before committing state;
- large output stops at configured quota;
- host timeout/cancellation leaves snapshot unchanged;
- unapproved host capability is denied;
- no individual VM opcode bypasses metering;
- long-running native call is prohibited or isolated/cancellable;
- same deterministic input/budget/runtime version gives the same logical result;
- budget failure preserves previous valid snapshot.
