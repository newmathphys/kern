# Differential facts and retractions v0.2

## Event model

Each evidence contribution is identified individually:

`EvidenceEvent = (evidence_id, claim_id, polarity, source_artifact_hash, verifier_run_id, scope_hash, weight_delta, event_epoch)`

`polarity ∈ {positive, negative}`. `weight_delta` is an integer multiplicity or a typed add/retract operation; its allowed domain and duplicate policy must be explicit. A retraction names the exact evidence contribution being removed. It is not an arithmetic inverse of Belnap `JOIN_K`.

## Belnap aggregation

For each claim and exact scope, recompute active support bits from active admissible contributions:

- `p = exists active admissible positive support`;
- `n = exists active admissible negative support`.

Then encode `(p,n)` as N/T/F/B. A source being removed may move B→T, B→F, T→N or F→N, depending on remaining contributions. Record the derivation IDs behind each bit.

## Incremental propagation

- Maintain dependency indexes from artifact/symbol/contract versions to derivations.
- Emit invalidation/retraction events for derivations whose exact inputs changed.
- Recompute only downstream derivations whose input projection changed.
- Batch deltas by epoch and publish a new consistent snapshot after all required incoming updates for the epoch arrive.
- Compare incremental outputs against full recomputation in randomized conformance tests.

## Recursion and negation

Source import cycles are analyzed through SCCs; they are not automatically semantic conflicts. Recursive positive rules require explicit finite-domain/fixed-point semantics. Negation requires stratification or another precisely specified semantics. An unstratified negative cycle is a diagnostic/blocked rule region unless a dedicated semantics proves how it is evaluated.

## Complexity

No generic O(delta) guarantee exists for arbitrary project analyses. Publish per-operator complexity and benchmark update workloads, including high fan-out, diamond-shaped dependencies, deletions, recursive SCCs and widespread interface changes. Differential dataflow is established prior art for incremental/iterative computation (McSherry et al., CIDR 2013), so KERN's contribution must be measured integration and specific semantics, not the bare use of deltas.
