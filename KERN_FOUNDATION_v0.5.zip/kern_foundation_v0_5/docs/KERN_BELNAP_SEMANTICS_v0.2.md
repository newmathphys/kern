# KERN Belnap–Dunn Semantics v0.2

## 1. Evidence pair

For each atomic proposition `c`, KERN computes two admissible-support bits:

- `p(c) = 1` iff the active verification policy admits at least one positive support for exactly `c` in the specified scope;
- `n(c) = 1` iff the active verification policy admits at least one negative support for exactly `c` in the specified scope.

The value is `(p,n)`:

| Name | Bits | `p` | `n` |
|---|---|---:|---:|
| `N` (`NEITHER`) | `00` | 0 | 0 |
| `T` (`TRUE_ONLY`) | `(1,0)` | 1 | 0 |
| `F` (`FALSE_ONLY`) | `(0,1)` | 0 | 1 |
| `B` (`BOTH`) | `11` | 1 | 1 |

For serialized scalar encoding, use `N=0`, `T=1`, `F=2`, `B=3`, with bit 0 = positive support and bit 1 = negative support. The pair notation `(p,n)` lists positive support first; it is not a binary numeral.

## 2. Orders

### Knowledge order `<=k`

`(p1,n1) <=k (p2,n2)` iff `p1 <= p2` and `n1 <= n2`.

- `N` is bottom: no information.
- `B` is top: both kinds of information.
- `T` and `F` are incomparable.

Knowledge join merges information from independent evidence sources:

`JOIN_K(a,b) = (p(a) OR p(b), n(a) OR n(b))`.

Knowledge meet is:

`MEET_K(a,b) = (p(a) AND p(b), n(a) AND n(b))`.

### Truth order `<=t`

The truth order has `F` as bottom and `T` as top, with `N` and `B` incomparable intermediate elements. Logical conjunction and disjunction are operations in this truth order and are not evidence aggregation.

## 3. Operators

For `a=(pa,na)` and `b=(pb,nb)`:

- `NOT_B(a) = (na,pa)`.
- `AND_T(a,b) = (pa AND pb, na OR nb)`.
- `OR_T(a,b) = (pa OR pb, na AND nb)`.
- `JOIN_K(a,b) = (pa OR pb, na OR nb)`.
- `MEET_K(a,b) = (pa AND pb, na AND nb)`.

`AND_T` and `OR_T` implement Belnap–Dunn truth-functional connectives. `JOIN_K` is used to aggregate evidence sources. Do not use one operator as a substitute for the other.

## 4. Truth tables

Rows are the left operand; columns are the right operand. Order is `N,T,F,B`.

### Truth conjunction `AND_T`

| AND | N | T | F | B |
|---|---|---|---|---|
| N | N | N | F | F |
| T | N | T | F | B |
| F | F | F | F | F |
| B | F | B | F | B |

### Truth disjunction `OR_T`

| OR | N | T | F | B |
|---|---|---|---|---|
| N | N | T | N | T |
| T | T | T | T | T |
| F | N | T | F | B |
| B | T | T | B | B |

### Knowledge join `JOIN_K`

Using the support-pair encoding, this is bitwise OR of the two serialized support masks.

| JOIN_K | N | T | F | B |
|---|---|---|---|---|
| N | N | T | F | B |
| T | T | T | B | B |
| F | F | B | F | B |
| B | B | B | B | B |

### Knowledge meet `MEET_K`

This is bitwise AND of the two serialized support masks.

| MEET_K | N | T | F | B |
|---|---|---|---|---|
| N | N | N | N | N |
| T | N | T | N | T |
| F | N | N | F | F |
| B | N | T | F | B |

## 5. Belnap value is not coverage

`N` only describes the currently aggregated evidence set. Coverage is a separate state:

- `not_scanned`
- `partial`
- `scanned_no_evidence`
- `scanned_with_evidence`
- `complete_under_policy`

No evidence because no search was run MUST NOT be presented as a complete negative result. A query against an incomplete source corpus remains incomplete even when the current value is `N`.

## 6. Admissibility and scope

Only evidence accepted by a type-specific policy participates in `p` or `n`. Each evidence record includes polarity, claim scope, method, input hashes, source IDs, and verifier result. An LLM assertion is `hypothesis` by default and does not set `p=1` for a fact merely by being stated.

If a unit test passes, the direct claim might be “test T passed on build B under environment E.” It is not automatically evidence for “all behavior of program P is correct.” A Z3 counterexample refutes the exact formal property represented by the solver encoding, not every vaguely related prose claim. Before merging evidence, KERN checks proposition and scope alignment.

## 7. Truth gate

`e(c)=1` only if all are true:

1. an explicit policy exists for this claim kind;
2. required source provenance is complete;
3. required verification method succeeded;
4. `BelnapValue(c) == T` (positive admissible support with no admissible negative support);
5. coverage meets policy;
6. no unresolved scope ambiguity remains.

For `N`, `F`, or `B`, `e=0`. For `B`, retain both evidence sides and enqueue `resolve_contradiction`. This prevents “explosion” or crashes in project processing, but does not prove the implementation of the policy correct by itself.

## 8. Separation from provenance semiring

A Belnap bilattice assigns evidence-consistency state. Provenance expressions track which source facts jointly or alternatively produced a result. KERN v0.2 keeps them separate until an explicit map is mathematically specified and its laws are proven. Do not assume any two Belnap operators form a semiring.

## 9. Required tests

- Every operator table matches this specification.
- `NOT_B(N)=N`, `NOT_B(T)=F`, `NOT_B(F)=T`, `NOT_B(B)=B`.
- `JOIN_K` is commutative, associative, idempotent; `N` is its identity.
- `MEET_K` is commutative, associative, idempotent; `B` is its identity.
- Evidence aggregation is order-independent.
- LLM text alone cannot make the state `T`.
- A claim with both admitted positive and negative support becomes `B` and creates a contradiction-resolution task.
- Out-of-scope evidence is not merged into either support bit.
- `N + not_scanned` is distinguished from `N + complete_under_policy`.
