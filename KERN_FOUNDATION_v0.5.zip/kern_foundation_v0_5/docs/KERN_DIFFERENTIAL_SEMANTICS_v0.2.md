# Differential semantics and evidence retraction v0.2

## Evidence store

A proposition's Belnap bits are derived from active evidence contributions, not used as the evidence database itself.

Each event has: unique `event_id`, `evidence_id`, proposition/scope ID, polarity (`positive|negative`), action (`add|retract`), source digest, checker/policy digest and epoch. A retraction names a prior active contribution.

For active admissible evidence `E+` and `E-`:

- `p = 1` iff at least one accepted positive contribution is active;
- `n = 1` iff at least one accepted negative contribution is active.

This recomputation gives N/T/F/B. Removing one positive contribution does not clear p if another active positive contribution remains.

## Transactional epochs

1. Collect all changes for an epoch.
2. Validate event identity and retractions.
3. Compute changed source facts and their dependency closure.
4. Recompute affected derived records under the declared rule semantics.
5. Validate no unsupported negative recursion/fixpoint case exists.
6. Commit a new immutable snapshot atomically.

Readers observe the previous committed snapshot until the new epoch is committed.

## Cycles and fixed points

- Source/module import graph: cycles are allowed and analyzed via SCCs.
- Provenance history: immutable versioned derivations must point to previously committed input versions.
- Positive recursive rules: require finite domain and explicit least-fixed-point semantics or a documented engine guarantee.
- Negation: use stratified negation or another explicitly specified semantics. Negation inside the same recursive SCC is rejected unless supported by a formally defined semantics.

## Cost

Target an output-sensitive update: `O(|affected_nodes| + |affected_edges| + local_transfer_cost)` for the affected subgraph. This is not a universal bound for all queries; recursive joins may have large fan-out and non-local properties may force broad recomputation. Test incremental output against a full-recompute oracle on small randomized graphs.
