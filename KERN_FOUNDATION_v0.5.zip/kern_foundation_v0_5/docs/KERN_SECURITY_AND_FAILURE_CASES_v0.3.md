# KERN Security and Failure Cases v0.3

1. **Vacuous precondition:** distinguish unreachable spec from false program claim; require validated feasibility model only when policy requires reachable behavior.
2. **Forged witness text:** no prefix/substring checks; parse model/certificate and run trusted validation.
3. **Certificate/code mismatch:** bind hashes of AST, contract, interfaces, checker and policy.
4. **SMT unknown/timeout:** keep `unknown`, never map to pass/fail.
5. **Negative delta underflow:** reject or quarantine unknown retraction; do not silently decrement to negative active support.
6. **Negation inside SCC:** reject under stratified Datalog profile unless a defined alternative semantics is implemented.
7. **Diamond propagation glitch:** only publish consistent epoch frontiers.
8. **Hash collision/security:** use cryptographic content hashes; stable IDs include canonical namespace and deterministic collision handling. Non-cryptographic secondary hashes are for indexing only.
9. **Malformed `.kbin`:** fuzz lengths, counts, overlaps, offset overflow, unknown required section, bad hash, truncated mmap file and invalid strings.
10. **TOCTOU snapshot mutation:** map only immutable snapshots; compare file identity/size and reject mutation.
11. **HugePage unavailable:** fall back without changing result correctness.
12. **SIMD assumptions:** scalar reference implementation remains oracle; compare SIMD output to scalar for randomized states and supported CPUs.
13. **Fuel bypass:** charge builtins proportionally; block unmetered native plugins in KERN-X.
14. **Host-call hang:** use cancel/timeout or a killable isolated process; fuel alone is insufficient.
15. **Output publication after failure:** stage writes; only successful verified task commits atomically.
16. **False cache hit:** task-specific semantic slice and complete tool/prompt/schema/model fingerprint; conservatively include code bodies when their semantics may matter.
17. **LLM proposal as evidence:** proposal is a hypothesis only; it cannot self-certify its own code.
18. **Conformal misuse:** report calibration data, loss, assumptions and coverage; statistical risk is not an individual proof.
