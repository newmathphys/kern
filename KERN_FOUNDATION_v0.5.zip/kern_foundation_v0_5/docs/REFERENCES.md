# References and technical anchors

1. Stanford Encyclopedia of Philosophy, “Truth Values” — Belnap–Dunn four-valued logic and its interpretation: https://plato.stanford.edu/entries/truth-values/
2. Todd J. Green, Grigoris Karvounarakis, Val Tannen. “Provenance Semirings,” PODS 2007 — https://www.cs.ucdavis.edu/~green/papers/pods07.pdf
3. Google FlatBuffers — direct access to serialized records without ordinary unpacking: https://github.com/google/flatbuffers
4. BLAKE3 official specifications — https://github.com/BLAKE3-team/BLAKE3-specs
5. Gabriel Loaiza-Ganem et al. “Conf-Gen: Conformal Uncertainty Quantification for Generative Models,” ICML 2026, PMLR 306 — https://proceedings.mlr.press/v306/loaiza-ganem26a.html
6. Lean 4, “Induction and Recursion” — well-founded recursion and termination — https://lean-lang.org/theorem_proving_in_lean4/Induction-and-Recursion/
7. Adapton — demand-driven incremental computation — https://adapton.org/

These sources support the individual methods described; they do not prove the novelty or correctness of KERN as an integrated system.
