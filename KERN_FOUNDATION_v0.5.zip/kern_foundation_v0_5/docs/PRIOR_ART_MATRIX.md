# KERN adjacent prior-art matrix (initial, non-exhaustive)

This matrix is a starting point for technical comparison, not a claim of novelty or a completed systematic review.

| Area | Existing work/tool | Established overlap | KERN-specific open question |
|---|---|---|---|
| Four-valued inconsistent information | Belnap–Dunn logic / bilattices | Represents neither/true-only/false-only/both states | Define typed evidence admissibility, coverage, verdict and task scheduling without conflating them |
| Data lineage | Provenance semirings (Green, Karvounarakis, Tannen, 2007) | Algebraic annotation of relational query results and provenance | Integrate versioned source artifacts, verification records and multi-output derivations |
| Incremental computation | Adapton | Demand-driven recomputation of dependencies after changes | Make invalidation policy depend on explicit source slices, agent context and proof/checker versions |
| Zero-copy binary serialization | FlatBuffers | Direct access to serialized data without unpacking each record | Measure KERN-specific graph, provenance, mmap and validation workload against mature alternatives |
| Content hashing | BLAKE3 | Parallel tree hash, incremental/streaming properties | Specify canonical encoding, domain separation and semantic vs integrity hashes |
| Proof/termination checking | Lean 4 well-founded recursion | Formal evidence that specific recursive definitions terminate | Bound KERN-X arbitrary task execution and host operations under an operational budget |
| Conformal methods for generators | Conf-Gen (ICML 2026) | Statistical risk-control framework for certain generative tasks under stated assumptions | Decide whether a calibrated candidate-selection policy improves safety on KERN's own held-out tasks |
| GPU neural-symbolic logic | XLOG (2026 documentation/preprint) | Integrates typed logic programming with probabilistic/epistemic/neural-symbolic paths and GPU execution | Evaluate whether KERN needs a logic-programming backend or should remain a project-evidence engine |

## Mandatory rule for novelty claims

To state that KERN provides a capability “not found elsewhere”, document:

1. a dated search protocol and search terms;
2. a list of products, research papers and repositories inspected;
3. exact feature definitions and comparison cases;
4. a reproducible test or proof showing a capability distinction;
5. review status and known uncertainty.

Without this, describe the design as a proposed integration or engineering hypothesis, not as the first system in the world.

## Sources

- Belnap–Dunn: https://plato.stanford.edu/entries/truth-values/
- Provenance semirings: https://www.cs.ucdavis.edu/~green/papers/pods07.pdf
- Adapton: https://adapton.org/
- FlatBuffers: https://github.com/google/flatbuffers
- BLAKE3: https://github.com/BLAKE3-team/BLAKE3-specs
- Conf-Gen: https://proceedings.mlr.press/v306/loaiza-ganem26a.html
- Lean 4 termination: https://lean-lang.org/theorem_proving_in_lean4/Induction-and-Recursion/
- XLOG preprint (Sept. 2026): https://arxiv.org/abs/2609.27203
