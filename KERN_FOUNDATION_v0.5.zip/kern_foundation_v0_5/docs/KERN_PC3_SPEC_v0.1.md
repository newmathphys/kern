# KERN PC3 — Proof-Carrying Code Completion Specification v0.1

## 1. Completion envelope

When a policy requires proof-carrying completion, the model returns a structured envelope:

```text
PC3Completion {
  ast_or_patch,
  target_scope,
  contract_id,
  preconditions,
  postconditions,
  certificate,
  proof_system_id,
  checker_policy_id,
  imports_fingerprint,
  declared_effects,
  producer_metadata
}
```

The code is initially held in a staging artifact and is not written into the active project before acceptance. A valid envelope is necessary, but not sufficient: the implementation must independently verify it.

## 2. Certificate binding

The proof record must bind at minimum:

- canonical AST/patch hash;
- contract and property hash;
- type/interface/import environment fingerprint;
- proof calculus / certificate grammar version;
- checker binary/version and policy hash;
- relevant target model or ABI assumptions;
- theorem/property IDs covered;
- referenced lemmas/certificates.

Any mismatch invalidates the certificate. A proof for a different AST, weaker contract or old interface cannot be reused.

## 3. Assurance profiles

Policies select the required assurance tier:

- `P0`: syntactic/type validation only; no functional proof claim.
- `P1`: compiler and declared safety checks.
- `P2`: proof-carrying safety/refinement properties checked by a small trusted checker.
- `P3`: theorem-specific functional correctness under an explicit formal model.

A P1/P2/P3 artifact must never be reported as proving more than its policy states. Projects may require P2/P3 for safety-critical modules and allow P0/P1 elsewhere. If certificate generation fails, the engine records a rejected candidate and does not silently weaken the policy.

## 4. Feasibility and anti-vacuity

Separate obligations:

1. `Feasible(Pre)`: find and validate a model of `Pre` if the contract is required to be reachable.
2. `Correct(Pre,Post)`: establish there is no satisfying counterexample to `Pre ∧ ¬Post` under the declared formal model, or provide a sound proof certificate.

Outcomes:

- SAT(Pre) with checked model → feasibility supported for this encoding.
- UNSAT(Pre) → `VACUOUS_PRECONDITION`, unless policy marks the branch intentionally unreachable.
- SAT(Pre ∧ ¬Post) with checked model → `COUNTEREXAMPLE`.
- UNSAT(Pre ∧ ¬Post) → property proved relative to the formalization and solver/checker trust model.
- UNKNOWN/TIMEOUT → `UNVERIFIED`.

A feasibility model is not a correctness certificate. A nonempty input set does not show that the code meets its postcondition.

## 5. Trusted computing base

List all trusted components: parser/canonicalizer for the proof target, certificate checker, hash implementation, contract elaborator, and external solver if solver answers are trusted rather than proof-checked. If the SMT solver does not emit a checked certificate, label the result `solver_trusted`, not `proof_kernel_checked`.

## 6. Complexity claims

The implementation may claim `O(|AST| + |π|)` checking only if the defined proof format can be parsed and checked within that bound and the checker is measured/analysed. It is not a general property of PCC. The proof producer may perform expensive search; KERN meters it separately.

## 7. Acceptance flow

`model proposal → parse AST → canonicalize → validate type/contracts → verify certificate binding → run trusted certificate checker → run policy-required tests → stage artifacts → publish atomically`.

A test suite does not substitute for a required proof, and a proof does not substitute for runtime/integration tests whose properties are outside the formal contract.

## 8. Mandatory adversarial tests

- certificate for a different AST rejected;
- certificate for a weaker/different postcondition rejected;
- interface fingerprint change invalidates certificate;
- empty/malformed certificate rejected;
- fake text such as `model_sat_witness...` is not accepted as a model;
- UNSAT precondition causes a vacuity diagnostic, not a false claim by default;
- SAT counterexample to `Pre ∧ ¬Post` rejects the property;
- solver timeout yields unknown;
- publish never occurs before successful policy checks;
- failed validation preserves the previous snapshot.
