# PC3 / Proof-Carrying Completion acceptance contract v0.2

## Completion object

`Completion = { source_or_AST, source_digest, contract_digest, dependency_interface_digests, target_environment_digest, checker_policy_digest, certificate_digest, producer_trace_ref }`.

The object is initially `STAGED_UNTRUSTED`. It is not written into the active project tree until policy checks pass.

## Required steps

1. Parse and canonicalize source/AST.
2. Hash canonical AST and contract.
3. Resolve and hash relevant interfaces and declared semantic dependencies.
4. Build or verify proof obligations for the selected policy.
5. Obtain a certificate from a proof checker or solver path that supports the needed guarantee.
6. Check the certificate with the configured trusted checker or independently validated proof mechanism.
7. Confirm certificate metadata binds to the exact AST, contract, interfaces, checker build and policy.
8. Run additional required tests/security checks.
9. Stage final artifacts and atomically publish only if every mandatory check passes.

## Outcomes

- `ACCEPTED_FOR_POLICY`: all required checks passed for the explicitly named policy.
- `REJECTED_COUNTEREXAMPLE`: a validated counterexample was found for a specified obligation.
- `REJECTED_CERTIFICATE`: invalid, malformed or mismatched certificate.
- `INCONCLUSIVE`: solver returned unknown/timeout or proof route is unsupported.
- `OUT_OF_RESOURCES`: proof/analysis quota exhausted.
- `BLOCKED`: required tool, interface, data, or permission unavailable.

These outcomes must not be projected onto the Belnap truth value without evidence contributions and a policy-defined mapping.

## What is proven

The checker proves only the property encoded in its proof calculus/verification condition, under recorded assumptions. Memory safety does not imply business correctness; tests do not prove universal correctness; a nonempty precondition witness does not prove the postcondition.

## Complexity

No default complexity claim applies to all certificates. Each checker documents cost in terms of certificate bytes, proof nodes, term sizes, solver work and/or kernel reductions. Enforced quotas provide a resource outcome, not a proof that checking always finishes under a fixed physical time.
