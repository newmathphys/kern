# KERN v0.3 Architectural Decisions

## ADR-0009 — PC3 is policy-gated

**Decision:** use proof-carrying completion for selected assurance profiles and modules, not as a magical claim that every generated function is universally correct.  
**Reason:** a proof only establishes its encoded property under its assumptions; exact binding to AST/contracts is mandatory.  
**Consequence:** staged outputs require checker verdicts and policy acceptance before publication.

## ADR-0010 — B4 and provenance algebra are separate

**Decision:** B4 is evidence support state; provenance is lineage; verifier result is its own typed object.  
**Reason:** B4 lattice operations are not automatically semiring operations.  
**Consequence:** separate APIs/types and conformance tests; never overload `⊗` without a versioned formal definition.

## ADR-0011 — differential data uses signed relation events

**Decision:** retract evidence tokens/multiplicities and recompute active support; do not subtract from the two-bit B4 state.  
**Reason:** knowledge join is idempotent and lacks a general inverse.  
**Consequence:** retain source token identity and deletion-aware provenance.

## ADR-0012 — `.kbin` v3 uses immutable chunks and relative locators

**Decision:** no in-place mutation of published mapped snapshots; use a chunk directory, `u64` file offsets and bounded within-chunk offsets.  
**Reason:** in-place layout shifts invalidate locators and concurrent writes create TOCTOU hazards.  
**Consequence:** rebuild changed chunks and atomically publish a new manifest/snapshot.

## ADR-0013 — HugePages are optional

**Decision:** regular mmap is the baseline; HugeTLB/THP is an optional benchmark profile with fallback.  
**Reason:** support, reservation, privileges, architecture and fragmentation vary.  
**Consequence:** no correctness or speed guarantee depends on huge pages.

## ADR-0014 — metering bounds VM steps, not arbitrary wall time

**Decision:** fuel is charged to VM steps and proportional-cost builtins; host calls require quotas/timeouts/cancellation/isolation.  
**Reason:** uninterruptible external operations are outside an instruction counter.  
**Consequence:** report resource exhaustion and host timeout separately.
