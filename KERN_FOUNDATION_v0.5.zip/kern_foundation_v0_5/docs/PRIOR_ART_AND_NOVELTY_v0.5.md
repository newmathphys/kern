# Prior art and novelty discipline for KERN v0.5

This register prevents known methods from being accidentally marketed as new discoveries.

| KERN component | Established prior art | KERN-specific research question |
|---|---|---|
| Four-valued truth/evidence logic | Belnap–Dunn FOUR / bilattices | Does KERN's separate coverage, provenance and lifecycle model improve auditability? |
| Proof-carrying code | Necula, POPL 1997 | How are claims/contracts/model edits bound to exact immutable inputs? |
| Proof-carrying code completions (PC³) | Kamran, Devanbu & Stanford, UC Davis vision paper, ASEW 2024; PCCC prototype | Can KERN generalize the proof gate across a native project engine while retaining soundness and usability? |
| Proof-carrying agent actions (PCAA) | arXiv 2606.04104, 2026 preprint | How does KERN bind pre-action authorization, assumptions, execution and outcome evidence? |
| Differential dataflow | CIDR 2013, Microsoft Research, TimelyDataflow implementation | How efficiently can evidence additions/retractions and proof dependency updates be maintained? |
| Conformal generation | Shahrokhi et al., UAI/PMLR 2025 | Where can calibrated candidate selection help while keeping formal proof as a separate gate? |
| Memory mapping/HugeTLB | Linux `mmap(2)` and kernel documentation | Does KERN's chunked immutable format improve the measured workloads over existing formats? |

## Claim policy

Use phrases such as `KERN combines`, `KERN implements`, or `KERN evaluates` until evidence supports stronger claims. Do not say `invented`, `first`, `guaranteed faster`, `zero hallucinations`, `always instant`, or `universally linear` without a defensible literature review, precise scope and reproducible empirical results.

## Primary references

- Necula (1997): https://doi.org/10.1145/263699.263712
- PC³ vision paper (2024): https://web.cs.ucdavis.edu/~cdstanford/doc/2024/ASEW24b.pdf
- PC³ prototype: https://github.com/DavisPL/PCCC
- PCAA preprint (2026): https://arxiv.org/abs/2606.04104
- Differential dataflow (2013): https://www.microsoft.com/en-us/research/publication/differential-dataflow/
- Conformal prediction sets for deep generative models (2025): https://proceedings.mlr.press/v286/shahrokhi25a.html
- Linux mmap: https://www.man7.org/linux/man-pages/man2/munmap.2.html
- Linux HugeTLB: https://docs.kernel.org/admin-guide/mm/hugetlbpage.html
