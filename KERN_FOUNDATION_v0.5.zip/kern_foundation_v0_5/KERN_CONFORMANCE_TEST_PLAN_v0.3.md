# KERN Conformance Plan v0.3

## A. Belnap B4
- All four encodings: N=0, T=1, F=2, B=3.
- `JOIN_K(a,b)=a|b`; `MEET_K(a,b)=a&b`.
- Negation swaps support planes.
- `AND_T=(p_a∧p_b, n_a∨n_b)`; `OR_T=(p_a∨p_b,n_a∧n_b)`.
- Assert `JOIN_K(T,F)=B`; assert `AND_T(T,F)=F`.
- Exhaustive all 16 operand pairs per operation; associativity/commutativity/idempotence tests where applicable.
- Ensure source status cannot set Belnap directly without evidence policy.

## B. PC3
- AST/contract/import/checker/policy hash mismatch → reject.
- Untrusted output is staged; invalid certificate cannot publish.
- Fake witness strings are rejected.
- Pre SAT and `Pre ∧ ¬Post` SAT are not conflated.
- Pre UNSAT → vacuity diagnostic; policy may allow explicitly unreachable branch.
- Solver UNKNOWN/TIMEOUT → unknown.
- Certificate checker tests bind exact theorem/property and target code.

## C. Differential/retractions
- Differential results match full recomputation for deterministic generated sequences.
- Retract one of two positive evidence tokens; positive support remains.
- Retract last positive evidence; positive plane clears.
- `T ⊕ F` becomes B; retract negative token restores T if positive token remains.
- Unknown/duplicate event ID behavior is specified and tested.
- No negative weight can underflow silently.
- Diamond graph commits only epoch-consistent states.
- Negative recursion inside SCC rejected under stratified profile.

## D. `.kbin` v3 reader/writer
- Header exactly 128 bytes, directory entry exactly 96 bytes.
- Little-endian roundtrip on all fields.
- Reject integer overflow, offsets outside file, overlap, incorrect alignment, bad hash, invalid chunk reference, truncated file, unknown mandatory feature.
- Unknown optional section can be skipped after validating its range/hash.
- Reader never casts unchecked file memory into native structs.
- Writer/reader round trip preserves stable IDs and semantics.
- Atomic publication leaves old snapshot intact on failure.
- Concurrent reader always sees a complete old or new snapshot, never an in-place mutation.

## E. Cache
- Comment-only change preserves key only for a task whose declared semantic projection excludes those comments.
- Docstring change invalidates a task that included the docstring.
- Function body change invalidates implementation correctness checks.
- Signature/contract change invalidates interface consumers.
- Cycle SCC hashes deterministic under canonical ordering.
- Model/prompt/tool/schema change invalidates relevant response cache.

## F. Resource limits
- Infinite VM loop reaches `FUEL_EXHAUSTED`.
- Builtin work is proportionally charged.
- Memory/output/recursion quota failure does not publish output.
- Host timeout or killed subprocess preserves previous snapshot.
- Unsupported HugeTLB falls back without correctness change.

## G. Performance benchmarks
- Dataset scales: 10^4, 10^5, 10^6 records; optional 10^7 if hardware permits.
- Compare full rebuild vs incremental updates, `.kbin` vs SQLite and FlatBuffers-compatible baseline where feasible.
- Report cold/warm open, first-query latency, sequential and random access, page faults, RSS, allocations, file size, validation time, and delta update latency.
- Report machine, OS/kernel, filesystem, CPU, memory, compiler/tool versions, page-size mode and median/dispersion.
- No claimed speedup without same-workload baseline and raw results.
