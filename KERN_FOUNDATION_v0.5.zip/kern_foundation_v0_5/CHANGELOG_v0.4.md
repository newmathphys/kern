# Changelog — KERN Foundation v0.4

- Integrated scalar Belnap operations with canonical `(p,n)` bit mapping.
- Added a separate TruthGate and explicit CoverageState/VerificationVerdict.
- Added Zig reference modules for Belnap operations, truth admission, fuel budgets and checked relative references/ranges.
- Added a Lean source with core algebraic lemmas; compiler verification remains pending because Lean is unavailable.
- Added `.kbin` v4 draft with 64-bit range fields and correct chunk-reference arithmetic.
- Added PC3/SMT query mapping and typed completion/verification schemas.
- Clarified retraction behavior: support contributions are removed by identity; B4 knowledge join has no general inverse.
- Corrected overclaims about SAT, certificate complexity, mmap, huge pages, SIMD throughput, cycles, and O(delta) recomputation.
