# KERN Foundation v0.3

This is a specification package for a proposed native KERN engine, not a completed implementation.

Start here:
- `KERN_FOUNDATION_SPEC_v0.3.md` — integrated architecture and semantics.
- `TECHNICAL_AUDIT_OF_PROPOSAL.md` — accepted ideas and corrections to overstrong/incorrect claims.
- `docs/KERN_PC3_SPEC_v0.1.md` — proof-carrying completions.
- `docs/KERN_DIFFERENTIAL_ENGINE_v0.1.md` — additions/retractions, Datalog-style incremental maintenance.
- `docs/KERNBIN_FORMAT_v0.3.md` — proposed chunked binary format.
- `docs/KERN_RESOURCE_AND_MEMORY_MODEL_v0.3.md` — mmap, HugePages, SIMD and resource envelopes.
- `docs/KERN_SECURITY_AND_FAILURE_CASES_v0.3.md` — adversarial cases.
- `KERN_CONFORMANCE_TEST_PLAN_v0.3.md` — requirements for implementation tests.
- `history/v0.2/` — prior specification package snapshot.

No Zig/Lean compiler was available in the generation environment. The package files and reference JSON are data/specification artifacts; do not describe the Zig engine, native conformance suite, or Lean proofs as built/verified yet.
