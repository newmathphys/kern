# KERN Foundation Specification — current version

The current normative version is [`KERN_FOUNDATION_SPEC_v0.5.md`](KERN_FOUNDATION_SPEC_v0.5.md).

The `.v0.2`–`.v0.4` files are preserved as prior versions, not current authority.
