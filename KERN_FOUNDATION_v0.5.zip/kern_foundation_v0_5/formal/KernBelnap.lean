import Lean

namespace KernV04

/-- Two independent support bits: p (positive), n (negative). -/
structure Belnap where
  p : Bool
  n : Bool
  deriving DecidableEq, Repr

def N : Belnap := ⟨false, false⟩
def T : Belnap := ⟨true, false⟩
def F : Belnap := ⟨false, true⟩
def B : Belnap := ⟨true, true⟩

def notB (a : Belnap) : Belnap := ⟨a.n, a.p⟩
def andT (a b : Belnap) : Belnap := ⟨a.p && b.p, a.n || b.n⟩
def orT (a b : Belnap) : Belnap := ⟨a.p || b.p, a.n && b.n⟩
def joinK (a b : Belnap) : Belnap := ⟨a.p || b.p, a.n || b.n⟩
def meetK (a b : Belnap) : Belnap := ⟨a.p && b.p, a.n && b.n⟩

theorem notB_involutive (a : Belnap) : notB (notB a) = a := by
  cases a with
  | mk p n => rfl

theorem notB_N : notB N = N := rfl
theorem notB_T : notB T = F := rfl
theorem notB_F : notB F = T := rfl
theorem notB_B : notB B = B := rfl

theorem joinK_comm (a b : Belnap) : joinK a b = joinK b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem joinK_assoc (a b c : Belnap) : joinK (joinK a b) c = joinK a (joinK b c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        cases ap <;> cases an <;> cases bp <;> cases bn <;> cases cp <;> cases cn <;> rfl

theorem joinK_idem (a : Belnap) : joinK a a = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem joinK_identity_N (a : Belnap) : joinK a N = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem meetK_comm (a b : Belnap) : meetK a b = meetK b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem meetK_assoc (a b c : Belnap) : meetK (meetK a b) c = meetK a (meetK b c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        cases ap <;> cases an <;> cases bp <;> cases bn <;> cases cp <;> cases cn <;> rfl

theorem meetK_idem (a : Belnap) : meetK a a = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem meetK_identity_B (a : Belnap) : meetK a B = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem evidence_conflict : joinK T F = B := rfl
theorem truth_conjunction_TF : andT T F = F := rfl
theorem truth_disjunction_TF : orT T F = T := rfl

theorem deMorgan_andT (a b : Belnap) : notB (andT a b) = orT (notB a) (notB b) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem deMorgan_orT (a b : Belnap) : notB (orT a b) = andT (notB a) (notB b) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem andT_distrib_orT (a b c : Belnap) : andT a (orT b c) = orT (andT a b) (andT a c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        cases ap <;> cases an <;> cases bp <;> cases bn <;> cases cp <;> cases cn <;> rfl

theorem orT_distrib_andT (a b c : Belnap) : orT a (andT b c) = andT (orT a b) (orT a c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        cases ap <;> cases an <;> cases bp <;> cases bn <;> cases cp <;> cases cn <;> rfl

theorem joinK_absorption (a b : Belnap) : joinK a (meetK a b) = a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem meetK_absorption (a b : Belnap) : meetK a (joinK a b) = a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases ap <;> cases an <;> cases bp <;> cases bn <;> rfl

theorem andT_identity_T (a : Belnap) : andT a T = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem andT_annihilator_F (a : Belnap) : andT a F = F := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem orT_identity_F (a : Belnap) : orT a F = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem orT_annihilator_T (a : Belnap) : orT a T = T := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

end KernV04
