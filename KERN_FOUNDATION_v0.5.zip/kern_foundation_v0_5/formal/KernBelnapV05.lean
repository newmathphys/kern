/-!
KERN v0.5 finite mathematical kernel for Belnap-Dunn FOUR.
This file is intended for Lean 4. It has not been compiled in the current environment.
It deliberately formalizes the four-valued algebra only; it does not claim to prove the KERN runtime.
-/
namespace KERN.V05

structure Belnap where
  p : Bool
  n : Bool
  deriving DecidableEq, Repr

def N : Belnap := ⟨false, false⟩
def T : Belnap := ⟨true, false⟩
def F : Belnap := ⟨false, true⟩
def B : Belnap := ⟨true, true⟩

def notB (a : Belnap) : Belnap := ⟨a.n, a.p⟩
def andT (a b : Belnap) : Belnap := ⟨a.p && b.p, a.n || b.n⟩
def orT (a b : Belnap) : Belnap := ⟨a.p || b.p, a.n && b.n⟩
def joinK (a b : Belnap) : Belnap := ⟨a.p || b.p, a.n || b.n⟩
def meetK (a b : Belnap) : Belnap := ⟨a.p && b.p, a.n && b.n⟩

def leqK (a b : Belnap) : Prop := (a.p = true → b.p = true) ∧ (a.n = true → b.n = true)
def leqT (a b : Belnap) : Prop := (a.p = true → b.p = true) ∧ (b.n = true → a.n = true)

theorem notB_involutive (a : Belnap) : notB (notB a) = a := by
  cases a with
  | mk p n => rfl

theorem notB_T : notB T = F := rfl
theorem notB_F : notB F = T := rfl
theorem notB_N : notB N = N := rfl
theorem notB_B : notB B = B := rfl

theorem joinK_comm (a b : Belnap) : joinK a b = joinK b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [joinK, Bool.or_comm]

theorem joinK_assoc (a b c : Belnap) : joinK (joinK a b) c = joinK a (joinK b c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        simp [joinK, Bool.or_assoc]

theorem joinK_idem (a : Belnap) : joinK a a = a := by
  cases a with
  | mk ap an => simp [joinK]

theorem joinK_identity_N (a : Belnap) : joinK a N = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem meetK_comm (a b : Belnap) : meetK a b = meetK b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [meetK, Bool.and_comm]

theorem meetK_assoc (a b c : Belnap) : meetK (meetK a b) c = meetK a (meetK b c) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      cases c with
      | mk cp cn =>
        simp [meetK, Bool.and_assoc]

theorem meetK_idem (a : Belnap) : meetK a a = a := by
  cases a with
  | mk ap an => simp [meetK]

theorem meetK_identity_B (a : Belnap) : meetK a B = a := by
  cases a with
  | mk ap an => cases ap <;> cases an <;> rfl

theorem evidence_conflict : joinK T F = B := rfl
theorem truth_conjunction_T_F : andT T F = F := rfl
theorem truth_disjunction_N_T : orT N T = T := rfl
theorem belnap_B_and_T : andT B T = B := rfl

theorem andT_comm (a b : Belnap) : andT a b = andT b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [andT, Bool.and_comm, Bool.or_comm]

theorem orT_comm (a b : Belnap) : orT a b = orT b a := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [orT, Bool.and_comm, Bool.or_comm]

theorem deMorgan_andT (a b : Belnap) : notB (andT a b) = orT (notB a) (notB b) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [notB, andT, orT, Bool.and_comm, Bool.or_comm]

theorem deMorgan_orT (a b : Belnap) : notB (orT a b) = andT (notB a) (notB b) := by
  cases a with
  | mk ap an =>
    cases b with
    | mk bp bn =>
      simp [notB, andT, orT, Bool.and_comm, Bool.or_comm]

/- Anti-vacuity is a policy predicate: an unsatisfiable precondition has no witness.
   This theorem does NOT prove that all unreachable contracts are universally invalid. -/
def PreNonempty {α : Type} (pre : α → Prop) : Prop := ∃ x, pre x

theorem false_precondition_has_no_witness {α : Type} :
    ¬ PreNonempty (fun _ : α => False) := by
  intro h
  rcases h with ⟨x, hx⟩
  exact hx

end KERN.V05
