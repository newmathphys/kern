# Changelog v0.5

- Added source-audited mathematical and implementation notes for the user's expanded blueprint.
- Added reference Zig operations for all five B4 functions, gate admission, shared task fuel, checked relative ranges and query-sensitive SMT interpretation.
- Added a finite exhaustive Python oracle for B4 operation laws and gate/retraction/range cases.
- Added a Lean 4 formalization source for the finite B4 algebra and the narrow anti-vacuity lemma; not compiled in this environment.
- Added PC3 acceptance contract, differential evidence retraction semantics, `.kbin` memory-format safety notes and canonical manifest specification.
- Explicitly removed unsupported claims of universal O(AST), O(delta), zero page faults, zero-allocation full runtime, instant hugepage mmap, and universally guaranteed wall-clock termination.
- Added test matrix for false witnesses, stale certificates, invalid ranges, cache invalidation, SCCs, negative recursion and synthetic report data.
