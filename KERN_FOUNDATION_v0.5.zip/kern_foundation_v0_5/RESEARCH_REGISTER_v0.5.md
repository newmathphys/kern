# KERN research register v0.5

## Established foundations used

1. Belnap–Dunn FOUR / bilattices: four support states and distinct knowledge/truth orders.
2. Proof-Carrying Code: untrusted code can carry a proof checked by a trusted consumer against an explicit safety policy.
3. Differential dataflow: incremental/iterative data-parallel updates with signed changes and time/frontier semantics; it does not imply universal O(delta) complexity.
4. Linux memory mapping and HugeTLB: file-backed virtual mappings and optional large pages; mappings may fault pages in and huge-page allocation can fail.
5. Structural termination / fuel: structurally decreasing recursion and explicit fuel are useful controls; fuel must measure total work and external effects need separate controls.

## KERN-specific research hypotheses (not established results)

- A task-specific canonical semantic slice yields better cache reuse than whole-file hashes without unsound reuse.
- Combining a four-valued evidence lattice with a separate provenance annotation algebra improves conflict traceability.
- Immutable derivation events and differential maintenance reduce recomputation cost on target repositories.
- A chunked SoA/CSR `.kbin` reader improves cold-start and repeated-query metrics against SQLite/JSON/FlatBuffers baselines on specified workloads.
- PC3 integration into agent editing yields fewer unsafe published edits at acceptable verification cost.

## Required evidence before claiming novelty or advantage

- prior-art review and terminology comparison;
- formal definitions and proofs of algebraic laws;
- soundness argument for the trusted checker boundary;
- reference implementation and conformance tests;
- reproducible benchmarks with baseline versions and exact datasets;
- failure cases and ablation studies;
- independent review of claimed novelty.
