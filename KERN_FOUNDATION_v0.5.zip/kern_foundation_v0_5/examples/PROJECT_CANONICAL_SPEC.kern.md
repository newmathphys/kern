---
kind: kern-canonical-manifest-example
manifest_schema: 0.1
project_id: "SYNTHETIC:example-project"
snapshot_id: "SYNTHETIC:example-snapshot"
root_digest: "blake3:0000000000000000000000000000000000000000000000000000000000000000"
generated_by: "kernc/UNIMPLEMENTED"
provenance_status: partial
synthetic: true
---

# Example canonical manifest (synthetic; not evidence about a real project)

This file demonstrates the intended human/machine dual view. All IDs and digests below are placeholders. The current reference implementation does not yet parse this file.

## Machine block

```kern
manifest snapshot="SYNTHETIC:example-snapshot" schema="kern/0.5" {
  artifact id="A1" path="src/example.zig" digest="SYNTHETIC:content-hash"
  claim id="C1" statement="example proposition" value=N coverage=partial
  evidence id="E1" source="A1" kind="source_span" span="1:1-1:20" admissible=false
  relation id="R1" from="C1" to="E1" kind="candidate_support"
}
```

## Coverage

No real project was scanned for this example. No percentages or admitted claims are provided.

## Trust boundary

Only validated machine records tied to real source digests and verification-run IDs can participate in admission. Human prose and synthetic data are non-authoritative.
