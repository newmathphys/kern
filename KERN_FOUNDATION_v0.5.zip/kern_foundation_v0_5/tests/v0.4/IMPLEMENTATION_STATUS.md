# v0.4 implementation status

| Component | Included | Executed/compiled in authoring environment | Status |
|---|---:|---:|---|
| Belnap Zig scalar operations | yes | no Zig toolchain found | source + tests supplied, compilation pending |
| Truth admission gate | yes | no Zig toolchain found | source + tests supplied, compilation pending |
| Fuel accounting | yes | no Zig toolchain found | source + tests supplied, compilation pending |
| Relative references / range validation | yes | no Zig toolchain found | source + bounds tests supplied, compilation pending |
| Typed SMT query result interpretation | yes | no Zig toolchain found | source + tests supplied; no actual solver call is implemented |
| Lean algebraic identities | yes | no Lean toolchain found | source supplied, theorem checking pending |
| `.kbin` v4 byte layout | specification | format-level arithmetic reviewed | no native reader/writer yet |
| PC3 verification adapter | contract only | no external verifier invoked | not implemented |
| SMT bridge | deliberately not faked | no solver invoked | not implemented; any placeholder must return `not_run` |
| Differential engine | specification | no runtime | not implemented |
| Performance benchmarks | none | none | no performance claims accepted |

The Python runtime is not part of KERN's intended native implementation. Any offline scripts used to audit test vectors are development-only oracles, not production dependencies.
