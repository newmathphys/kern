#!/bin/sh
set -eu
if ! command -v zig >/dev/null 2>&1; then
  echo "ERROR: zig executable not found; native tests were not run." >&2
  exit 127
fi
printf 'Zig toolchain: '
zig version
zig test src/core/belnap_v05.zig
zig test src/core/truth_gate_v05.zig
zig test src/core/fuel_v05.zig
zig test src/format/rel_ref_v05.zig
zig test src/verifier/smt_result_v05.zig
