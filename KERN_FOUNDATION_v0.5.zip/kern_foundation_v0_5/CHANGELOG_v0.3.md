# KERN Foundation v0.3 — changelog

## Added
- PC3/Proof-Carrying Completion policy and certificate-binding requirements.
- Differential provenance delta model, retractions and rules for stratified negation.
- Chunked `.kbin` v3 design, portable relative references and optional huge-page advice.
- Explicit audit of proof complexity, SAT/UNSAT interpretation, zero-copy, TLB and SIMD claims.
- Anti-vacuity as a separate feasibility obligation, not a truth label.
- Resource/correctness vulnerability cases and conformance vectors.

## Corrected
- Belnap evidence aggregation is distinct from truth conjunction and provenance multiplication.
- SAT of `Pre` is not a correctness proof; SAT of `Pre ∧ ¬Post` is a counterexample to the encoded postcondition.
- Retractions are not implemented by subtracting from idempotent B4 join; active evidence/provenance is maintained.
- Cycles in source dependencies are not cycles in the immutable provenance snapshot; SCCs and fixed-point rules are explicit.
- `mmap` is zero-copy-oriented, not zero-cost; HugePages, 64-byte lines, SIMD gains, and O(n) proof-checking claims require measurement/proof.
- A string containing `model_sat_witness` is not a SAT model or certificate.

## Compatibility
- KERN-D language concept remains compatible at the declaration level.
- `.kbin` moves to format major 3. v2 reader compatibility is a migration tool requirement, not wire compatibility.
