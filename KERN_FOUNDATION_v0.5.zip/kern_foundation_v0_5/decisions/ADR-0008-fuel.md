# ADR-0008: Meter KERN-X with fuel and host-resource quotas

**Status:** Proposed for the future KERN-X extension.

## Decision
Every VM instruction is metered under a versioned cost schedule. Memory, output, recursion, host operations and optional wall-clock time have separate quotas. Side effects are staged and only committed on success.

## Rationale
Fuel bounds instruction count only if no instruction or native call bypasses charging. Host operations and wall time require separate controls.

## Consequences
KERN-X is not specified as unrestricted native plugins. Untrusted tasks require an instrumented VM or isolated process.
