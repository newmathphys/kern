# ADR-0007: Semantic-slice cache identities

**Status:** Accepted for v0.2 specification.

## Decision
Use a domain-separated BLAKE3 key over a canonical task identity and an explicit task-specific input projection, including model/prompt/tool/schema versions and generation settings.

## Rationale
A whole-repository hash over-invalidates; interface-only hashes can unsafely under-invalidate implementation-sensitive tasks. The projection is declared by task and checked against the context actually sent to the model.

## Consequences
Cache correctness tests are mandatory. A cached model response remains derived output and never bypasses claim verification.
