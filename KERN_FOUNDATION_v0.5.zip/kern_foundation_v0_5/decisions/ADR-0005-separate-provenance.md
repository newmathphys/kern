# ADR-0005: Separate source graph, build graph and provenance graph

**Status:** Accepted for v0.2 specification.

## Decision
Maintain `G_src`, `G_build`, and `G_prov` separately. Source dependency cycles are represented with SCCs. Provenance DAG acyclicity is enforced by immutable versioned inputs and causal derivations.

## Rationale
A bipartite graph is not automatically acyclic. Cycle freedom comes from a construction invariant, not node partitioning. Recursive/fixed-point evaluation must be explicitly represented and bounded.
