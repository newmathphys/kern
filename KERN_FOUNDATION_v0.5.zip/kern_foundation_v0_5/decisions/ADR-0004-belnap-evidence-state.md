# ADR-0004: Belnap evidence state is separate from verdict and coverage

**Status:** Accepted for v0.2 specification.

## Decision
Use a four-valued Belnap–Dunn state for admissible positive/negative evidence. Keep claim coverage and typed verification verdict as separate fields. The gate `e` is computed from the claim-specific policy and cannot be set in source.

## Rationale
A three-state enum conflates absence of data with conflicts. Four values preserve neither/true-only/false-only/both. Coverage distinguishes not-searched from searched-with-no-evidence. Typed verdicts prevent a test pass, counterexample, proof result and LLM assertion from being treated as interchangeable.

## Consequences
A conflict remains a first-class state and queues resolution work. A semantic scope check is required before evidence contributes support bits.
