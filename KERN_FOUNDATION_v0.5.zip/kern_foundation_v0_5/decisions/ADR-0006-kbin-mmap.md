# ADR-0006: `.kbin` v2 uses checked offsets and read-only memory mapping

**Status:** Accepted for v0.2 proposal; performance unproven.

## Decision
Use fixed header/directory sizes, 64-bit offsets, section-relative record references, explicit endian decoding, read-only mappings and integrity hashes. Require range/overlap validation before data access.

## Rationale
Offset-based records are relocatable and allow direct access without rebuilding the entire heap object graph. `mmap` does not eliminate page faults, I/O, validation, or all allocations.

## Consequences
Format code needs adversarial bounds tests, mapping-lifetime discipline, atomic snapshot publication and benchmarks against an established zero-copy format.
