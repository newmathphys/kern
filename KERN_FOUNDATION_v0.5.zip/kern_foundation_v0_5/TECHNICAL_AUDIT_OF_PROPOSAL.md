# Technical audit of the submitted KERN proposals

This audit distinguishes useful design directions from claims that must not become specification guarantees without further work.

## Accepted, with precise scope

1. **Belnap B4:** adopt the four states and knowledge-order aggregation for evidence; keep logical conjunction/disjunction separate.
2. **PC3/PCC:** adopt certificate-carrying changes under explicit assurance policies. Bind certificates to exact code, contracts, interfaces and checker versions.
3. **Differential maintenance:** keep signed deltas/retractions and incremental query maintenance, including evidence provenance.
4. **Chunked immutable binary snapshots:** use mmap views, relative offsets, safe bounds checks and append-only chunks.
5. **Fuel and memory budgets:** meter interpreter work and bound host calls/resources.
6. **SCC-aware semantic cache:** handle cyclic source components explicitly; include only task-relevant semantic inputs.
7. **Huge pages and SoA/CSR/SIMD:** keep as benchmark-controlled optimization profiles with fallback.

## Corrections that matter

### A. Belnap operations

With encoding `N=0b00`, `T=0b01`, `F=0b10`, `B=0b11`, where bit 0 is positive support and bit 1 negative support:

- evidence merge: `JOIN_K(a,b) = a | b`; hence `JOIN_K(T,F)=B`;
- logical conjunction: `AND_T(a,b) = (p_a & p_b, n_a | n_b)`; hence `AND_T(T,F)=F`;
- logical disjunction: `OR_T(a,b) = (p_a | p_b, n_a & n_b)`;
- negation swaps the two support bits.

The supplied `otimes` implementation that returns B for `T` combined conjunctively with `F` is not Belnap truth conjunction. A provenance-semiring multiplication is a third operation, defined on a different algebra/type until its laws are proven.

### B. SMT/SAT semantics and anti-vacuity

A textual marker such as `model_sat_witness...` proves nothing. A model must be parsed against a specific formula and validated by the declared trusted checker. `SAT(Pre)` only shows feasibility of that encoded precondition. `SAT(Pre ∧ ¬Post)` gives a counterexample to the encoded postcondition. `UNSAT(Pre ∧ ¬Post)` supports the Hoare property only under the encoding/theory/solver trust assumptions. `UNSAT(Pre)` identifies a vacuous/unreachable precondition, not automatically a refutation of the original prose claim.

Vacuity checks should be policy-driven: reject if a public callable contract must be reachable; permit an explicitly declared unreachable/dead branch where intended. Feasibility is necessary but never sufficient for correctness.

### C. Proof-Carrying Code

PCC traditionally checks an explicit safety policy and requires the certificate to match the exact code and policy. It does not mean arbitrary business correctness is proven automatically. Complexity is proof-format/checker-specific. Do not claim universal O(n), microseconds or no solver use unless the exact checker and certificate grammar support that claim and benchmarks back it.

### D. Differential retractions

Belnap `JOIN_K` is idempotent and lacks a subtraction inverse. A negative delta must remove a specific active evidence token / decrement a differential multiplicity, then recompute aggregate support (or use a correct differential query engine). Do not implement `B4 - evidence` by arithmetic on the two-bit status.

Incremental cost depends on indexes, joins, recursion, SCC maintenance and output size; O(|delta|) is not a universal complexity guarantee. Differential Datalog with negation requires stratification or another explicit well-defined non-monotonic semantics. A negative edge inside an SCC should trigger a specified semantic error/blocked rule, not automatically be labeled Belnap conflict.

### E. Binary layout and physical assumptions

- `mmap` maps virtual memory; it does not guarantee zero page faults, zero validation cost or zero heap allocations elsewhere.
- Native `extern struct` casts over file bytes are unsafe unless size, alignment, endianness and every field range are validated. Prefer generated accessors and explicit LE decoding.
- `u32` offsets cannot address files/sections beyond 4 GiB. v3 uses `u64` section offsets and 32-bit offsets only within bounded chunks.
- `chunk_id:u12 + offset:u20` cannot address an entire 2 MiB chunk because 20 bits cover only 1 MiB. Use a wider `RelRef` or a precisely smaller chunk.
- Size equality (64 bytes) does not imply 64-byte alignment. Compile-time alignment assertions are separate; alignment is an optimization, not correctness.
- HugeTLB mappings may fail if pages are unsupported/unreserved, unavailable, fragmented or permission-gated. Treat as optional with fallback. No universal TLB-miss percentage should be stated.
- SIMD width and cycles vary across hardware and workload. 64 facts in one clock cycle is not a portable guarantee.
- Unkeyed BLAKE3 protects integrity against accidental change only if the expected hash root is trusted; it does not authenticate authorship. A second non-cryptographic hash does not make the collision probability simply multiplicative in a general security model.

### F. Fuel and determinism

Fuel bounds counted VM operations only if every operation is metered. An uninterruptible external call, host filesystem stall, GPU call or OS scheduling delay prevents a strict wall-time guarantee. Use host-call budgets, cancellation, process isolation and atomic publication.

### G. Logical timestamps and reproducibility

Do not replace observed file modification timestamps with synthetic timestamps and pretend they are physical observations. Keep source timestamps when available as evidence, but exclude irrelevant timestamps from semantic hashes. Determinism comes from canonical semantic inputs and declared environment, not invented metadata.

### H. Linear types and memory safety

Linear/affine types help model resource use but do not alone prove absence of every race or leak in a native runtime. Task-scoped arenas, ownership constraints, safe host APIs, tests and a small trusted core are complementary techniques.

## Decision

All accepted items appear in v0.3 as scoped requirements or optional profiles. The corrected claims are binding. The unverified performance claims are explicitly deferred to benchmarks on target hardware.
