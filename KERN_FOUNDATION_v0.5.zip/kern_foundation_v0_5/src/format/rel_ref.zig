const std = @import("std");

/// Wire-level reference. It is not a native pointer and is safe to move between mappings.
/// Each field is encoded explicitly as little-endian u32 in .kbin.
pub const RelRef = extern struct {
    chunk_id: u32,
    offset: u32,
};

pub const ResolveError = error{
    InvalidChunk,
    OffsetOutOfBounds,
    LengthOutOfBounds,
};

/// Bounds-check a record slice in a previously validated chunk directory.
/// This does not allocate and never performs unchecked pointer casts.
pub fn resolveSlice(chunks: []const []const u8, ref: RelRef, record_len: u32) ResolveError![]const u8 {
    const chunk_index: usize = @intCast(ref.chunk_id);
    if (chunk_index >= chunks.len) return error.InvalidChunk;
    const chunk = chunks[chunk_index];
    const off: usize = @intCast(ref.offset);
    const len: usize = @intCast(record_len);
    if (off > chunk.len) return error.OffsetOutOfBounds;
    if (len > chunk.len - off) return error.LengthOutOfBounds;
    return chunk[off .. off + len];
}

test "relative reference checks chunk and bounds" {
    const chunk_a = "abcdef";
    const chunks = [_][]const u8{chunk_a};
    const ok = try resolveSlice(&chunks, .{ .chunk_id = 0, .offset = 2 }, 3);
    try std.testing.expectEqualStrings("cde", ok);
    try std.testing.expectError(error.InvalidChunk, resolveSlice(&chunks, .{ .chunk_id = 1, .offset = 0 }, 1));
    try std.testing.expectError(error.OffsetOutOfBounds, resolveSlice(&chunks, .{ .chunk_id = 0, .offset = 9 }, 0));
    try std.testing.expectError(error.LengthOutOfBounds, resolveSlice(&chunks, .{ .chunk_id = 0, .offset = 4 }, 3));
}
