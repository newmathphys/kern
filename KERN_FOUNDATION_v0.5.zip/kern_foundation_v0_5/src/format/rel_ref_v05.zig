const std = @import("std");

pub const RelRef = extern struct {
    chunk_id: u32,
    offset: u32,
};

pub const RefError = error{ ChunkNotFound, OffsetOutOfBounds, RangeOutOfBounds, Misaligned };

/// Validate using subtraction to avoid integer overflow in offset + length.
pub fn validateRange(chunk_len: usize, offset: usize, length: usize, alignment: usize) RefError!void {
    if (offset > chunk_len) return error.OffsetOutOfBounds;
    if (length > chunk_len - offset) return error.RangeOutOfBounds;
    if (alignment == 0 or (alignment & (alignment - 1)) != 0) return error.Misaligned;
    if ((offset % alignment) != 0) return error.Misaligned;
}

test "relative references require checked bounds" {
    try validateRange(1024, 64, 64, 8);
    try std.testing.expectError(error.OffsetOutOfBounds, validateRange(1024, 1025, 0, 1));
    try std.testing.expectError(error.RangeOutOfBounds, validateRange(1024, 1000, 25, 1));
    try std.testing.expectError(error.Misaligned, validateRange(1024, 3, 8, 8));
}
