const std = @import("std");

pub const BoundsError = error{ OutOfBounds, InvalidAlignment };

/// Overflow-safe check for [offset, offset+length) within total bytes.
pub fn checkRange(offset: u64, length: u64, total: u64) BoundsError!void {
    if (offset > total) return error.OutOfBounds;
    if (length > total - offset) return error.OutOfBounds;
}

pub fn checkAlignment(offset: u64, alignment: u32) BoundsError!void {
    if (alignment == 0 or (alignment & (alignment - 1)) != 0) return error.InvalidAlignment;
    if (offset % alignment != 0) return error.InvalidAlignment;
}

test "range checks avoid addition overflow" {
    try checkRange(10, 5, 15);
    try std.testing.expectError(error.OutOfBounds, checkRange(11, 5, 15));
    try std.testing.expectError(error.OutOfBounds, checkRange(std.math.maxInt(u64), 1, std.math.maxInt(u64)));
}

test "alignment must be a power of two and offset aligned" {
    try checkAlignment(64, 64);
    try std.testing.expectError(error.InvalidAlignment, checkAlignment(63, 64));
    try std.testing.expectError(error.InvalidAlignment, checkAlignment(8, 3));
}
