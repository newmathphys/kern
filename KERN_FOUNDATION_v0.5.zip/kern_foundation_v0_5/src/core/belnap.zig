const std = @import("std");

/// Belnap-Dunn FOUR using bit 0 = positive support p, bit 1 = negative support n.
/// This type represents evidence support only; it is not an execution/verifier status.
pub const BelnapValue = enum(u2) {
    N = 0b00, // neither
    T = 0b01, // positive support only
    F = 0b10, // negative support only
    B = 0b11, // both

    pub inline fn p(self: BelnapValue) bool {
        return (@intFromEnum(self) & 0b01) != 0;
    }

    pub inline fn n(self: BelnapValue) bool {
        return (@intFromEnum(self) & 0b10) != 0;
    }

    pub inline fn fromPN(pos: bool, neg: bool) BelnapValue {
        const p_bit: u2 = if (pos) 0b01 else 0;
        const n_bit: u2 = if (neg) 0b10 else 0;
        return @enumFromInt(p_bit | n_bit);
    }

    /// Truth negation: swaps positive and negative support.
    pub inline fn notB(self: BelnapValue) BelnapValue {
        return fromPN(self.n(), self.p());
    }

    /// Truth-order meet/conjunction.
    pub inline fn andT(a: BelnapValue, b: BelnapValue) BelnapValue {
        return fromPN(a.p() and b.p(), a.n() or b.n());
    }

    /// Truth-order join/disjunction.
    pub inline fn orT(a: BelnapValue, b: BelnapValue) BelnapValue {
        return fromPN(a.p() or b.p(), a.n() and b.n());
    }

    /// Knowledge-order join: aggregate positive and negative supports.
    pub inline fn joinK(a: BelnapValue, b: BelnapValue) BelnapValue {
        return @enumFromInt(@intFromEnum(a) | @intFromEnum(b));
    }

    /// Knowledge-order meet: intersect support bits.
    pub inline fn meetK(a: BelnapValue, b: BelnapValue) BelnapValue {
        return @enumFromInt(@intFromEnum(a) & @intFromEnum(b));
    }

    pub inline fn leqK(a: BelnapValue, b: BelnapValue) bool {
        return (!a.p() or b.p()) and (!a.n() or b.n());
    }
};

test "Belnap canonical encoding and support bits" {
    try std.testing.expectEqual(@as(u2, 0), @intFromEnum(BelnapValue.N));
    try std.testing.expectEqual(@as(u2, 1), @intFromEnum(BelnapValue.T));
    try std.testing.expectEqual(@as(u2, 2), @intFromEnum(BelnapValue.F));
    try std.testing.expectEqual(@as(u2, 3), @intFromEnum(BelnapValue.B));
    try std.testing.expect(!BelnapValue.N.p() and !BelnapValue.N.n());
    try std.testing.expect(BelnapValue.T.p() and !BelnapValue.T.n());
    try std.testing.expect(!BelnapValue.F.p() and BelnapValue.F.n());
    try std.testing.expect(BelnapValue.B.p() and BelnapValue.B.n());
}

test "Belnap core distinctions" {
    try std.testing.expectEqual(BelnapValue.B, BelnapValue.joinK(.T, .F));
    try std.testing.expectEqual(BelnapValue.F, BelnapValue.andT(.T, .F));
    try std.testing.expectEqual(BelnapValue.T, BelnapValue.orT(.T, .F));
    try std.testing.expectEqual(BelnapValue.F, BelnapValue.notB(.T));
    try std.testing.expectEqual(BelnapValue.N, BelnapValue.notB(.N));
    try std.testing.expectEqual(BelnapValue.B, BelnapValue.notB(.B));
    try std.testing.expectEqual(BelnapValue.N, BelnapValue.meetK(.T, .F));
}

test "Belnap operations are exhaustive over all pairs" {
    const values = [_]BelnapValue{ .N, .T, .F, .B };
    for (values) |a| {
        try std.testing.expectEqual(a, BelnapValue.joinK(a, a));
        try std.testing.expectEqual(a, BelnapValue.meetK(a, a));
        try std.testing.expectEqual(a, BelnapValue.notB(BelnapValue.notB(a)));
        for (values) |b| {
            try std.testing.expectEqual(BelnapValue.joinK(a, b), BelnapValue.joinK(b, a));
            try std.testing.expectEqual(BelnapValue.meetK(a, b), BelnapValue.meetK(b, a));
            try std.testing.expectEqual(BelnapValue.fromPN(a.p() or b.p(), a.n() or b.n()), BelnapValue.joinK(a, b));
            try std.testing.expectEqual(BelnapValue.fromPN(a.p() and b.p(), a.n() and b.n()), BelnapValue.meetK(a, b));
        }
    }
}
