const BelnapValue = @import("belnap_v05.zig").BelnapValue;

pub const CoverageState = enum {
    not_scanned,
    partial,
    scanned_no_evidence,
    scanned_with_evidence,
    complete_under_policy,
};

pub const VerificationVerdict = enum {
    not_run,
    proved,
    counterexample,
    sat_witness,
    unsat,
    unknown,
    timeout,
    invalid_certificate,
    tool_error,
    out_of_fuel,
};

pub const GateReason = enum {
    admitted,
    conflicting_evidence,
    missing_positive_support,
    negative_support_present,
    policy_missing,
    provenance_incomplete,
    checker_not_succeeded,
    coverage_incomplete,
    scope_unresolved,
    input_hash_mismatch,
};

pub const GateInput = struct {
    value: BelnapValue,
    coverage: CoverageState,
    has_policy: bool,
    provenance_complete: bool,
    checker_succeeded_for_required_property: bool,
    scope_resolved: bool,
    input_hash_matches: bool,
};

pub const GateDecision = struct {
    admitted: bool,
    enqueue_resolution: bool,
    reason: GateReason,
};

/// Computes admission. A source file/LLM cannot directly set `admitted`.
pub fn evaluate(input: GateInput) GateDecision {
    if (input.value == .B) return .{
        .admitted = false,
        .enqueue_resolution = true,
        .reason = .conflicting_evidence,
    };
    if (input.value == .F) return .{
        .admitted = false,
        .enqueue_resolution = false,
        .reason = .negative_support_present,
    };
    if (input.value != .T) return .{
        .admitted = false,
        .enqueue_resolution = false,
        .reason = .missing_positive_support,
    };
    if (!input.has_policy) return .{ .admitted = false, .enqueue_resolution = false, .reason = .policy_missing };
    if (!input.provenance_complete) return .{ .admitted = false, .enqueue_resolution = false, .reason = .provenance_incomplete };
    if (!input.checker_succeeded_for_required_property) return .{ .admitted = false, .enqueue_resolution = false, .reason = .checker_not_succeeded };
    if (input.coverage != .complete_under_policy) return .{ .admitted = false, .enqueue_resolution = false, .reason = .coverage_incomplete };
    if (!input.scope_resolved) return .{ .admitted = false, .enqueue_resolution = false, .reason = .scope_unresolved };
    if (!input.input_hash_matches) return .{ .admitted = false, .enqueue_resolution = false, .reason = .input_hash_mismatch };
    return .{ .admitted = true, .enqueue_resolution = false, .reason = .admitted };
}

test "coverage and provenance prevent false admission" {
    const base = GateInput{
        .value = .T,
        .coverage = .complete_under_policy,
        .has_policy = true,
        .provenance_complete = true,
        .checker_succeeded_for_required_property = true,
        .scope_resolved = true,
        .input_hash_matches = true,
    };
    try @import("std").testing.expect(evaluate(base).admitted);
    var changed = base;
    changed.coverage = .not_scanned;
    try @import("std").testing.expect(!evaluate(changed).admitted);
    changed = base;
    changed.value = .B;
    try @import("std").testing.expect(evaluate(changed).enqueue_resolution);
    changed = base;
    changed.input_hash_matches = false;
    try @import("std").testing.expect(!evaluate(changed).admitted);
}
