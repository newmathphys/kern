const std = @import("std");

/// KERN Belnap-Dunn FOUR, packed as p in bit 0 and n in bit 1.
/// N=00 (neither), T=01 (positive only), F=10 (negative only), B=11 (both).
pub const BelnapValue = enum(u2) {
    N = 0b00,
    T = 0b01,
    F = 0b10,
    B = 0b11,

    pub inline fn p(self: BelnapValue) bool {
        return (@intFromEnum(self) & 0b01) != 0;
    }

    pub inline fn n(self: BelnapValue) bool {
        return (@intFromEnum(self) & 0b10) != 0;
    }

    pub inline fn fromPN(pos: bool, neg: bool) BelnapValue {
        const value: u2 = (if (neg) @as(u2, 0b10) else 0) |
            (if (pos) @as(u2, 0b01) else 0);
        return @enumFromInt(value);
    }

    /// De Morgan negation: swap positive and negative support.
    pub inline fn notB(self: BelnapValue) BelnapValue {
        return fromPN(self.n(), self.p());
    }

    /// Truth-order meet/conjunction: (p_a AND p_b, n_a OR n_b).
    pub inline fn andT(a: BelnapValue, b: BelnapValue) BelnapValue {
        return fromPN(a.p() and b.p(), a.n() or b.n());
    }

    /// Truth-order join/disjunction: (p_a OR p_b, n_a AND n_b).
    pub inline fn orT(a: BelnapValue, b: BelnapValue) BelnapValue {
        return fromPN(a.p() or b.p(), a.n() and b.n());
    }

    /// Knowledge-order join. Aggregates admitted support; not logical AND.
    pub inline fn joinK(a: BelnapValue, b: BelnapValue) BelnapValue {
        return @enumFromInt(@intFromEnum(a) | @intFromEnum(b));
    }

    /// Knowledge-order meet. It intersects the support bits.
    pub inline fn meetK(a: BelnapValue, b: BelnapValue) BelnapValue {
        return @enumFromInt(@intFromEnum(a) & @intFromEnum(b));
    }
};

test "canonical Belnap encodings and operators" {
    try std.testing.expectEqual(@as(u2, 0), @intFromEnum(BelnapValue.N));
    try std.testing.expectEqual(@as(u2, 1), @intFromEnum(BelnapValue.T));
    try std.testing.expectEqual(@as(u2, 2), @intFromEnum(BelnapValue.F));
    try std.testing.expectEqual(@as(u2, 3), @intFromEnum(BelnapValue.B));
    try std.testing.expectEqual(BelnapValue.B, BelnapValue.joinK(.T, .F));
    try std.testing.expectEqual(BelnapValue.F, BelnapValue.andT(.T, .F));
    try std.testing.expectEqual(BelnapValue.T, BelnapValue.orT(.N, .T));
    try std.testing.expectEqual(BelnapValue.F, BelnapValue.notB(.T));
}

test "knowledge join is commutative associative idempotent" {
    const vals = [_]BelnapValue{ .N, .T, .F, .B };
    for (vals) |a| {
        try std.testing.expectEqual(a, BelnapValue.joinK(a, a));
        for (vals) |b| {
            try std.testing.expectEqual(BelnapValue.joinK(a, b), BelnapValue.joinK(b, a));
            for (vals) |c| {
                try std.testing.expectEqual(
                    BelnapValue.joinK(BelnapValue.joinK(a, b), c),
                    BelnapValue.joinK(a, BelnapValue.joinK(b, c)),
                );
            }
        }
    }
}

test "truth operations and knowledge meet identities" {
    const vals = [_]BelnapValue{ .N, .T, .F, .B };
    for (vals) |a| {
        try std.testing.expectEqual(a, BelnapValue.meetK(a, .B));
        try std.testing.expectEqual(a, BelnapValue.andT(a, .T));
        try std.testing.expectEqual(a, BelnapValue.orT(a, .F));
        try std.testing.expectEqual(a, BelnapValue.notB(BelnapValue.notB(a)));
    }
}
