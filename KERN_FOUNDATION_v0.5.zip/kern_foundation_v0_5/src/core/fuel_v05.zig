const std = @import("std");

pub const FuelError = error{OutOfFuel, ArenaLimitExceeded, OutputLimitExceeded};

/// One shared budget per task. Do not copy remaining fuel into recursive branches.
pub const TaskBudget = struct {
    fuel_remaining: u64,
    fuel_consumed: u64 = 0,
    arena_limit_bytes: u64,
    arena_used_bytes: u64 = 0,
    output_limit_bytes: u64,
    output_used_bytes: u64 = 0,

    pub fn consume(self: *TaskBudget, units: u64) FuelError!void {
        if (units > self.fuel_remaining) return error.OutOfFuel;
        self.fuel_remaining -= units;
        self.fuel_consumed += units;
    }

    pub fn accountArena(self: *TaskBudget, bytes: u64) FuelError!void {
        if (bytes > self.arena_limit_bytes -| self.arena_used_bytes) return error.ArenaLimitExceeded;
        self.arena_used_bytes += bytes;
    }

    pub fn accountOutput(self: *TaskBudget, bytes: u64) FuelError!void {
        if (bytes > self.output_limit_bytes -| self.output_used_bytes) return error.OutputLimitExceeded;
        self.output_used_bytes += bytes;
    }
};

test "fuel is global and depletion is not Belnap conflict" {
    var budget = TaskBudget{
        .fuel_remaining = 5,
        .arena_limit_bytes = 100,
        .output_limit_bytes = 100,
    };
    try budget.consume(3);
    try std.testing.expectEqual(@as(u64, 2), budget.fuel_remaining);
    try std.testing.expectError(error.OutOfFuel, budget.consume(3));
}
