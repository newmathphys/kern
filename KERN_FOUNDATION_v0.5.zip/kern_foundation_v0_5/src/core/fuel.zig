const std = @import("std");

pub const BudgetError = error{
    OutOfFuel,
    ArenaLimitExceeded,
    OutputLimitExceeded,
    HostCallLimitExceeded,
    RecursionLimitExceeded,
    ArithmeticOverflow,
    InvalidRelease,
};

/// Resource outcomes are operational states, not logical truth values.
pub const Budget = struct {
    fuel_remaining: u64,
    arena_limit_bytes: u64,
    arena_used_bytes: u64 = 0,
    output_limit_bytes: u64,
    output_used_bytes: u64 = 0,
    host_calls_remaining: u64,
    recursion_remaining: u32,

    pub fn chargeFuel(self: *Budget, amount: u64) BudgetError!void {
        if (amount > self.fuel_remaining) return error.OutOfFuel;
        self.fuel_remaining -= amount;
    }

    pub fn reserveArena(self: *Budget, amount: u64) BudgetError!void {
        if (self.arena_used_bytes > self.arena_limit_bytes) return error.ArenaLimitExceeded;
        if (amount > self.arena_limit_bytes - self.arena_used_bytes) return error.ArenaLimitExceeded;
        self.arena_used_bytes += amount;
    }

    pub fn releaseArena(self: *Budget, amount: u64) BudgetError!void {
        if (amount > self.arena_used_bytes) return error.InvalidRelease;
        self.arena_used_bytes -= amount;
    }

    pub fn chargeOutput(self: *Budget, amount: u64) BudgetError!void {
        if (self.output_used_bytes > self.output_limit_bytes) return error.OutputLimitExceeded;
        if (amount > self.output_limit_bytes - self.output_used_bytes) return error.OutputLimitExceeded;
        self.output_used_bytes += amount;
    }

    pub fn chargeHostCall(self: *Budget) BudgetError!void {
        if (self.host_calls_remaining == 0) return error.HostCallLimitExceeded;
        self.host_calls_remaining -= 1;
    }

    pub fn enterRecursion(self: *Budget) BudgetError!void {
        if (self.recursion_remaining == 0) return error.RecursionLimitExceeded;
        self.recursion_remaining -= 1;
    }

    pub fn leaveRecursion(self: *Budget) void {
        self.recursion_remaining += 1;
    }
};

test "fuel exhaustion is an operational error, not Belnap conflict" {
    var budget = Budget{
        .fuel_remaining = 2,
        .arena_limit_bytes = 1024,
        .output_limit_bytes = 128,
        .host_calls_remaining = 4,
        .recursion_remaining = 8,
    };
    try budget.chargeFuel(2);
    try std.testing.expectError(error.OutOfFuel, budget.chargeFuel(1));
}

test "arena and output quotas reject overrun without integer overflow" {
    var budget = Budget{
        .fuel_remaining = 100,
        .arena_limit_bytes = 10,
        .output_limit_bytes = 4,
        .host_calls_remaining = 1,
        .recursion_remaining = 1,
    };
    try budget.reserveArena(8);
    try std.testing.expectError(error.ArenaLimitExceeded, budget.reserveArena(3));
    try budget.chargeOutput(4);
    try std.testing.expectError(error.OutputLimitExceeded, budget.chargeOutput(1));
}
