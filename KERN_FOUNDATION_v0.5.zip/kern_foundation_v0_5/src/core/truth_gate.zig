const std = @import("std");
const belnap = @import("belnap.zig");

pub const CoverageState = enum(u3) {
    not_scanned,
    partial,
    scanned_no_evidence,
    scanned_with_evidence,
    complete_under_policy,
};

pub const VerificationVerdict = enum {
    not_run,
    passed,
    counterexample,
    invalid_certificate,
    unknown,
    timeout,
    tool_error,
};

pub const GateReason = enum {
    admitted,
    conflicting_support,
    no_positive_support,
    negative_support_present,
    coverage_incomplete,
    provenance_incomplete,
    required_check_failed,
    scope_unresolved,
    policy_missing,
};

pub const GateInput = struct {
    support: belnap.BelnapValue,
    coverage: CoverageState,
    verdict: VerificationVerdict,
    policy_configured: bool,
    provenance_complete: bool,
    required_checks_passed: bool,
    scope_resolved: bool,
};

pub const GateResult = struct {
    admitted: bool,
    enqueue_resolution: bool,
    reason: GateReason,
};

/// Admission is derived from a claim-type policy. This is intentionally stricter
/// than checking the Belnap bits alone; source KERN syntax cannot assign e=1.
pub fn evaluate(input: GateInput) GateResult {
    if (input.support == .B) return .{
        .admitted = false,
        .enqueue_resolution = true,
        .reason = .conflicting_support,
    };
    if (!input.policy_configured) return deny(.policy_missing);
    if (input.coverage != .complete_under_policy) return deny(.coverage_incomplete);
    if (!input.provenance_complete) return deny(.provenance_incomplete);
    if (!input.scope_resolved) return deny(.scope_unresolved);
    if (input.support == .N) return deny(.no_positive_support);
    if (input.support == .F) return deny(.negative_support_present);
    if (input.verdict != .passed or !input.required_checks_passed) return deny(.required_check_failed);
    return .{ .admitted = true, .enqueue_resolution = false, .reason = .admitted };
}

fn deny(reason: GateReason) GateResult {
    return .{ .admitted = false, .enqueue_resolution = false, .reason = reason };
}

test "gate rejects unscanned state even when no evidence is present" {
    const result = evaluate(.{
        .support = .N,
        .coverage = .not_scanned,
        .verdict = .not_run,
        .policy_configured = true,
        .provenance_complete = false,
        .required_checks_passed = false,
        .scope_resolved = true,
    });
    try std.testing.expect(!result.admitted);
    try std.testing.expectEqual(GateReason.no_positive_support, result.reason);
}

test "gate opens contradiction resolution queue for B" {
    const result = evaluate(.{
        .support = .B,
        .coverage = .complete_under_policy,
        .verdict = .passed,
        .policy_configured = true,
        .provenance_complete = true,
        .required_checks_passed = true,
        .scope_resolved = true,
    });
    try std.testing.expect(!result.admitted);
    try std.testing.expect(result.enqueue_resolution);
    try std.testing.expectEqual(GateReason.conflicting_support, result.reason);
}

test "gate admits only policy-compliant positive-only evidence" {
    const result = evaluate(.{
        .support = .T,
        .coverage = .complete_under_policy,
        .verdict = .passed,
        .policy_configured = true,
        .provenance_complete = true,
        .required_checks_passed = true,
        .scope_resolved = true,
    });
    try std.testing.expect(result.admitted);
    try std.testing.expect(!result.enqueue_resolution);
    try std.testing.expectEqual(GateReason.admitted, result.reason);
}
