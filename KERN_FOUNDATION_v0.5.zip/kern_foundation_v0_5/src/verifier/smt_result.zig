const std = @import("std");

pub const QueryKind = enum {
    precondition_feasibility,
    counterexample_search,
};

pub const SolverStatus = enum {
    sat,
    unsat,
    unknown,
    timeout,
    unavailable,
    tool_error,
};

pub const ModelValidation = enum {
    not_applicable,
    not_checked,
    valid,
    invalid,
};

pub const Interpretation = enum {
    precondition_feasible,
    precondition_infeasible_or_vacuous,
    counterexample_found,
    no_counterexample_in_encoded_model,
    inconclusive,
    invalid_or_unchecked_model,
    not_run,
    tool_error,
};

/// Maps a *typed query result* to a narrow interpretation. This is not an SMT client:
/// the caller must execute the solver, parse its response, and validate any returned model.
pub fn interpret(kind: QueryKind, result: SolverStatus, model: ModelValidation) Interpretation {
    return switch (result) {
        .unavailable => .not_run,
        .tool_error => .tool_error,
        .unknown, .timeout => .inconclusive,
        .sat => switch (kind) {
            .precondition_feasibility => if (model == .valid) .precondition_feasible else .invalid_or_unchecked_model,
            .counterexample_search => if (model == .valid) .counterexample_found else .invalid_or_unchecked_model,
        },
        .unsat => switch (kind) {
            .precondition_feasibility => .precondition_infeasible_or_vacuous,
            .counterexample_search => .no_counterexample_in_encoded_model,
        },
    };
}

test "SAT has different meanings for different queries" {
    try std.testing.expectEqual(
        Interpretation.precondition_feasible,
        interpret(.precondition_feasibility, .sat, .valid),
    );
    try std.testing.expectEqual(
        Interpretation.counterexample_found,
        interpret(.counterexample_search, .sat, .valid),
    );
}

test "unchecked model never becomes a verified witness" {
    try std.testing.expectEqual(
        Interpretation.invalid_or_unchecked_model,
        interpret(.precondition_feasibility, .sat, .not_checked),
    );
}

test "timeout is inconclusive, not false and not conflict" {
    try std.testing.expectEqual(
        Interpretation.inconclusive,
        interpret(.counterexample_search, .timeout, .not_applicable),
    );
}
