/// SMT answers are query-relative. They are not mapped directly to Belnap truth.
pub const QueryKind = enum {
    precondition_feasibility,
    postcondition_counterexample,
    invariant_check,
};

pub const SolverAnswer = enum { sat, unsat, unknown, timeout, tool_error };
pub const SemanticResult = enum {
    precondition_feasible,
    precondition_infeasible,
    counterexample_found,
    no_counterexample_in_encoded_model,
    invariant_model_found,
    invariant_violation_not_found_in_encoded_model,
    inconclusive,
    execution_error,
};

pub const SmtResult = struct {
    query_kind: QueryKind,
    answer: SolverAnswer,
    model_parsed: bool = false,
    model_validated_against_exact_query: bool = false,
    encoding_soundness_policy_satisfied: bool = false,

    pub fn interpret(self: SmtResult) SemanticResult {
        switch (self.answer) {
            .unknown, .timeout => return .inconclusive,
            .tool_error => return .execution_error,
            .sat => {
                if (!self.model_parsed or !self.model_validated_against_exact_query) return .inconclusive;
                return switch (self.query_kind) {
                    .precondition_feasibility => .precondition_feasible,
                    .postcondition_counterexample => .counterexample_found,
                    .invariant_check => .invariant_model_found,
                };
            },
            .unsat => {
                if (!self.encoding_soundness_policy_satisfied) return .inconclusive;
                return switch (self.query_kind) {
                    .precondition_feasibility => .precondition_infeasible,
                    .postcondition_counterexample => .no_counterexample_in_encoded_model,
                    .invariant_check => .invariant_violation_not_found_in_encoded_model,
                };
            },
        }
    }
};

test "SAT is interpreted according to query kind, never as universal correctness" {
    const testing = @import("std").testing;
    const pre_sat = SmtResult{ .query_kind = .precondition_feasibility, .answer = .sat, .model_parsed = true, .model_validated_against_exact_query = true };
    try testing.expectEqual(SemanticResult.precondition_feasible, pre_sat.interpret());
    const cex_sat = SmtResult{ .query_kind = .postcondition_counterexample, .answer = .sat, .model_parsed = true, .model_validated_against_exact_query = true };
    try testing.expectEqual(SemanticResult.counterexample_found, cex_sat.interpret());
    const unknown = SmtResult{ .query_kind = .postcondition_counterexample, .answer = .unsat };
    try testing.expectEqual(SemanticResult.inconclusive, unknown.interpret());
}
