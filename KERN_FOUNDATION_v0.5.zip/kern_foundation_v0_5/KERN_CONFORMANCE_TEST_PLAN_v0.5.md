# KERN conformance test plan v0.5

A test passes only when an actual implementation produces the expected output. Text in this plan is not evidence that Zig/Lean compilation has already passed.

## 1. Belnap algebra

- Exhaust all 4 values for `notB` and all 16 input pairs for `andT`, `orT`, `joinK`, `meetK`.
- Check both order definitions and that each operator returns the correct greatest lower bound/least upper bound for its order.
- Check `joinK(T,F)=B`, `andT(T,F)=F`, `orT(N,T)=T`, and De Morgan laws.
- Cross-check outputs among Zig reference implementation, Lean formal model, and the standard-library Python oracle.

## 2. Coverage / gate

- `N + not_scanned` cannot be admitted.
- `N + complete_under_policy` is still unknown, not false.
- `T` without matching trusted evidence or matching input hash cannot be admitted.
- `T` from tests may be admitted only for test-scope empirical claims under policy.
- `F` cannot be admitted as proven true.
- `B` creates a resolution task only with two scope-compatible evidence contributions; `B` never means timeout.
- `out_of_fuel`, `timeout`, `tool_error`, `invalid_certificate` remain verdicts, not Belnap values.

## 3. SMT semantics

- `SAT(Pre)` with a validated model passes feasibility only.
- `UNSAT(Pre)` triggers `vacuous_or_unreachable_specification` when feasibility is required; it does not set a business claim to false.
- `SAT(Pre AND NOT Post)` produces a counterexample only when model and encoding metadata validate.
- `UNSAT(Pre AND NOT Post)` supports only the encoded property under explicit assumptions.
- Fake witness strings and non-empty byte arrays are rejected.

## 4. PC3

- Certificate for AST A cannot be reused for AST B.
- Certificate for contract C cannot be reused under contract D.
- Dependency interface, checker policy, proof calculus or verifier version changes invalidate cache/admission.
- Invalid/missing certificate keeps the change staged and unpublished.
- Certificate size and checker work limits return resource outcomes, never false or conflict by themselves.

## 5. Provenance and differential updates

- Duplicate add/retract event IDs are idempotent or diagnosed according to the event schema.
- Retraction must name an active evidence contribution.
- Recompute `p` and `n` from active valid contributions after retraction.
- Diamond dependencies commit only after all updates for an epoch are resolved; no externally visible intermediate status.
- Positive recursive rules converge under declared finite fixpoint semantics.
- Negative edge inside a recursive SCC is rejected unless the language defines a supported semantics.
- Differential result must equal full recomputation for generated small graphs, including cycles in source/module graph and retractions.
- Measure update work; do not assert `O(delta)` without evidence.

## 6. `.kbin`

- Reject wrong magic/version, truncated header, overflowing offset+length, out-of-bounds tables, invalid alignment and malformed UTF-8 where strings require UTF-8.
- Verify section digests against exact bytes.
- Handle unknown optional sections and reject unknown required sections.
- Check endianness and never cast unchecked file bytes directly to native structs.
- Verify chunk offsets are within their chunk and record does not straddle a prohibited boundary.
- Crash consistency: old snapshot remains valid if writing a new snapshot is interrupted.
- Read-only concurrent readers never see a partially published snapshot.
- Test normal mmap fallback when HugeTLB is unavailable.

## 7. Cache

- Irrelevant whitespace normalization can hit only when canonicalization contract permits it.
- Relevant implementation body change invalidates body-sensitive analysis.
- Tool/model/prompt/schema/policy/retrieval/checker change invalidates results that depend on it.
- SCC canonicalization is stable under input file enumeration order.
- Cryptographic digest input is length-delimited/canonical; no ambiguous concatenation.
- Cache hit is not counted as a new test/proof execution.

## 8. KERN-X

- Exhaust global fuel and ensure `OUT_OF_FUEL`, not `B`.
- Exhaust arena bytes and output quota.
- Simulated blocking host call is cancelled by host timeout.
- Verify capabilities reject forbidden filesystem/network actions.
- A malformed or cyclic input cannot bypass global fuel through copied counters.

## 9. Canonical manifest

- Synthetic data cannot be admitted as real evidence.
- Percentages have explicit numerator/denominator and are computed from run data.
- Every status T has an exact source/evidence/checker reference.
- Machine blocks validate against schema; prose is non-authoritative.
- Rebuild from same committed inputs produces canonical identical machine records.
