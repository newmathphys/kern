# KERN Foundation v0.5

Current package entry point. See `README_v0.5.md` for scope and commands and `KERN_FOUNDATION_SPEC_v0.5.md` for the normative design.

This is still a specification plus reference modules, not a finished native compiler. The package does not claim that Zig or Lean was compiled in the available environment.
