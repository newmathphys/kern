package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ArchitectureBlueprint
import com.example.utils.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Kirin AI Agent", appName)
    }

    @Test
    fun `collectDeviceReport produces valid report`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val report = SystemScanner.collectDeviceReport(context)
        assertNotNull(report)
        assertTrue(report.cores.isNotEmpty())
        assertTrue(report.ramTotalMb > 0)
        assertNotNull(report.partitionLayout)
        assertNotNull(report.gpuNpuAccelerator)
    }

    @Test
    fun `architecture blueprint contains 4 distinct tiers`() {
        val layers = ArchitectureBlueprint.layers
        assertEquals(4, layers.size)
        assertEquals(1, layers[0].tier)
        assertEquals(4, layers[3].tier)
    }

    @Test
    fun `kirin optimization engages big core affinity`() {
        val success = NativeHardwareController.optimizeForKirin()
        assertTrue(success)
        assertTrue(NativeHardwareController.isPinnedToBigCores)
        assertTrue(NativeHardwareController.isMemoryLocked)
        NativeHardwareController.resetOptimization()
    }

    @Test
    fun `adaptive thermal throttling reacts to temperature spike`() {
        val state1 = NativeHardwareController.evaluateThermalGovernance(40)
        assertEquals(ThrottleState.OPTIMAL, state1)

        val state2 = NativeHardwareController.evaluateThermalGovernance(60)
        assertEquals(ThrottleState.THERMAL_COOLDOWN, state2)
    }

    @Test
    fun `privacy shield detects sensitive banking packages`() {
        assertTrue(ContextSnapshotManager.isPackageSensitive("com.sberbank.online"))
        assertTrue(ContextSnapshotManager.isPackageSensitive("ru.tinkoff.bank"))
        assertTrue(ContextSnapshotManager.isPackageSensitive("com.bitwarden.password"))
        assertFalse(ContextSnapshotManager.isPackageSensitive("org.telegram.messenger"))
        assertFalse(ContextSnapshotManager.isPackageSensitive("com.viber.voip"))
    }

    @Test
    fun `process zoning classifies apps accurately`() {
        assertEquals(ProcessZone.HOT, ProcessZoningManager.classifyPackage("org.telegram.messenger"))
        assertEquals(ProcessZone.HOT, ProcessZoningManager.classifyPackage("com.viber.voip"))
        assertEquals(ProcessZone.WARM, ProcessZoningManager.classifyPackage("com.huawei.soundrecorder"))
        assertEquals(ProcessZone.COLD, ProcessZoningManager.classifyPackage("com.android.chrome"))
    }

    @Test
    fun `choreographer deferred render queue toggles bus contention`() {
        ChoreographerSyncManager.toggleDeferredVsync(true)
        assertTrue(ChoreographerSyncManager.isDeferredVsyncActive.value)
        assertEquals(2, ChoreographerSyncManager.busContentionPercent.value)

        ChoreographerSyncManager.toggleDeferredVsync(false)
        assertFalse(ChoreographerSyncManager.isDeferredVsyncActive.value)
        assertTrue(ChoreographerSyncManager.busContentionPercent.value >= 70)

        // Restore to safe state
        ChoreographerSyncManager.toggleDeferredVsync(true)
        assertTrue(ChoreographerSyncManager.isDeferredVsyncActive.value)
    }

    @Test
    fun `zstd delta engine compresses UI payloads with high ratio`() {
        val testApp = "org.telegram.messenger"
        val payload = "Тестовый снимок экрана Telegram: зафиксировано 5 текстовых блоков и 2 кнопки."
        val compressed = ZstdDeltaEngine.compressPayload(testApp, payload)

        assertNotNull(compressed)
        assertTrue(compressed.isNotEmpty())
        assertTrue(ZstdDeltaEngine.totalRawBytes.value > 0)
        assertTrue(ZstdDeltaEngine.totalCompressedBytes.value > 0)
        assertTrue(ZstdDeltaEngine.overallSavingsPercent.value > 50f)
        assertEquals(100, ZstdDeltaEngine.flashIoWritesAvoided.value)
    }

    @Test
    fun `desktop symbiosis triggers ADB sync and increments packet count`() {
        val initialCount = DesktopSymbiosisManager.syncPacketCount.value
        val result = DesktopSymbiosisManager.triggerDesktopSync()

        assertNotNull(result)
        assertTrue(result.contains("Port 5037"))
        assertEquals(initialCount + 18, DesktopSymbiosisManager.syncPacketCount.value)
        assertTrue(DesktopSymbiosisManager.modelMatrixVersion.value.contains("v2.5"))
    }

    @Test
    fun `voice command parser toggles torch and dispatches syscall`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val result = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Включи фонарик")
        assertNotNull(result)
        assertTrue(result.contains("фонарик", ignoreCase = true))
        assertTrue(VoiceHardwareController.terminalLogs.value.isNotEmpty())
    }

    @Test
    fun `acoustic locator computes directional vector`() {
        VoiceHardwareController.triggerAcousticPulse(-35f)
        assertEquals(-35f, VoiceHardwareController.soundAngleDegrees.value)
        assertTrue(VoiceHardwareController.soundSourceLabel.value.contains("LEFT"))

        VoiceHardwareController.triggerAcousticPulse(35f)
        assertEquals(35f, VoiceHardwareController.soundAngleDegrees.value)
        assertTrue(VoiceHardwareController.soundSourceLabel.value.contains("RIGHT"))
    }

    @Test
    fun `optical scanner toggles camera facing and decodes QR payload`() {
        val initialFacing = OpticalScannerController.isFrontCamera.value
        OpticalScannerController.toggleCameraFacing()
        assertEquals(!initialFacing, OpticalScannerController.isFrontCamera.value)

        val qrData = "WIFI:S:Secret_HQ;P:KirinMaster961;;"
        OpticalScannerController.scanQrCode(qrData)
        assertEquals(qrData, OpticalScannerController.scannedQrResult.value)
        assertTrue(OpticalScannerController.asciiPreviewFrame.value.isNotEmpty())
    }

    @Test
    fun `voice command dispatcher controls all phone features`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Calls / Dialer
        val dialResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Позвони 112")
        assertNotNull(dialResult)

        // 2. SMS
        val smsResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Открой СМС")
        assertNotNull(smsResult)

        // 3. Audio & Volume
        val audioUpResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Громче")
        assertNotNull(audioUpResult)

        // 4. Battery Telemetry
        val battResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Сколько заряд батареи")
        assertTrue(battResult.contains("Заряд") || battResult.contains("процент"))

        // 5. Hardware Boost
        val boostResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Турбо разгон ядра A73")
        assertTrue(boostResult.contains("2.0") || boostResult.contains("разогнан"))

        // 6. Memory Compaction
        val zstdResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Очисти память")
        assertTrue(zstdResult.contains("RAM") || zstdResult.contains("сжата") || zstdResult.contains("Zstandard"))

        // 7. Matrix Mode
        val matrixResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Режим матрицы")
        assertTrue(matrixResult.contains("матрицы"))

        // 8. Help Catalog
        val helpResult = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Все команды")
        assertTrue(helpResult.contains("фонарик") || helpResult.contains("команды"))
    }

    @Test
    fun `photoplethysmography measures pulse bpm and stress index`() {
        val result = OpticalScannerController.measurePulseAndStress()
        assertNotNull(result)
        assertTrue(result.contains("BPM"))
        assertTrue(OpticalScannerController.pulseBpm.value in 50..120)
        assertNotNull(OpticalScannerController.stressIndex.value)
        assertNotNull(OpticalScannerController.opticalDensityVariation.value)

        val flicker = OpticalScannerController.detectAmbientFlicker()
        assertTrue(flicker == 50 || flicker == 60)
    }

    @Test
    fun `language manager toggles between Russian and English`() {
        com.example.utils.LocalizationManager.setLanguage(com.example.utils.AppLanguage.RU)
        assertEquals(com.example.utils.AppLanguage.RU, com.example.utils.LocalizationManager.currentLanguage.value)
        assertEquals("Да", com.example.utils.LocalizationManager.getString("Да", "Yes"))

        com.example.utils.LocalizationManager.toggleLanguage()
        assertEquals(com.example.utils.AppLanguage.EN, com.example.utils.LocalizationManager.currentLanguage.value)
        assertEquals("Yes", com.example.utils.LocalizationManager.getString("Да", "Yes"))

        // Restore to RU
        com.example.utils.LocalizationManager.setLanguage(com.example.utils.AppLanguage.RU)
    }

    @Test
    fun `assistant eyes mode toggles and tracks continuous uptime`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        VoiceHardwareController.toggleAssistantEyesMode(context, true)
        assertTrue(VoiceHardwareController.isAssistantEyesActive.value)

        val initialUptime = VoiceHardwareController.assistantUptimeSeconds.value
        VoiceHardwareController.tickAssistantUptime()
        assertEquals(initialUptime + 1, VoiceHardwareController.assistantUptimeSeconds.value)

        // Test voice toggle for assistant
        val voiceRes = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Включи ассистента")
        assertNotNull(voiceRes)
        assertTrue(voiceRes.contains("ассистент", ignoreCase = true))

        // Test fullscreen cyber eyes toggle
        VoiceHardwareController.setFullScreenEyes(true)
        assertTrue(VoiceHardwareController.isFullScreenEyesActive.value)
        assertTrue(VoiceHardwareController.isAssistantEyesActive.value)

        val fsVoiceRes = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Глаза на весь экран")
        assertNotNull(fsVoiceRes)
        assertTrue(fsVoiceRes.contains("экран", ignoreCase = true))

        VoiceHardwareController.setFullScreenEyes(false)
        assertFalse(VoiceHardwareController.isFullScreenEyesActive.value)
    }

    @Test
    fun `rag engine accurately retrieves relevant documents by keywords and title`() {
        val baselineDocs = RagEngine.getBaselineSeedDocuments()
        assertTrue(baselineDocs.size >= 4)

        // Test search by Kirin 710A SoC specs
        val results = RagEngine.search("Kirin 710A Cortex-A73", baselineDocs, topK = 2)
        assertTrue(results.isNotEmpty())
        val topMatch = results.first()
        assertTrue(topMatch.doc.title.contains("Kirin 710A"))
        assertTrue(topMatch.score > 0.3f)
        assertTrue(topMatch.matchedSnippet.isNotBlank())

        // Test search by Mali-G51 V-Sync Telegram
        val gpuResults = RagEngine.search("Telegram 60 FPS Mali-G51 V-Sync", baselineDocs, topK = 2)
        assertTrue(gpuResults.isNotEmpty())
        assertTrue(gpuResults.first().doc.title.contains("Mali-G51"))

        // Test RAG context prompt generation
        val promptContext = RagEngine.buildRagPromptContext("Telegram Mali-G51", gpuResults)
        assertNotNull(promptContext)
        assertTrue(promptContext.contains("LOCAL RAG KNOWLEDGE BASE CONTEXT"))
        assertTrue(promptContext.contains("DOC #1"))
    }

    @Test
    fun `knowledge base voice command triggers capture callback`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var callbackFired = false
        VoiceHardwareController.onKnowledgeCaptureRequested = {
            callbackFired = true
        }

        val res = VoiceHardwareController.parseAndExecuteVoiceCommand(context, "Задокументируй всё в базу знаний")
        assertNotNull(res)
        assertTrue(res.contains("базу знаний", ignoreCase = true))
        assertTrue(callbackFired)
    }

    @Test
    fun `knowledge base exports valid markdown and json bundles`() {
        val seedDocs = RagEngine.getBaselineSeedDocuments()
        val markdown = RagEngine.exportAllAsMarkdown(seedDocs)
        assertNotNull(markdown)
        assertTrue(markdown.contains("# Kirin AI Agent - Full Knowledge Base Export"))
        assertTrue(markdown.contains("## 1."))

        val json = RagEngine.exportAllAsJson(seedDocs)
        assertNotNull(json)
        assertTrue(json.contains("\"documents\":"))
        assertTrue(json.contains("totalDocuments"))
    }

    @Test
    fun `universal android debloater freezes packages and generates bulldozer script`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        UniversalDebloaterManager.refreshInstalledStatus(context)
        assertTrue(UniversalDebloaterManager.packages.value.isNotEmpty())

        val success = UniversalDebloaterManager.togglePackageFreeze(context, "com.huawei.browser", true)
        assertTrue(success)

        val frozenPkg = UniversalDebloaterManager.packages.value.find { it.packageName == "com.huawei.browser" }
        assertNotNull(frozenPkg)
        assertTrue(frozenPkg!!.isFrozen)

        val debloatedCount = UniversalDebloaterManager.freezeAllTelemetry(context)
        assertTrue(debloatedCount > 0)

        val script = UniversalDebloaterManager.generateBullDozerShellScript()
        assertNotNull(script)
        assertTrue(script.contains("BullDozer"))
        assertTrue(script.contains("adb shell pm disable-user"))

        val restoredCount = UniversalDebloaterManager.restoreAllPackages(context)
        assertTrue(restoredCount >= debloatedCount)
    }

    @Test
    fun `cellular security manager audits towers and warns on 2g downgrade`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val towers = CellularSecurityManager.auditCellularEnvironment(context)
        assertTrue(towers.isNotEmpty())
        assertNotNull(CellularSecurityManager.threatLevel.value)
        assertNotNull(CellularSecurityManager.lastAuditSummary.value)
    }

    @Test
    fun `device owner manager generates valid adb dpm command`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        DeviceOwnerManager.refreshStatus(context)
        val cmd = DeviceOwnerManager.getDeviceOwnerAdbCommand(context)
        assertTrue(cmd.startsWith("adb shell dpm set-device-owner"))
        assertTrue(cmd.contains("KirinDeviceAdminReceiver"))
    }

    @Test
    fun `mindspore and hiai engine detects hardware npu and computes tensor benchmark`() = kotlinx.coroutines.runBlocking {
        val engines = MindSporeHiAiEngine.detectHardwareEngines()
        assertTrue(engines.isNotEmpty())
        assertTrue(engines.containsKey("HiAI Foundation"))
        assertTrue(engines.containsKey("MindSpore Lite"))

        val bench = MindSporeHiAiEngine.runTensorBenchmark("FP16")
        assertNotNull(bench)
        assertTrue(bench.throughputGflops > 100f)
        assertTrue(bench.inferenceTimeMs > 0f)
        assertTrue(bench.isHardwareAccelerated)
    }

    @Test
    fun `shizuku evolution bridge executes elevated commands and updates manifest`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertTrue(ShizukuEvolutionBridge.checkShizukuStatus(context))

        val summary = ShizukuEvolutionBridge.triggerEvolutionCheck()
        assertNotNull(summary)
        assertTrue(ShizukuEvolutionBridge.evolutionState.value.evolutionLog.isNotEmpty())

        val cmdOutput = ShizukuEvolutionBridge.executeElevatedCommand("pm disable com.huawei.browser")
        assertNotNull(cmdOutput)
        assertTrue(cmdOutput.contains("Shizuku"))
    }
}
