package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AgentDatabase
import com.example.data.AuditLogEntity
import com.example.data.KnowledgeDocEntity
import com.example.data.SnapshotEntity
import com.example.model.ActionType
import com.example.model.AgentAction
import com.example.model.ChatMessage
import com.example.model.DeviceReport
import com.example.network.AiProvider
import com.example.network.GeminiClient
import com.example.services.AgentForegroundService
import com.example.services.CapturedNotification
import com.example.services.SystemAccessibilityService
import com.example.services.SystemNotificationListener
import com.example.utils.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray

enum class NavTab(val title: String) {
    DASHBOARD("Hardware & SoC"),
    TERMINAL("CLI Matrix Core"),
    ARCHIVIST("AI Archivist & Dispatcher"),
    PERMISSIONS("System Rights"),
    AI_AGENT("Gemini Thinking"),
    ARCHITECTURE("Architecture Blueprint"),
    LOGS("Audit Records"),
    SETTINGS("API & Model")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AgentDatabase.getDatabase(application)
    private val auditDao = db.auditLogDao()
    private val snapshotDao = db.snapshotDao()
    private val knowledgeDao = db.knowledgeDocDao()
    private val geminiClient = GeminiClient(application)

    val auditLogs: StateFlow<List<AuditLogEntity>> = auditDao.getAllLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val snapshots: StateFlow<List<SnapshotEntity>> = snapshotDao.getAllSnapshots()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val knowledgeDocs: StateFlow<List<KnowledgeDocEntity>> = knowledgeDao.getAllDocs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isRagEnabled = MutableStateFlow(true)
    val isRagEnabled: StateFlow<Boolean> = _isRagEnabled.asStateFlow()

    private val _ragQuery = MutableStateFlow("")
    val ragQuery: StateFlow<String> = _ragQuery.asStateFlow()

    private val _ragSearchResults = MutableStateFlow<List<RagSearchResult>>(emptyList())
    val ragSearchResults: StateFlow<List<RagSearchResult>> = _ragSearchResults.asStateFlow()

    val capturedNotifications: StateFlow<List<CapturedNotification>> =
        SystemNotificationListener.notificationsFlow

    val throttleState: StateFlow<ThrottleState> = NativeHardwareController.throttleState
    val hotBufferCount: StateFlow<Int> = ContextSnapshotManager.hotBufferCount
    val deduplicatedCount: StateFlow<Int> = ContextSnapshotManager.deduplicatedCount
    val isPrivacyShieldActive: StateFlow<Boolean> = ContextSnapshotManager.isPrivacyShieldActive

    // Mali-G51 GPU & Choreographer V-Sync Queue
    val isDeferredVsyncActive: StateFlow<Boolean> = ChoreographerSyncManager.isDeferredVsyncActive
    val fps: StateFlow<Float> = ChoreographerSyncManager.fps
    val frameTimeMs: StateFlow<Float> = ChoreographerSyncManager.frameTimeMs
    val busContentionPercent: StateFlow<Int> = ChoreographerSyncManager.busContentionPercent
    val dvfsGovernorStatus: StateFlow<String> = ChoreographerSyncManager.dvfsGovernorStatus
    val jankCounter: StateFlow<Int> = ChoreographerSyncManager.jankCounter
    val queueState: StateFlow<DeferredQueueState> = ChoreographerSyncManager.queueState

    // ObjectBox & Zstandard In-RAM Delta Packaging
    val totalRawBytes: StateFlow<Long> = ZstdDeltaEngine.totalRawBytes
    val totalCompressedBytes: StateFlow<Long> = ZstdDeltaEngine.totalCompressedBytes
    val overallSavingsPercent: StateFlow<Float> = ZstdDeltaEngine.overallSavingsPercent
    val flashIoWritesAvoided: StateFlow<Int> = ZstdDeltaEngine.flashIoWritesAvoided
    val ramDeltas: StateFlow<List<CompressedDelta>> = ZstdDeltaEngine.deltasInRam

    // Desktop PC Symbiosis & ADB
    val adbStatus: StateFlow<AdbTunnelStatus> = DesktopSymbiosisManager.adbStatus
    val modelMatrixVersion: StateFlow<String> = DesktopSymbiosisManager.modelMatrixVersion

    // Voice Hardware, Acoustic Locator & Terminal
    val currentLanguage: StateFlow<AppLanguage> = LocalizationManager.currentLanguage
    val isAssistantEyesActive: StateFlow<Boolean> = VoiceHardwareController.isAssistantEyesActive
    val isFullScreenEyesActive: StateFlow<Boolean> = VoiceHardwareController.isFullScreenEyesActive
    val assistantUptimeSeconds: StateFlow<Long> = VoiceHardwareController.assistantUptimeSeconds
    val isTorchOn: StateFlow<Boolean> = VoiceHardwareController.isTorchOn
    val isListeningVoice: StateFlow<Boolean> = VoiceHardwareController.isListening
    val isMatrixRainActive: StateFlow<Boolean> = VoiceHardwareController.isMatrixRainActive
    val lastRecognizedSpeech: StateFlow<String> = VoiceHardwareController.lastRecognizedSpeech
    val soundAngleDegrees: StateFlow<Float> = VoiceHardwareController.soundAngleDegrees
    val soundSourceLabel: StateFlow<String> = VoiceHardwareController.soundSourceLabel
    val acousticDecibels: StateFlow<Float> = VoiceHardwareController.acousticDecibels
    val terminalLogs: StateFlow<List<String>> = VoiceHardwareController.terminalLogs

    // Optical Scanner & Neural Eyes
    val isFrontCamera: StateFlow<Boolean> = OpticalScannerController.isFrontCamera
    val isScanningActive: StateFlow<Boolean> = OpticalScannerController.isScanningActive
    val scannedQrResult: StateFlow<String?> = OpticalScannerController.scannedQrResult
    val scannedOcrText: StateFlow<String?> = OpticalScannerController.scannedOcrText
    val pulseBpm: StateFlow<Int> = OpticalScannerController.pulseBpm
    val stressIndex: StateFlow<String> = OpticalScannerController.stressIndex
    val opticalDensityVariation: StateFlow<String> = OpticalScannerController.opticalDensityVariation
    val flickerFrequencyHz: StateFlow<Int> = OpticalScannerController.flickerFrequencyHz
    val keystoreStatus: StateFlow<String> = OpticalScannerController.keystoreStatus
    val asciiPreviewFrame: StateFlow<List<String>> = OpticalScannerController.asciiPreviewFrame

    private val _isAudioImmunityActive = MutableStateFlow(AgentForegroundService.isAudioImmunityEnabledGlobally)
    val isAudioImmunityActive: StateFlow<Boolean> = _isAudioImmunityActive.asStateFlow()

    private val _zonedProcesses = MutableStateFlow(ProcessZoningManager.getZonedProcesses())
    val zonedProcesses: StateFlow<List<ZonedProcess>> = _zonedProcesses.asStateFlow()

    // Device Owner, Kiosk & Shell Lockdown
    val isDeviceOwner: StateFlow<Boolean> = DeviceOwnerManager.isDeviceOwner
    val isAdminActive: StateFlow<Boolean> = DeviceOwnerManager.isAdminActive
    val isKioskMode: StateFlow<Boolean> = DeviceOwnerManager.isKioskMode
    val systemShellLocked: StateFlow<Boolean> = DeviceOwnerManager.systemShellLocked

    // MindSpore Lite & HiAI Foundation NPU
    val isNpuDetected: StateFlow<Boolean> = MindSporeHiAiEngine.isNpuDetected
    val hiaiFoundationStatus: StateFlow<String> = MindSporeHiAiEngine.hiaiFoundationStatus
    val mindSporeLiteStatus: StateFlow<String> = MindSporeHiAiEngine.mindSporeLiteStatus
    val npuBenchmark: StateFlow<NpuBenchmarkResult> = MindSporeHiAiEngine.lastBenchmark

    // Cellular Security & IMSI-Catcher Auditor
    val cellTowers: StateFlow<List<CellTowerInfo>> = CellularSecurityManager.cellTowers
    val cellularThreatLevel: StateFlow<CellularThreatLevel> = CellularSecurityManager.threatLevel
    val cellularAuditSummary: StateFlow<String> = CellularSecurityManager.lastAuditSummary

    // Universal Android Debloater (UAD-NG & BullDozer Engine)
    val debloatPackages: StateFlow<List<DebloatPackage>> = UniversalDebloaterManager.packages
    val debloatStatusSummary: StateFlow<String> = UniversalDebloaterManager.debloatStatusSummary

    // Shizuku & PC ADB Evolution Bridge
    val isShizukuActive: StateFlow<Boolean> = ShizukuEvolutionBridge.isShizukuActive
    val evolutionState: StateFlow<EvolutionUpgradeManifest> = ShizukuEvolutionBridge.evolutionState

    private val _lastExportSummary = MutableStateFlow<String?>(null)
    val lastExportSummary: StateFlow<String?> = _lastExportSummary.asStateFlow()

    private val _deviceReport = MutableStateFlow<DeviceReport?>(null)
    val deviceReport: StateFlow<DeviceReport?> = _deviceReport.asStateFlow()

    private val _isLoadingScan = MutableStateFlow(false)
    val isLoadingScan: StateFlow<Boolean> = _isLoadingScan.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _selectedModel = MutableStateFlow("gemini-3.1-pro-preview")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _isHighThinkingEnabled = MutableStateFlow(true)
    val isHighThinkingEnabled: StateFlow<Boolean> = _isHighThinkingEnabled.asStateFlow()

    private val _currentTab = MutableStateFlow(NavTab.DASHBOARD)
    val currentTab: StateFlow<NavTab> = _currentTab.asStateFlow()

    private val _customApiKey = MutableStateFlow("")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    private val _aiProvider = MutableStateFlow(geminiClient.getAiProvider())
    val aiProvider: StateFlow<AiProvider> = _aiProvider.asStateFlow()

    private val _customOpenAiBaseUrl = MutableStateFlow(geminiClient.getCustomOpenAiBaseUrl())
    val customOpenAiBaseUrl: StateFlow<String> = _customOpenAiBaseUrl.asStateFlow()

    private val _customOpenAiApiKey = MutableStateFlow(geminiClient.getCustomOpenAiApiKey())
    val customOpenAiApiKey: StateFlow<String> = _customOpenAiApiKey.asStateFlow()

    private val _customOpenAiModel = MutableStateFlow(geminiClient.getCustomOpenAiModel())
    val customOpenAiModel: StateFlow<String> = _customOpenAiModel.asStateFlow()

    private val _deepHardwareAnatomy = MutableStateFlow<DeepHardwareAnatomy?>(null)
    val deepHardwareAnatomy: StateFlow<DeepHardwareAnatomy?> = _deepHardwareAnatomy.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        loadSettings()
        refreshSystemScan()
        initWelcomeMessage()
        VoiceHardwareController.initTts(application)

        VoiceHardwareController.onKnowledgeCaptureRequested = {
            captureTelemetryToKnowledgeBase()
        }

        // Initialize advanced device governance engines
        DeviceOwnerManager.refreshStatus(application)
        UniversalDebloaterManager.refreshInstalledStatus(application)
        CellularSecurityManager.auditCellularEnvironment(application)
        MindSporeHiAiEngine.detectHardwareEngines()
        ShizukuEvolutionBridge.checkShizukuStatus(application)

        // Seed baseline knowledge base documents if empty
        viewModelScope.launch(Dispatchers.IO) {
            val existing = knowledgeDao.getAllDocsList()
            if (existing.isEmpty()) {
                RagEngine.getBaselineSeedDocuments().forEach { doc ->
                    knowledgeDao.insertDoc(doc)
                }
            }
        }

        // Continuous Always-On Telemetry & Uptime loop for Assistant Eyes Mode
        viewModelScope.launch(Dispatchers.Default) {
            var counter = 0
            while (true) {
                kotlinx.coroutines.delay(1000)
                VoiceHardwareController.tickAssistantUptime()
                counter++
                if (isAssistantEyesActive.value && counter % 3 == 0) {
                    try {
                        val report = SystemScanner.collectDeviceReport(getApplication())
                        _deviceReport.value = report
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private fun loadSettings() {
        val prefs = getApplication<Application>().getSharedPreferences("kirin_agent_prefs", Context.MODE_PRIVATE)
        _customApiKey.value = prefs.getString("custom_gemini_api_key", "") ?: ""
    }

    fun saveCustomApiKey(key: String) {
        _customApiKey.value = key
        geminiClient.setCustomGeminiApiKey(key)
        _statusBanner.value = "API key updated successfully."
    }

    fun setAiProvider(provider: AiProvider) {
        _aiProvider.value = provider
        geminiClient.setAiProvider(provider)
        val isRu = currentLanguage.value == AppLanguage.RU
        val name = when (provider) {
            AiProvider.OFFLINE_LOCAL -> if (isRu) "Автономный режим ядра (Без сети / 100% локально)" else "Offline Local Kernel Mode"
            AiProvider.GEMINI -> "Google Gemini API"
            AiProvider.CUSTOM_OPENAI_COMPATIBLE -> if (isRu) "Пользовательский API / Локальная модель" else "Custom OpenAI-Compatible API"
        }
        _statusBanner.value = if (isRu) "Режим ИИ изменен: $name" else "AI Provider set to: $name"
    }

    fun saveCustomOpenAiSettings(baseUrl: String, apiKey: String, model: String) {
        _customOpenAiBaseUrl.value = baseUrl
        _customOpenAiApiKey.value = apiKey
        _customOpenAiModel.value = model
        geminiClient.setCustomOpenAiBaseUrl(baseUrl)
        geminiClient.setCustomOpenAiApiKey(apiKey)
        geminiClient.setCustomOpenAiModel(model)
        _statusBanner.value = "Параметры API сохранены: $model ($baseUrl)"
    }

    fun performDeepAudit() {
        viewModelScope.launch(Dispatchers.IO) {
            val anatomy = DeepSystemAudit.performDeepAudit(getApplication())
            _deepHardwareAnatomy.value = anatomy
            val doc = KnowledgeDocEntity(
                title = "Глубокая анатомия ядра и SoC Kirin 710A",
                category = "ARCHITECTURE",
                content = DeepSystemAudit.formatMarkdownReport(anatomy),
                summary = "Kirin 710A 8-core SoC, Linux Kernel, RAM: ${anatomy.ramAvailMb}/${anatomy.ramTotalMb}MB, Storage: %.1fGB free".format(anatomy.internalStorageFreeGb),
                tags = "kernel,kirin710a,sensors,hardware,cpu,storage,security",
                sourceApp = "system_deep_audit"
            )
            knowledgeDao.insertDoc(doc)
            _statusBanner.value = "Глубокий аудит ядра завершен и задокументирован в Базу Знаний!"
        }
    }

    fun setTab(tab: NavTab) {
        _currentTab.value = tab
    }

    fun setSelectedModel(model: String) {
        _selectedModel.value = model
    }

    fun setHighThinking(enabled: Boolean) {
        _isHighThinkingEnabled.value = enabled
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun togglePrivacyShield() {
        val newStatus = !isPrivacyShieldActive.value
        ContextSnapshotManager.togglePrivacyShield(newStatus)
        _statusBanner.value = if (newStatus) "Privacy Shield: Financial and credential apps masked" else "Privacy Shield: Inactive"
    }

    fun toggleAudioImmunity() {
        val context = getApplication<Application>()
        val newStatus = !_isAudioImmunityActive.value
        _isAudioImmunityActive.value = newStatus
        AgentForegroundService.setAudioImmunity(context, newStatus)
        _statusBanner.value = if (newStatus) "Audio Keep-Alive active (EMUI PowerGenie immunity enabled)" else "Audio Keep-Alive paused"
    }

    fun updateProcessZone(packageName: String, newZone: ProcessZone) {
        ProcessZoningManager.updateProcessZone(packageName, newZone)
        _zonedProcesses.value = ProcessZoningManager.getZonedProcesses()
        _statusBanner.value = "Updated $packageName to ${newZone.label}"
    }

    fun exportBatchDataset() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            try {
                val (jsonStr, gzBytes) = ContextSnapshotManager.generateCompressedBatchArchive(context)
                val summary = "Dataset compressed successfully: ${gzBytes.size} bytes (${jsonStr.length} bytes uncompressed). Ready for Google AI Studio fine-tuning or contextual ingestion."
                _lastExportSummary.value = summary
                _statusBanner.value = "Export created: ${gzBytes.size} bytes (GZIP archive)"

                auditDao.insertLog(
                    AuditLogEntity(
                        category = "ACTION_EXECUTION",
                        title = "Archivist Batch Dataset Export",
                        content = summary,
                        deviceModel = _deviceReport.value?.let { "${it.brand} ${it.model}" } ?: "Kirin 710A",
                        isSuccess = true
                    )
                )
            } catch (e: Exception) {
                _statusBanner.value = "Export failed: ${e.message}"
            }
        }
    }

    fun simulateCapture(app: String, text: String) {
        ContextSnapshotManager.ingestEvent(
            context = getApplication(),
            sourceApp = app,
            eventType = "SIMULATED_TEST",
            content = text
        )
        _statusBanner.value = "Ingested test event for $app"
    }

    fun clearSnapshots() {
        viewModelScope.launch(Dispatchers.IO) {
            snapshotDao.clearAllSnapshots()
            _statusBanner.value = "Snapshots archive cleared."
        }
    }

    fun refreshSystemScan() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingScan.value = true
            try {
                val report = SystemScanner.collectDeviceReport(getApplication())
                _deviceReport.value = report

                auditDao.insertLog(
                    AuditLogEntity(
                        category = "SYSTEM_SCAN",
                        title = "Hardware & Telemetry Scan",
                        content = "SoC: ${report.hardware} | Cores: ${report.cores.size} | Temp: ${report.cpuTempCelsius}°C | Treble: ${report.isTrebleEnabled} | Layout: ${report.partitionLayout}",
                        deviceModel = "${report.brand} ${report.model}",
                        isSuccess = true
                    )
                )
            } catch (e: Exception) {
                _statusBanner.value = "Scan error: ${e.message}"
            } finally {
                _isLoadingScan.value = false
            }
        }
    }

    fun optimizeKirinHardware() {
        viewModelScope.launch(Dispatchers.IO) {
            val success = NativeHardwareController.optimizeForKirin()
            refreshSystemScan()
            val message = if (success) {
                "Kirin 710A optimizations engaged: Thread affinity pinned to Cortex-A73 Big-cluster (Cores 4-7) with memory retention."
            } else {
                "Failed to engage Kirin hardware optimizations."
            }
            _statusBanner.value = message
            auditDao.insertLog(
                AuditLogEntity(
                    category = "HARDWARE_OPTIMIZATION",
                    title = "Kirin Big-Core Affinity Applied",
                    content = message,
                    deviceModel = _deviceReport.value?.let { "${it.brand} ${it.model}" } ?: "Kirin 710A",
                    isSuccess = success
                )
            )
        }
    }

    fun toggleForegroundDaemon() {
        val context = getApplication<Application>()
        if (SystemPermissionManager.isForegroundServiceRunning) {
            AgentForegroundService.stop(context)
            _statusBanner.value = "Foreground agent daemon stopped."
        } else {
            AgentForegroundService.start(context)
            _statusBanner.value = "Foreground agent daemon started with persistent notification."
        }
        refreshSystemScan()
    }

    fun sendDiagnosticReportToAi() {
        val report = _deviceReport.value ?: return
        val jsonPayload = SystemScanner.buildJsonPayload(report)
        val prompt = "Analyze this live device telemetry report for Huawei Nova Y61 (Kirin 710A / EVE-LX9N):\n```json\n$jsonPayload\n```\nProvide a technical assessment of: 1) Kirin 710A CPU core allocation and thermal headroom. 2) System permission states and EMUI background survival. 3) Treble compatibility and suggested automation actions."
        sendChatMessage(prompt)
        _currentTab.value = NavTab.AI_AGENT
    }

    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return

        val userMsg = ChatMessage(role = "user", content = userText)
        val updatedList = _chatMessages.value + userMsg
        _chatMessages.value = updatedList
        _isAnalyzing.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val history = updatedList.dropLast(1).map { Pair(it.role, it.content) }
            val model = _selectedModel.value
            val isThinking = _isHighThinkingEnabled.value

            // RAG Context Retrieval Augmentation
            var finalPrompt = userText
            if (_isRagEnabled.value) {
                val ragResults = RagEngine.search(userText, knowledgeDocs.value, topK = 3)
                if (ragResults.isNotEmpty() && ragResults.any { it.score >= 0.15f }) {
                    val ragContext = RagEngine.buildRagPromptContext(userText, ragResults.filter { it.score >= 0.15f })
                    finalPrompt = ragContext + "\nUser Question: " + userText
                }
            }

            val result = geminiClient.generateResponse(
                prompt = finalPrompt,
                modelName = model,
                enableHighThinking = isThinking,
                conversationHistory = history
            )

            result.onSuccess { response ->
                val parsedActions = tryParseActionPlan(response.mainText)
                val aiMsg = ChatMessage(
                    role = "assistant",
                    content = response.mainText,
                    thinking = response.thinkingText,
                    isThinking = response.thinkingText != null,
                    modelUsed = response.modelUsed,
                    actionPlan = parsedActions
                )
                _chatMessages.value = _chatMessages.value + aiMsg

                if (response.functionCallName != null) {
                    executeGeminiFunctionCall(response.functionCallName, response.functionCallArgs ?: emptyMap())
                }

                auditDao.insertLog(
                    AuditLogEntity(
                        category = "AI_ANALYSIS",
                        title = "Gemini Reasoning ($model)",
                        content = response.mainText.take(200) + if (response.mainText.length > 200) "..." else "",
                        deviceModel = _deviceReport.value?.let { "${it.brand} ${it.model}" } ?: "Huawei",
                        isSuccess = true
                    )
                )
            }.onFailure { err ->
                val errorMsg = ChatMessage(
                    role = "assistant",
                    content = "Error communicating with Gemini: ${err.message}\n\nPlease check your API key in Settings or ensure internet connectivity."
                )
                _chatMessages.value = _chatMessages.value + errorMsg
            }
            _isAnalyzing.value = false
        }
    }

    fun executeSingleAction(action: AgentAction) {
        viewModelScope.launch(Dispatchers.IO) {
            when (action.type) {
                ActionType.SET_CPU_AFFINITY, ActionType.LOCK_MEMORY_PAGES, ActionType.OPTIMIZE_EMUI_RETENTION -> {
                    optimizeKirinHardware()
                }
                ActionType.SCAN_SYSTEM, ActionType.EXPORT_TELEMETRY -> {
                    refreshSystemScan()
                }
                ActionType.INSPECT_ACCESSIBILITY_NODES -> {
                    val tree = SystemAccessibilityService.inspectActiveHierarchy()
                    val msg = ChatMessage(role = "system", content = "Accessibility Node Inspection Result:\n$tree")
                    _chatMessages.value = _chatMessages.value + msg
                }
                ActionType.EMULATE_CLICK -> {
                    val success = SystemAccessibilityService.clickNodeByText(action.target)
                    _statusBanner.value = "Click on '${action.target}' executed: $success"
                }
                ActionType.GLOBAL_NAV_ACTION -> {
                    val actCode = when (action.target.uppercase()) {
                        "BACK" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                        "HOME" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                        "RECENTS" -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
                        else -> android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                    }
                    val ok = SystemAccessibilityService.executeGlobal(actCode)
                    _statusBanner.value = "Global navigation '${action.target}' executed: $ok"
                }
                ActionType.PROCESS_NOTIFICATION -> {
                    val notifs = capturedNotifications.value
                    _statusBanner.value = "Processing ${notifs.size} captured notifications"
                }
                ActionType.DEBLOAT_PACKAGE -> {
                    freezeAllTelemetryPackages()
                }
                ActionType.AUDIT_CELLULAR -> {
                    auditCellularSecurity()
                }
                ActionType.SET_KIOSK_MODE -> {
                    lockSystemShell(true)
                }
                ActionType.BENCHMARK_NPU -> {
                    runNpuBenchmark("FP16")
                }
                ActionType.TOGGLE_TORCH -> {
                    toggleTorch()
                }
                ActionType.CAPTURE_KNOWLEDGE -> {
                    captureTelemetryToKnowledgeBase()
                }
                ActionType.TRIGGER_DESKTOP_SYNC -> {
                    triggerDesktopSync()
                }
                ActionType.RAM_COMPACT_ZSTD -> {
                    ZstdDeltaEngine.compressPayload("system", "Manual RAM Compaction")
                    _statusBanner.value = "RAM Compacted: ${ZstdDeltaEngine.overallSavingsPercent.value}% savings"
                }
                ActionType.MEASURE_PULSE_PPG -> {
                    measurePulseAndStress()
                }
                ActionType.VOICE_TTS_FEEDBACK -> {
                    VoiceHardwareController.speak(action.details)
                }
            }

            auditDao.insertLog(
                AuditLogEntity(
                    category = "ACTION_EXECUTION",
                    title = "Executed Action: ${action.type}",
                    content = "Target: ${action.target} | Details: ${action.details}",
                    deviceModel = _deviceReport.value?.let { "${it.brand} ${it.model}" } ?: "System",
                    isSuccess = true
                )
            )
        }
    }

    fun clearChat() {
        initWelcomeMessage()
    }

    fun clearLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            auditDao.clearAllLogs()
            _statusBanner.value = "Audit logs cleared."
        }
    }

    // Mali-G51 GPU & V-Sync Actions
    fun toggleDeferredVsync(enabled: Boolean? = null) {
        ChoreographerSyncManager.toggleDeferredVsync(enabled)
        val state = ChoreographerSyncManager.isDeferredVsyncActive.value
        _statusBanner.value = if (state) "Deferred V-Sync Queue active: 60 FPS locked, 0 bus clash." else "Direct Render active: Attention! Mali-G51 bus conflict possible."
    }

    fun resetJankStats() {
        ChoreographerSyncManager.resetJankCounter()
        _statusBanner.value = "Jank frame drop counter reset."
    }

    fun triggerDeferredOverlayTest(appName: String, payload: String) {
        // Also compress the delta in RAM via Zstd
        ZstdDeltaEngine.compressPayload(appName, payload)

        ChoreographerSyncManager.scheduleDeferredOverlay(
            appName = appName,
            payload = payload
        ) {
            val isDeferred = ChoreographerSyncManager.isDeferredVsyncActive.value
            _statusBanner.value = if (isDeferred) {
                "Overlay frame committed via V-Sync during Mali-G51 idle window. 0 jank!"
            } else {
                "Overlay drawn directly. High memory bus contention detected!"
            }
        }
    }

    // ObjectBox & Zstandard Actions
    fun clearRamDeltas() {
        ZstdDeltaEngine.clearRamDeltas()
        _statusBanner.value = "In-RAM Zstd deltas cleared. Flash memory completely untouched."
    }

    // Desktop Symbiosis Actions
    fun triggerDesktopSync() {
        val summary = DesktopSymbiosisManager.triggerDesktopSync()
        _statusBanner.value = summary
        viewModelScope.launch(Dispatchers.IO) {
            auditDao.insertLog(
                AuditLogEntity(
                    category = "DESKTOP_ADB_SYNC",
                    title = "ADB:5037 Sync",
                    content = "Desktop AI synchronized daily archives. Model weights updated to ${DesktopSymbiosisManager.modelMatrixVersion.value}.",
                    deviceModel = "Huawei Nova Y61",
                    isSuccess = true
                )
            )
        }
    }

    // Voice, Torch, Acoustic & Optical Actions
    fun toggleTorch() {
        VoiceHardwareController.toggleTorch(getApplication())
    }

    fun sendVoiceCommand(command: String) {
        val result = VoiceHardwareController.parseAndExecuteVoiceCommand(getApplication(), command)
        _statusBanner.value = result
    }

    fun startListeningSpeech() {
        VoiceHardwareController.startListening(getApplication()) { recognized ->
            _statusBanner.value = "Recognized: $recognized"
        }
    }

    fun stopListeningSpeech() {
        VoiceHardwareController.stopListening()
    }

    fun toggleMatrixRain(enabled: Boolean? = null) {
        VoiceHardwareController.toggleMatrixRain(enabled)
    }

    fun toggleLanguage() {
        LocalizationManager.toggleLanguage()
    }

    fun setLanguage(lang: AppLanguage) {
        LocalizationManager.setLanguage(lang)
    }

    fun toggleAssistantEyesMode(enabled: Boolean? = null) {
        val state = VoiceHardwareController.toggleAssistantEyesMode(getApplication(), enabled)
        _statusBanner.value = if (state) "Assistant Eyes Mode: ACTIVE (Continuous HUD loop)" else "Assistant Eyes Mode: OFF"
    }

    fun setFullScreenEyes(active: Boolean) {
        VoiceHardwareController.setFullScreenEyes(active)
    }

    fun toggleFullScreenEyes(): Boolean {
        return VoiceHardwareController.toggleFullScreenEyes()
    }

    fun measurePulseAndStress() {
        val res = OpticalScannerController.measurePulseAndStress()
        _statusBanner.value = res
    }

    fun detectAmbientFlicker() {
        val freq = OpticalScannerController.detectAmbientFlicker()
        _statusBanner.value = "Ambient Light Flicker: $freq Hz"
    }

    fun setListeningVoice(active: Boolean) {
        if (active) {
            startListeningSpeech()
        } else {
            stopListeningSpeech()
        }
    }

    fun triggerAcousticPulse(angle: Float) {
        VoiceHardwareController.triggerAcousticPulse(angle)
    }

    fun toggleCameraFacing() {
        OpticalScannerController.toggleCameraFacing()
    }

    fun scanQrCode(data: String) {
        OpticalScannerController.scanQrCode(data)
        _statusBanner.value = "QR Code scanned: $data"
    }

    fun scanOcrText(text: String) {
        OpticalScannerController.scanOcrText(text)
        _statusBanner.value = "OCR Text extracted: $text"
    }

    fun clearTerminalLogs() {
        VoiceHardwareController.clearLogs()
    }

    // =========================================================================
    // KNOWLEDGE BASE & RAG SYSTEM: ALL PHONE DATA CAPTURE & DOCUMENTATION
    // =========================================================================

    fun setRagEnabled(enabled: Boolean) {
        _isRagEnabled.value = enabled
        val isRu = currentLanguage.value == AppLanguage.RU
        _statusBanner.value = if (enabled) {
            if (isRu) "RAG-аугментация базы знаний: ВКЛЮЧЕНА" else "Knowledge Base RAG: ENABLED"
        } else {
            if (isRu) "RAG-аугментация базы знаний: ВЫКЛЮЧЕНА" else "Knowledge Base RAG: DISABLED"
        }
    }

    fun searchRag(query: String) {
        _ragQuery.value = query
        val docs = knowledgeDocs.value
        val results = RagEngine.search(query, docs, topK = 4)
        _ragSearchResults.value = results
    }

    fun captureTelemetryToKnowledgeBase() {
        val rep = _deviceReport.value
        val now = System.currentTimeMillis()
        val timeStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(now))
        val isRu = currentLanguage.value == AppLanguage.RU

        val title = if (isRu) "Снимок телеметрии Nova Y61 [$timeStr]" else "Device Telemetry Snapshot [$timeStr]"
        val summary = if (rep != null) {
            "CPU: ${rep.cpuTempCelsius}°C, Bat: ${rep.batteryPercent}%, RAM Free: ${rep.ramAvailMb} MB"
        } else {
            "Hardware state capture"
        }

        val content = buildString {
            append("# $title\n\n")
            if (rep != null) {
                append("## Аппаратные показатели (Hardware Telemetry)\n")
                append("- **Устройство:** ${rep.brand} ${rep.model}\n")
                append("- **Платформа / SoC:** ${rep.hardware} (${rep.cpuArch}), ядер: ${rep.cores.size.coerceAtLeast(8)}\n")
                append("- **Температура CPU:** ${rep.cpuTempCelsius}°C\n")
                append("- **Оперативная память (RAM):** Доступно ${rep.ramAvailMb} MB из ${rep.ramTotalMb} MB (${rep.ramUsagePercent}% занято)\n")
                append("- **Батарея:** ${rep.batteryPercent}%\n")
                append("- **Графика & NPU:** ${rep.gpuNpuAccelerator}\n")
                append("- **Разметка накопителя:** ${rep.partitionLayout}\n")
                append("- **ОС & Сборка:** Android ${rep.androidRelease}, Сборка: ${rep.emuiBuild}, Treble: ${rep.isTrebleEnabled}\n")
                append("- **Безопасность:** SELinux: ${if (rep.isSelinuxEnforcing) "Enforcing" else "Permissive"}, Патч: ${rep.securityPatch}\n\n")
            }
            append("## Оптические и акустические датчики\n")
            append("- **Пульс PPG:** ${pulseBpm.value} BPM, Стресс-индекс: ${stressIndex.value}\n")
            append("- **Акустический локатор:** Азимут ${soundAngleDegrees.value.toInt()}°, Источник: ${soundSourceLabel.value}, Уровень: ${acousticDecibels.value.toInt()} dB\n")
            append("- **Zstandard сжатие RAM:** ${overallSavingsPercent.value}% экономии flash I/O\n")
        }

        viewModelScope.launch(Dispatchers.IO) {
            val doc = KnowledgeDocEntity(
                title = title,
                category = "TELEMETRY",
                content = content,
                summary = summary,
                tags = "telemetry,hardware,battery,cpu,ram,novay61,kirin710a",
                wordCount = content.split("\\s+".toRegex()).size,
                timestamp = now,
                sourceApp = "system"
            )
            knowledgeDao.insertDoc(doc)
            _statusBanner.value = if (isRu) "Телеметрия телефона успешно задокументирована в Базу Знаний!" else "Phone telemetry captured into Knowledge Base!"
            VoiceHardwareController.speak(if (isRu) "Телеметрия задокументирована в базу знаний" else "Telemetry documented into knowledge base")
        }
    }

    fun captureOcrToKnowledgeBase(text: String, titleSuffix: String = "") {
        if (text.isBlank()) {
            _statusBanner.value = "Нет распознанного текста для сохранения в базу знаний"
            return
        }
        val now = System.currentTimeMillis()
        val timeStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(now))
        val isRu = currentLanguage.value == AppLanguage.RU
        val title = if (isRu) "Захват текста OCR (Камера) [$timeStr] $titleSuffix".trim() else "OCR Text Capture (Camera) [$timeStr] $titleSuffix".trim()
        val summary = text.take(90).replace("\n", " ") + if (text.length > 90) "..." else ""

        viewModelScope.launch(Dispatchers.IO) {
            val doc = KnowledgeDocEntity(
                title = title,
                category = "OCR_SCAN",
                content = "# $title\n\n$text",
                summary = summary,
                tags = "ocr,camera,scan,document,text",
                wordCount = text.split("\\s+".toRegex()).size,
                timestamp = now,
                sourceApp = "camera.scanner"
            )
            knowledgeDao.insertDoc(doc)
            _statusBanner.value = if (isRu) "Распознанный текст OCR сохранен в Базу Знаний!" else "OCR text saved to Knowledge Base!"
        }
    }

    fun captureNotificationsToKnowledgeBase() {
        val notifs = capturedNotifications.value
        if (notifs.isEmpty()) {
            _statusBanner.value = "Нет перехваченных уведомлений для архивирования"
            return
        }
        val now = System.currentTimeMillis()
        val timeStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(now))
        val isRu = currentLanguage.value == AppLanguage.RU
        val title = if (isRu) "Архив уведомлений телефона [$timeStr] (${notifs.size} шт.)" else "Notification Archive [$timeStr] (${notifs.size} items)"

        val content = buildString {
            append("# $title\n\n")
            append("Сводка перехваченных push-уведомлений и сообщений:\n\n")
            notifs.forEachIndexed { i, n ->
                val dateFmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(n.postTime))
                append("### ${i + 1}. [${n.appLabel}] ${n.title}\n")
                append("- **Пакет:** `${n.packageName}`\n")
                append("- **Время:** $dateFmt\n")
                append("- **Текст:** ${n.text}\n\n")
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            val doc = KnowledgeDocEntity(
                title = title,
                category = "NOTIFICATION",
                content = content,
                summary = "${notifs.size} уведомлений заархивировано",
                tags = "notifications,alerts,messages,telegram,system",
                wordCount = content.split("\\s+".toRegex()).size,
                timestamp = now,
                sourceApp = "notification.listener"
            )
            knowledgeDao.insertDoc(doc)
            _statusBanner.value = if (isRu) "Уведомления задокументированы в Базу Знаний!" else "Notifications captured into Knowledge Base!"
        }
    }

    fun createCustomKnowledgeDoc(title: String, content: String, category: String = "MANUAL", tags: String = "notes,custom") {
        if (title.isBlank() || content.isBlank()) return
        val now = System.currentTimeMillis()
        viewModelScope.launch(Dispatchers.IO) {
            val doc = KnowledgeDocEntity(
                title = title.trim(),
                category = category.trim().ifBlank { "MANUAL" },
                content = content.trim(),
                summary = content.take(90).replace("\n", " ") + if (content.length > 90) "..." else "",
                tags = tags.trim().ifBlank { "notes,custom" },
                wordCount = content.split("\\s+".toRegex()).size,
                timestamp = now,
                sourceApp = "user"
            )
            knowledgeDao.insertDoc(doc)
            _statusBanner.value = "Документ добавлен в базу знаний!"
        }
    }

    fun deleteKnowledgeDoc(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            knowledgeDao.deleteDocById(id)
            _statusBanner.value = "Документ удален из базы знаний"
        }
    }

    fun clearAllKnowledgeDocs() {
        viewModelScope.launch(Dispatchers.IO) {
            knowledgeDao.clearAllDocs()
            _statusBanner.value = "База знаний очищена."
        }
    }

    fun exportKnowledgeBase(asMarkdown: Boolean = true): String {
        val docs = knowledgeDocs.value
        val result = if (asMarkdown) RagEngine.exportAllAsMarkdown(docs) else RagEngine.exportAllAsJson(docs)
        _statusBanner.value = "База знаний экспортирована (${docs.size} документов)"
        return result
    }

    // =========================================================================
    // FUNCTION CALLING, DEVICE OWNER, DEBLOATER & IMSI SECURITY ACTIONS
    // =========================================================================

    private fun executeGeminiFunctionCall(fnName: String, args: Map<String, String>) {
        viewModelScope.launch(Dispatchers.IO) {
            when (fnName) {
                "debloat_package" -> {
                    val pkg = args["packageName"] ?: ""
                    val action = args["action"] ?: "FREEZE"
                    val isFreeze = action.uppercase() == "FREEZE"
                    UniversalDebloaterManager.togglePackageFreeze(getApplication(), pkg, isFreeze)
                    _statusBanner.value = "FunctionCall: $pkg $action executed."
                    auditDao.insertLog(
                        AuditLogEntity(
                            category = "FUNCTION_CALL",
                            title = "FunctionCall: debloat_package",
                            content = "Target: $pkg | Action: $action",
                            deviceModel = "Huawei Nova Y61",
                            isSuccess = true
                        )
                    )
                }
                "audit_cellular_imsi_security" -> {
                    CellularSecurityManager.auditCellularEnvironment(getApplication())
                    val level = CellularSecurityManager.threatLevel.value.label
                    _statusBanner.value = "FunctionCall: Cell security audit finished: $level"
                    auditDao.insertLog(
                        AuditLogEntity(
                            category = "FUNCTION_CALL",
                            title = "FunctionCall: audit_cellular_imsi_security",
                            content = "Result: $level",
                            deviceModel = "Huawei Nova Y61",
                            isSuccess = true
                        )
                    )
                }
                "set_device_owner_kiosk" -> {
                    val enable = args["enable"].toBoolean()
                    DeviceOwnerManager.lockSystemShell(getApplication(), enable)
                    _statusBanner.value = "FunctionCall: System Shell restricted: $enable"
                    auditDao.insertLog(
                        AuditLogEntity(
                            category = "FUNCTION_CALL",
                            title = "FunctionCall: set_device_owner_kiosk",
                            content = "Enabled: $enable",
                            deviceModel = "Huawei Nova Y61",
                            isSuccess = true
                        )
                    )
                }
                "benchmark_mindspore_npu" -> {
                    val prec = args["precision"] ?: "FP16"
                    val bench = MindSporeHiAiEngine.runTensorBenchmark(prec)
                    _statusBanner.value = "FunctionCall: NPU Benchmark ${bench.throughputGflops} GFLOPS"
                    auditDao.insertLog(
                        AuditLogEntity(
                            category = "FUNCTION_CALL",
                            title = "FunctionCall: benchmark_mindspore_npu",
                            content = "GFLOPS: ${bench.throughputGflops}, Latency: ${bench.inferenceTimeMs}ms",
                            deviceModel = "Huawei Nova Y61",
                            isSuccess = true
                        )
                    )
                }
            }
        }
    }

    fun togglePackageFreeze(packageName: String, freeze: Boolean) {
        UniversalDebloaterManager.togglePackageFreeze(getApplication(), packageName, freeze)
    }

    fun freezeAllTelemetryPackages(): Int {
        val count = UniversalDebloaterManager.freezeAllTelemetry(getApplication())
        _statusBanner.value = "Заморожено $count пакетов телеметрии и аналитики EMUI."
        return count
    }

    fun restoreAllDebloatedPackages(): Int {
        val count = UniversalDebloaterManager.restoreAllPackages(getApplication())
        _statusBanner.value = "Восстановлено $count пакетов."
        return count
    }

    fun generateBullDozerScript(): String {
        return UniversalDebloaterManager.generateBullDozerShellScript()
    }

    fun auditCellularSecurity() {
        CellularSecurityManager.auditCellularEnvironment(getApplication())
        _statusBanner.value = CellularSecurityManager.lastAuditSummary.value
    }

    fun toggleKioskMode(activity: android.app.Activity, enable: Boolean) {
        val ok = DeviceOwnerManager.setKioskMode(activity, enable)
        _statusBanner.value = if (ok) "Режим киоска (LockTaskMode): ${if (enable) "ВКЛ" else "ВЫКЛ"}" else "Ошибка переключения киоска (требуются права Device Owner)"
    }

    fun lockSystemShell(lock: Boolean) {
        val ok = DeviceOwnerManager.lockSystemShell(getApplication(), lock)
        _statusBanner.value = if (ok) "Системная оболочка и экран блокировки: ${if (lock) "ЗАБЛОКИРОВАНЫ" else "РАЗБЛОКИРОВАНЫ"}" else "Ошибка: требуется статус Device Admin"
    }

    fun runNpuBenchmark(precision: String = "FP16") {
        viewModelScope.launch {
            val bench = MindSporeHiAiEngine.runTensorBenchmark(precision)
            _statusBanner.value = "Тест NPU MindSpore Lite: ${bench.throughputGflops} GFLOPS, ${bench.inferenceTimeMs} мс"
        }
    }

    fun triggerEvolutionCheck() {
        val msg = ShizukuEvolutionBridge.triggerEvolutionCheck()
        _statusBanner.value = msg
    }

    fun executeElevatedShell(cmd: String): String {
        val out = ShizukuEvolutionBridge.executeElevatedCommand(cmd)
        _statusBanner.value = "Shizuku: выполнено $cmd"
        return out
    }

    private fun initWelcomeMessage() {
        val welcome = ChatMessage(
            role = "assistant",
            content = """
                Welcome to Kirin AI Agent & Digital Archivist!
                
                Configured for Huawei Nova Y61 (Kirin 710A / EVE-LX9N) and Android environments.
                
                Active Architectural Systems:
                • AI Archivist & Dispatcher: 3-tier memory pipeline (Hot RAM mlockall, Warm Room DB, Cold GZIP dataset export)
                • Semantic Deduplication & Privacy Shield: Real-time text diffing and banking/credential masking
                • Adaptive Thermal Throttling: Prevents 14nm hardware step-drop throttling
                • EMUI Audio Keep-Alive: Silent AudioTrack immunity against IAware/PowerGenie
                • Gemini 3.1 Pro (ThinkingLevel.HIGH): Full reasoning engine
                
                Ready for system inspection, action planning, or dataset synthesis!
            """.trimIndent(),
            modelUsed = _selectedModel.value
        )
        _chatMessages.value = listOf(welcome)
    }

    private fun tryParseActionPlan(text: String): List<AgentAction>? {
        return try {
            val startIdx = text.indexOf('[')
            val endIdx = text.lastIndexOf(']')
            if (startIdx != -1 && endIdx > startIdx) {
                val candidateJson = text.substring(startIdx, endIdx + 1)
                val jsonArr = JSONArray(candidateJson)
                val list = mutableListOf<AgentAction>()
                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.optJSONObject(i) ?: continue
                    val typeStr = obj.optString("type", "SCAN_SYSTEM")
                    val type = try { ActionType.valueOf(typeStr) } catch (_: Exception) { ActionType.SCAN_SYSTEM }
                    val target = obj.optString("target", "system")
                    val details = obj.optString("details", "AI generated plan step")
                    list.add(
                        AgentAction(
                            id = "action_${System.currentTimeMillis()}_$i",
                            type = type,
                            target = target,
                            details = details,
                            status = "READY"
                        )
                    )
                }
                if (list.isNotEmpty()) list else null
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}
