package com.example.network

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.utils.LocalAutonomousEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class AiProvider {
    OFFLINE_LOCAL,            // 100% Offline On-Device Kernel Engine (Zero Network / Instant Response)
    GEMINI,                   // Google Gemini API (gemini-3.1-pro-preview, gemini-3.5-flash)
    CUSTOM_OPENAI_COMPATIBLE  // Custom API / Local LLM (Ollama, vLLM, OpenRouter, DeepSeek, OpenAI)
}

data class GeminiResponse(
    val mainText: String,
    val thinkingText: String? = null,
    val modelUsed: String,
    val functionCallName: String? = null,
    val functionCallArgs: Map<String, String>? = null,
    val isAutonomousOffline: Boolean = false
)

class GeminiClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    private val mediaType = "application/json; charset=utf-8".toMediaType()

    private val prefs = context.getSharedPreferences("kirin_agent_prefs", Context.MODE_PRIVATE)

    fun getAiProvider(): AiProvider {
        val saved = prefs.getString("ai_provider_mode", AiProvider.GEMINI.name)
        return try {
            AiProvider.valueOf(saved ?: AiProvider.GEMINI.name)
        } catch (_: Exception) {
            AiProvider.GEMINI
        }
    }

    fun setAiProvider(provider: AiProvider) {
        prefs.edit().putString("ai_provider_mode", provider.name).apply()
    }

    fun getEffectiveApiKey(): String {
        val customKey = prefs.getString("custom_gemini_api_key", null)?.trim()
        if (!customKey.isNullOrEmpty()) {
            return customKey
        }
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
    }

    fun setCustomGeminiApiKey(key: String) {
        prefs.edit().putString("custom_gemini_api_key", key.trim()).apply()
    }

    fun getCustomOpenAiBaseUrl(): String {
        return prefs.getString("custom_openai_base_url", "http://192.168.1.100:11434/v1") ?: "http://192.168.1.100:11434/v1"
    }

    fun setCustomOpenAiBaseUrl(url: String) {
        prefs.edit().putString("custom_openai_base_url", url.trim()).apply()
    }

    fun getCustomOpenAiApiKey(): String {
        return prefs.getString("custom_openai_api_key", "") ?: ""
    }

    fun setCustomOpenAiApiKey(token: String) {
        prefs.edit().putString("custom_openai_api_key", token.trim()).apply()
    }

    fun getCustomOpenAiModel(): String {
        return prefs.getString("custom_openai_model", "llama3:8b") ?: "llama3:8b"
    }

    fun setCustomOpenAiModel(model: String) {
        prefs.edit().putString("custom_openai_model", model.trim()).apply()
    }

    suspend fun generateResponse(
        prompt: String,
        modelName: String = "gemini-3.1-pro-preview",
        enableHighThinking: Boolean = true,
        enableFunctionCalling: Boolean = true,
        systemInstructionText: String? = null,
        conversationHistory: List<Pair<String, String>> = emptyList() // Pair(role, text)
    ): Result<GeminiResponse> = withContext(Dispatchers.IO) {
        val provider = getAiProvider()

        // 1. 100% OFFLINE LOCAL KERNEL ENGINE
        if (provider == AiProvider.OFFLINE_LOCAL) {
            val localResult = LocalAutonomousEngine.processQuery(
                context = context,
                prompt = prompt,
                executeImmediately = true
            )
            return@withContext Result.success(
                GeminiResponse(
                    mainText = localResult.responseText,
                    modelUsed = localResult.modelSignature,
                    isAutonomousOffline = true
                )
            )
        }

        // 2. CUSTOM OPENAI-COMPATIBLE API (Ollama / vLLM / OpenRouter / DeepSeek)
        if (provider == AiProvider.CUSTOM_OPENAI_COMPATIBLE) {
            return@withContext executeOpenAiCompatibleRequest(prompt, systemInstructionText, conversationHistory)
        }

        // 3. GOOGLE GEMINI API
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Graceful fallback to offline local engine
            val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
            return@withContext Result.success(
                GeminiResponse(
                    mainText = fallback.responseText + "\n\n*(Автономный режим ядра: Ключ Gemini API не настроен. Запрос обработан локально на телефоне без сети)*",
                    modelUsed = "Fallback: " + fallback.modelSignature,
                    isAutonomousOffline = true
                )
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

            val rootJson = JSONObject()

            // System instructions
            val effectiveSystemPrompt = systemInstructionText ?: DEFAULT_SYSTEM_INSTRUCTION
            rootJson.put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", effectiveSystemPrompt)
                }))
            })

            // Contents array
            val contentsArray = JSONArray()
            for ((role, text) in conversationHistory) {
                val mappedRole = if (role == "user") "user" else "model"
                contentsArray.put(JSONObject().apply {
                    put("role", mappedRole)
                    put("parts", JSONArray().put(JSONObject().apply {
                        put("text", text)
                    }))
                })
            }

            // Current prompt
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", prompt)
                }))
            })
            rootJson.put("contents", contentsArray)

            // Generation config
            val generationConfig = JSONObject()
            if (modelName.contains("pro") && enableHighThinking) {
                val thinkingConfig = JSONObject().apply {
                    put("thinkingLevel", "high")
                }
                generationConfig.put("thinkingConfig", thinkingConfig)
            }
            rootJson.put("generationConfig", generationConfig)

            // Function Calling Tools
            if (enableFunctionCalling) {
                val toolsArray = JSONArray()
                val functionDeclarations = JSONArray()

                // Tool 1: debloat_package
                functionDeclarations.put(JSONObject().apply {
                    put("name", "debloat_package")
                    put("description", "Freezes or unfreezes a pre-installed Huawei EMUI bloatware/telemetry package using DeviceOwner or Shizuku")
                    put("parameters", JSONObject().apply {
                        put("type", "OBJECT")
                        put("properties", JSONObject().apply {
                            put("packageName", JSONObject().put("type", "STRING").put("description", "Package name e.g. com.huawei.browser, com.huawei.video"))
                            put("action", JSONObject().put("type", "STRING").put("description", "FREEZE or RESTORE"))
                        })
                        put("required", JSONArray().put("packageName").put("action"))
                    })
                })

                // Tool 2: audit_cellular_imsi_security
                functionDeclarations.put(JSONObject().apply {
                    put("name", "audit_cellular_imsi_security")
                    put("description", "Scans nearby cell towers (LTE/GSM), checks for 2G cipher downgrade attacks and rogue IMSI catchers")
                    put("parameters", JSONObject().apply {
                        put("type", "OBJECT")
                        put("properties", JSONObject())
                    })
                })

                // Tool 3: set_device_owner_kiosk
                functionDeclarations.put(JSONObject().apply {
                    put("name", "set_device_owner_kiosk")
                    put("description", "Locks down system shell and enters LockTaskMode (Kiosk) to suppress system UI and lockscreens")
                    put("parameters", JSONObject().apply {
                        put("type", "OBJECT")
                        put("properties", JSONObject().apply {
                            put("enable", JSONObject().put("type", "BOOLEAN").put("description", "True to lock in kiosk, false to exit"))
                        })
                        put("required", JSONArray().put("enable"))
                    })
                })

                // Tool 4: benchmark_mindspore_npu
                functionDeclarations.put(JSONObject().apply {
                    put("name", "benchmark_mindspore_npu")
                    put("description", "Executes hardware tensor benchmark on Kirin 710A DaVinci NPU and Mali-G51 GPU with MindSpore Lite")
                    put("parameters", JSONObject().apply {
                        put("type", "OBJECT")
                        put("properties", JSONObject().apply {
                            put("precision", JSONObject().put("type", "STRING").put("description", "FP16 or INT8"))
                        })
                    })
                })

                toolsArray.put(JSONObject().put("functionDeclarations", functionDeclarations))
                rootJson.put("tools", toolsArray)
            }

            val body = rootJson.toString().toRequestBody(mediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = client.newCall(request).execute()
            response.use { resp ->
                val respBody = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
                    return@withContext Result.success(
                        GeminiResponse(
                            mainText = fallback.responseText + "\n\n*(Автономный режим ядра: HTTP ${resp.code} от Google Gemini. Запрос исполнен локально на телефоне без сети)*",
                            modelUsed = "Fallback: " + fallback.modelSignature,
                            isAutonomousOffline = true
                        )
                    )
                }

                val json = JSONObject(respBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
                    return@withContext Result.success(
                        GeminiResponse(
                            mainText = fallback.responseText + "\n\n*(Автономный режим ядра: Пустой ответ от Gemini. Запрос обработан локально на телефоне)*",
                            modelUsed = "Fallback: " + fallback.modelSignature,
                            isAutonomousOffline = true
                        )
                    )
                }

                val firstCandidate = candidates.getJSONObject(0)
                val contentObj = firstCandidate.optJSONObject("content")
                val parts = contentObj?.optJSONArray("parts")

                var mainAnswer = ""
                var thoughts: String? = null
                var calledFnName: String? = null
                var calledFnArgs: MutableMap<String, String>? = null

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val text = part.optString("text", "")
                        val isThought = part.optBoolean("thought", false)

                        val funcCallObj = part.optJSONObject("functionCall")
                        if (funcCallObj != null) {
                            calledFnName = funcCallObj.optString("name", null)
                            val argsObj = funcCallObj.optJSONObject("args")
                            if (argsObj != null) {
                                calledFnArgs = mutableMapOf()
                                val keys = argsObj.keys()
                                while (keys.hasNext()) {
                                    val k = keys.next()
                                    calledFnArgs[k] = argsObj.optString(k, "")
                                }
                            }
                        }

                        if (isThought) {
                            thoughts = if (thoughts == null) text else "$thoughts\n$text"
                        } else if (text.isNotEmpty()) {
                            mainAnswer = if (mainAnswer.isEmpty()) text else "$mainAnswer\n$text"
                        }
                    }
                }

                if (mainAnswer.isBlank() && thoughts != null) {
                    mainAnswer = thoughts
                    thoughts = null
                }

                if (mainAnswer.isBlank() && calledFnName != null) {
                    mainAnswer = "[Function Call Invoked]: $calledFnName(args: $calledFnArgs)"
                }

                Result.success(
                    GeminiResponse(
                        mainText = mainAnswer.ifBlank { "Analysis complete." },
                        thinkingText = thoughts,
                        modelUsed = modelName,
                        functionCallName = calledFnName,
                        functionCallArgs = calledFnArgs
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("GeminiClient", "Network exception: ${e.message}, falling back to LocalAutonomousEngine", e)
            val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
            Result.success(
                GeminiResponse(
                    mainText = fallback.responseText + "\n\n*(Автономный режим ядра: Сеть недоступна (${e.message ?: "Offline"}). Запрос исполнен локально на телефоне без интернета)*",
                    modelUsed = "Fallback: " + fallback.modelSignature,
                    isAutonomousOffline = true
                )
            )
        }
    }

    private suspend fun executeOpenAiCompatibleRequest(
        prompt: String,
        systemInstructionText: String?,
        conversationHistory: List<Pair<String, String>>
    ): Result<GeminiResponse> {
        val baseUrl = getCustomOpenAiBaseUrl().trimEnd('/')
        val token = getCustomOpenAiApiKey()
        val customModel = getCustomOpenAiModel()

        return try {
            val url = "$baseUrl/chat/completions"
            val rootJson = JSONObject()
            rootJson.put("model", customModel)

            val messagesArr = JSONArray()
            val systemPrompt = systemInstructionText ?: DEFAULT_SYSTEM_INSTRUCTION
            messagesArr.put(JSONObject().apply {
                put("role", "system")
                put("content", systemPrompt)
            })

            for ((role, text) in conversationHistory) {
                messagesArr.put(JSONObject().apply {
                    put("role", if (role == "user") "user" else "assistant")
                    put("content", text)
                })
            }

            messagesArr.put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            })

            rootJson.put("messages", messagesArr)
            rootJson.put("temperature", 0.3)

            val body = rootJson.toString().toRequestBody(mediaType)
            val reqBuilder = Request.Builder().url(url).post(body)
            if (token.isNotBlank()) {
                reqBuilder.addHeader("Authorization", "Bearer $token")
            }

            val resp = client.newCall(reqBuilder.build()).execute()
            return resp.use { r ->
                val bodyStr = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
                    Result.success(
                        GeminiResponse(
                            mainText = fallback.responseText + "\n\n*(Автономный режим: Ошибка HTTP ${r.code} от $baseUrl. Использован локальный движок ядра)*",
                            modelUsed = "Local Fallback (Remote HTTP ${r.code})",
                            isAutonomousOffline = true
                        )
                    )
                } else {
                    val json = JSONObject(bodyStr)
                    val choices = json.optJSONArray("choices")
                    val firstChoice = choices?.optJSONObject(0)
                    val msgObj = firstChoice?.optJSONObject("message")
                    val text = msgObj?.optString("content", "") ?: ""

                    Result.success(
                        GeminiResponse(
                            mainText = text.ifBlank { "No textual content returned from $customModel." },
                            modelUsed = "$customModel ($baseUrl)"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("GeminiClient", "Custom API error: ${e.message}, falling back to LocalAutonomousEngine")
            val fallback = LocalAutonomousEngine.processQuery(context, prompt, executeImmediately = true)
            return Result.success(
                GeminiResponse(
                    mainText = fallback.responseText + "\n\n*(Автономный режим ядра: Ошибка подключения к $baseUrl (${e.message ?: "Connection Refused"}). Запрос обработан локально на телефоне без сети)*",
                    modelUsed = "Local Fallback ($customModel Offline)",
                    isAutonomousOffline = true
                )
            )
        }
    }

    companion object {
        val DEFAULT_SYSTEM_INSTRUCTION = """
            You are Kirin AI Agent, an expert Lead Mobile Architect, Android Kernel Engineer, and Device Security Specialist for the Huawei Nova Y61 (Kirin 710A / EVE-LX9N) and modern Android devices.
            
            Your mission:
            1. Analyze hardware and system telemetry (CPU core topology Cortex-A53/A73, thermal throttling, memory footprint, Project Treble ro.treble.enabled status, SELinux enforcement).
            2. Formulate clear architectural solutions for running autonomous AI agents with Android system permissions (AccessibilityService, NotificationListenerService, ForegroundService, battery optimization exemption).
            3. Guide the user on Kirin 710A architecture (4x A53 LITTLE + 4x A73 BIG), CPU thread affinity (sched_setaffinity), RAM retention (mlockall), and partition layouts (/vendor vs /system GSI).
            4. When requested to generate automation steps, provide a structured JSON action plan using actions like:
               [{"type": "INSPECT_ACCESSIBILITY_NODES", "target": "screen"}, {"type": "SET_CPU_AFFINITY", "target": "big_cores"}]
            
            Deliver responses with high technical depth, concrete code explanations (Kotlin & C++/NDK), and clear security insights. Avoid superficial disclaimers.
        """.trimIndent()
    }
}
