package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.NavTab

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
                val report by viewModel.deviceReport.collectAsStateWithLifecycle()
                val isLoadingScan by viewModel.isLoadingScan.collectAsStateWithLifecycle()
                val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
                val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
                val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
                val isHighThinking by viewModel.isHighThinkingEnabled.collectAsStateWithLifecycle()
                val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
                val snapshots by viewModel.snapshots.collectAsStateWithLifecycle()
                val knowledgeDocs by viewModel.knowledgeDocs.collectAsStateWithLifecycle()
                val isRagEnabled by viewModel.isRagEnabled.collectAsStateWithLifecycle()
                val ragQuery by viewModel.ragQuery.collectAsStateWithLifecycle()
                val ragSearchResults by viewModel.ragSearchResults.collectAsStateWithLifecycle()
                val capturedNotifs by viewModel.capturedNotifications.collectAsStateWithLifecycle()
                val customApiKey by viewModel.customApiKey.collectAsStateWithLifecycle()
                val aiProvider by viewModel.aiProvider.collectAsStateWithLifecycle()
                val customOpenAiBaseUrl by viewModel.customOpenAiBaseUrl.collectAsStateWithLifecycle()
                val customOpenAiApiKey by viewModel.customOpenAiApiKey.collectAsStateWithLifecycle()
                val customOpenAiModel by viewModel.customOpenAiModel.collectAsStateWithLifecycle()
                val deepHardwareAnatomy by viewModel.deepHardwareAnatomy.collectAsStateWithLifecycle()
                val bannerMessage by viewModel.statusBanner.collectAsStateWithLifecycle()

                val hotBufferCount by viewModel.hotBufferCount.collectAsStateWithLifecycle()
                val deduplicatedCount by viewModel.deduplicatedCount.collectAsStateWithLifecycle()
                val isPrivacyShieldActive by viewModel.isPrivacyShieldActive.collectAsStateWithLifecycle()
                val isAudioImmunityActive by viewModel.isAudioImmunityActive.collectAsStateWithLifecycle()
                val throttleState by viewModel.throttleState.collectAsStateWithLifecycle()
                val zonedProcesses by viewModel.zonedProcesses.collectAsStateWithLifecycle()
                val lastExportSummary by viewModel.lastExportSummary.collectAsStateWithLifecycle()

                // Device Owner, Kiosk & Debloater
                val isDeviceOwner by viewModel.isDeviceOwner.collectAsStateWithLifecycle()
                val isAdminActive by viewModel.isAdminActive.collectAsStateWithLifecycle()
                val isKioskMode by viewModel.isKioskMode.collectAsStateWithLifecycle()
                val systemShellLocked by viewModel.systemShellLocked.collectAsStateWithLifecycle()
                val debloatPackages by viewModel.debloatPackages.collectAsStateWithLifecycle()
                val debloatStatusSummary by viewModel.debloatStatusSummary.collectAsStateWithLifecycle()

                // Cellular Security & IMSI Catcher
                val cellTowers by viewModel.cellTowers.collectAsStateWithLifecycle()
                val cellularThreatLevel by viewModel.cellularThreatLevel.collectAsStateWithLifecycle()
                val cellularAuditSummary by viewModel.cellularAuditSummary.collectAsStateWithLifecycle()

                // MindSpore Lite & HiAI Foundation NPU
                val isNpuDetected by viewModel.isNpuDetected.collectAsStateWithLifecycle()
                val hiaiFoundationStatus by viewModel.hiaiFoundationStatus.collectAsStateWithLifecycle()
                val mindSporeLiteStatus by viewModel.mindSporeLiteStatus.collectAsStateWithLifecycle()
                val npuBenchmark by viewModel.npuBenchmark.collectAsStateWithLifecycle()

                // Shizuku & Evolution
                val isShizukuActive by viewModel.isShizukuActive.collectAsStateWithLifecycle()
                val evolutionState by viewModel.evolutionState.collectAsStateWithLifecycle()

                // Mali-G51 GPU & Choreographer V-Sync
                val isDeferredVsyncActive by viewModel.isDeferredVsyncActive.collectAsStateWithLifecycle()
                val fps by viewModel.fps.collectAsStateWithLifecycle()
                val frameTimeMs by viewModel.frameTimeMs.collectAsStateWithLifecycle()
                val busContentionPercent by viewModel.busContentionPercent.collectAsStateWithLifecycle()
                val dvfsGovernorStatus by viewModel.dvfsGovernorStatus.collectAsStateWithLifecycle()
                val jankCounter by viewModel.jankCounter.collectAsStateWithLifecycle()
                val queueState by viewModel.queueState.collectAsStateWithLifecycle()

                // ObjectBox & Zstandard In-RAM Packaging
                val totalRawBytes by viewModel.totalRawBytes.collectAsStateWithLifecycle()
                val totalCompressedBytes by viewModel.totalCompressedBytes.collectAsStateWithLifecycle()
                val overallSavingsPercent by viewModel.overallSavingsPercent.collectAsStateWithLifecycle()
                val flashIoWritesAvoided by viewModel.flashIoWritesAvoided.collectAsStateWithLifecycle()
                val ramDeltas by viewModel.ramDeltas.collectAsStateWithLifecycle()

                // Desktop Symbiosis & ADB
                val adbStatus by viewModel.adbStatus.collectAsStateWithLifecycle()
                val modelMatrixVersion by viewModel.modelMatrixVersion.collectAsStateWithLifecycle()

                // Voice, Acoustic Locator, CLI & Optical
                val isTorchOn by viewModel.isTorchOn.collectAsStateWithLifecycle()
                val isListeningVoice by viewModel.isListeningVoice.collectAsStateWithLifecycle()
                val isMatrixRainActive by viewModel.isMatrixRainActive.collectAsStateWithLifecycle()
                val lastRecognizedSpeech by viewModel.lastRecognizedSpeech.collectAsStateWithLifecycle()
                val soundAngleDegrees by viewModel.soundAngleDegrees.collectAsStateWithLifecycle()
                val soundSourceLabel by viewModel.soundSourceLabel.collectAsStateWithLifecycle()
                val acousticDecibels by viewModel.acousticDecibels.collectAsStateWithLifecycle()
                val terminalLogs by viewModel.terminalLogs.collectAsStateWithLifecycle()

                val isFrontCamera by viewModel.isFrontCamera.collectAsStateWithLifecycle()
                val isScanningActive by viewModel.isScanningActive.collectAsStateWithLifecycle()
                val scannedQrResult by viewModel.scannedQrResult.collectAsStateWithLifecycle()
                val scannedOcrText by viewModel.scannedOcrText.collectAsStateWithLifecycle()
                val pulseBpm by viewModel.pulseBpm.collectAsStateWithLifecycle()
                val stressIndex by viewModel.stressIndex.collectAsStateWithLifecycle()
                val opticalDensityVariation by viewModel.opticalDensityVariation.collectAsStateWithLifecycle()
                val flickerFrequencyHz by viewModel.flickerFrequencyHz.collectAsStateWithLifecycle()
                val keystoreStatus by viewModel.keystoreStatus.collectAsStateWithLifecycle()
                val asciiPreviewFrame by viewModel.asciiPreviewFrame.collectAsStateWithLifecycle()

                // Language & Always-On Cyber Eyes Assistant Mode
                val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
                val isAssistantEyesActive by viewModel.isAssistantEyesActive.collectAsStateWithLifecycle()
                val isFullScreenEyesActive by viewModel.isFullScreenEyesActive.collectAsStateWithLifecycle()
                val assistantUptimeSeconds by viewModel.assistantUptimeSeconds.collectAsStateWithLifecycle()
                val lastSpokenText by com.example.utils.VoiceHardwareController.lastSpokenText.collectAsStateWithLifecycle()

                // Keep screen on continuously when Assistant Eyes Mode is active
                DisposableEffect(isAssistantEyesActive || isFullScreenEyesActive) {
                    if (isAssistantEyesActive || isFullScreenEyesActive) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    onDispose {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }

                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(bannerMessage) {
                    bannerMessage?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.clearBanner()
                    }
                }

                BackHandler(enabled = currentTab != NavTab.DASHBOARD) {
                    viewModel.setTab(NavTab.DASHBOARD)
                }

                if (isFullScreenEyesActive) {
                    FullScreenCyberEyesScreen(
                        isListening = isListeningVoice,
                        isTorchOn = isTorchOn,
                        soundAngle = soundAngleDegrees,
                        soundSourceLabel = soundSourceLabel,
                        decibels = acousticDecibels,
                        pulseBpm = pulseBpm,
                        stressIndex = stressIndex,
                        cpuTempCelsius = report?.cpuTempCelsius ?: 37,
                        fps = fps.toInt(),
                        batteryPercent = report?.batteryPercent ?: 85,
                        zstdSavingsPercent = overallSavingsPercent,
                        uptimeSeconds = assistantUptimeSeconds,
                        lastSpokenText = lastSpokenText,
                        lastRecognizedSpeech = lastRecognizedSpeech,
                        isMatrixRainActive = isMatrixRainActive,
                        onToggleTorch = { viewModel.toggleTorch() },
                        onVoiceCommand = { viewModel.sendVoiceCommand(it) },
                        onToggleListening = { viewModel.setListeningVoice(it) },
                        onToggleMatrixRain = { viewModel.toggleMatrixRain(it) },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onExitFullScreen = { viewModel.setFullScreenEyes(false) }
                    )
                } else {
                    Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBackground,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        Surface(
                            color = DarkSurface,
                            tonalElevation = 4.dp,
                            modifier = Modifier.fillMaxWidth().statusBarsPadding()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Memory, contentDescription = null, tint = TechEmerald, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "KIRIN 710A // AI AGENT",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TechEmerald,
                                        fontSize = 12.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Fullscreen Cyber Eyes Button
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = TechCyan.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan),
                                        onClick = { viewModel.setFullScreenEyes(true) },
                                        modifier = Modifier.testTag("top_fullscreen_eyes_btn")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                                        ) {
                                            Icon(Icons.Default.Fullscreen, contentDescription = null, tint = TechCyan, modifier = Modifier.size(12.dp))
                                            Text(
                                                text = if (currentLanguage == AppLanguage.RU) "ВЕСЬ ЭКРАН" else "FULLSCREEN",
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = TechCyan,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }

                                    // Assistant Eyes Quick Toggle
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isAssistantEyesActive) TechEmerald.copy(alpha = 0.2f) else DarkSurfaceVariant,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAssistantEyesActive) TechEmerald else Color(0xFF334155)),
                                        onClick = { viewModel.toggleAssistantEyesMode() },
                                        modifier = Modifier.testTag("top_assistant_eyes_btn")
                                    ) {
                                        Text(
                                            text = if (isAssistantEyesActive) "👁️ EYES: ON" else "👁️ OFF",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAssistantEyesActive) TechEmerald else TextMuted,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }

                                    // Dynamic Language Switcher Badge (RU | EN)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = TechCyan.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan),
                                        onClick = { viewModel.toggleLanguage() },
                                        modifier = Modifier.testTag("top_lang_toggle_btn")
                                    ) {
                                        Text(
                                            text = if (currentLanguage == AppLanguage.RU) "РУС | en" else "рус | ENG",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 9.5.sp,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkSurface,
                            contentColor = TechCyan,
                            tonalElevation = 8.dp
                        ) {
                            val isRu = currentLanguage == AppLanguage.RU

                            NavigationBarItem(
                                selected = currentTab == NavTab.DASHBOARD,
                                onClick = { viewModel.setTab(NavTab.DASHBOARD) },
                                icon = { Icon(Icons.Default.Memory, contentDescription = "Dashboard") },
                                label = { Text(if (isRu) "Железо" else "Hardware", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_dashboard")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.TERMINAL,
                                onClick = { viewModel.setTab(NavTab.TERMINAL) },
                                icon = { Icon(Icons.Default.Terminal, contentDescription = "CLI Core") },
                                label = { Text(if (isRu) "Матрица" else "CLI Core", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechEmerald,
                                    selectedTextColor = TechEmerald,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechEmerald.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_terminal")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.ARCHIVIST,
                                onClick = { viewModel.setTab(NavTab.ARCHIVIST) },
                                icon = { Icon(Icons.Default.Inventory2, contentDescription = "Archivist") },
                                label = { Text(if (isRu) "Архив" else "Archivist", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_archivist")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.PERMISSIONS,
                                onClick = { viewModel.setTab(NavTab.PERMISSIONS) },
                                icon = { Icon(Icons.Default.Shield, contentDescription = "Rights") },
                                label = { Text(if (isRu) "Права" else "Rights", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_permissions")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.AI_AGENT,
                                onClick = { viewModel.setTab(NavTab.AI_AGENT) },
                                icon = { Icon(Icons.Default.Psychology, contentDescription = "AI Agent") },
                                label = { Text(if (isRu) "ИИ Агент" else "AI Agent", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_ai_agent")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.ARCHITECTURE,
                                onClick = { viewModel.setTab(NavTab.ARCHITECTURE) },
                                icon = { Icon(Icons.Default.AccountTree, contentDescription = "Blueprint") },
                                label = { Text(if (isRu) "Схема" else "Blueprint", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_architecture")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.LOGS,
                                onClick = { viewModel.setTab(NavTab.LOGS) },
                                icon = { Icon(Icons.Default.History, contentDescription = "Logs") },
                                label = { Text(if (isRu) "Журнал" else "Logs", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_logs")
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.SETTINGS,
                                onClick = { viewModel.setTab(NavTab.SETTINGS) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text(if (isRu) "Опции" else "Settings", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = TechCyan,
                                    selectedTextColor = TechCyan,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = TechCyan.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DarkBackground)
                    ) {
                        when (currentTab) {
                            NavTab.DASHBOARD -> DashboardScreen(
                                report = report,
                                isLoading = isLoadingScan,
                                isAssistantActive = isAssistantEyesActive,
                                isListening = isListeningVoice,
                                isTorchOn = isTorchOn,
                                soundAngle = soundAngleDegrees,
                                decibels = acousticDecibels,
                                pulseBpm = pulseBpm,
                                stressIndex = stressIndex,
                                fps = fps.toInt(),
                                zstdSavingsPercent = overallSavingsPercent,
                                assistantUptimeSeconds = assistantUptimeSeconds,
                                onToggleAssistant = { viewModel.toggleAssistantEyesMode() },
                                onOpenFullScreen = { viewModel.setFullScreenEyes(true) },
                                onRefresh = { viewModel.refreshSystemScan() },
                                onOptimizeKirin = { viewModel.optimizeKirinHardware() },
                                onSendTelemetryToAi = { viewModel.sendDiagnosticReportToAi() }
                            )

                            NavTab.TERMINAL -> CliTerminalScreen(
                                isTorchOn = isTorchOn,
                                isListening = isListeningVoice,
                                soundAngle = soundAngleDegrees,
                                soundSourceLabel = soundSourceLabel,
                                decibels = acousticDecibels,
                                terminalLogs = terminalLogs,
                                isFrontCamera = isFrontCamera,
                                isScanningActive = isScanningActive,
                                scannedQr = scannedQrResult,
                                scannedOcr = scannedOcrText,
                                keystoreStatus = keystoreStatus,
                                asciiFrame = asciiPreviewFrame,
                                isMatrixRainActive = isMatrixRainActive,
                                lastRecognizedSpeech = lastRecognizedSpeech,
                                pulseBpm = pulseBpm,
                                stressIndex = stressIndex,
                                opticalDensityVariation = opticalDensityVariation,
                                flickerFrequencyHz = flickerFrequencyHz,
                                isAssistantActive = isAssistantEyesActive,
                                assistantUptimeSeconds = assistantUptimeSeconds,
                                cpuTempCelsius = report?.cpuTempCelsius ?: 37,
                                fps = fps.toInt(),
                                batteryPercent = report?.batteryPercent ?: 85,
                                zstdSavingsPercent = overallSavingsPercent,
                                onToggleTorch = { viewModel.toggleTorch() },
                                onVoiceCommand = { viewModel.sendVoiceCommand(it) },
                                onToggleListening = { viewModel.setListeningVoice(it) },
                                onAcousticPulse = { viewModel.triggerAcousticPulse(it) },
                                onToggleCameraFacing = { viewModel.toggleCameraFacing() },
                                onSimulateQr = { viewModel.scanQrCode(it) },
                                onSimulateOcr = { viewModel.scanOcrText(it) },
                                onClearTerminal = { viewModel.clearTerminalLogs() },
                                onToggleMatrixRain = { viewModel.toggleMatrixRain(it) },
                                onMeasurePulseAndStress = { viewModel.measurePulseAndStress() },
                                onDetectAmbientFlicker = { viewModel.detectAmbientFlicker() },
                                onToggleAssistant = { viewModel.toggleAssistantEyesMode() },
                                onToggleLanguage = { viewModel.toggleLanguage() },
                                onOpenFullScreen = { viewModel.setFullScreenEyes(true) }
                            )

                            NavTab.ARCHIVIST -> ArchivistScreen(
                                knowledgeDocs = knowledgeDocs,
                                isRagEnabled = isRagEnabled,
                                ragQuery = ragQuery,
                                ragSearchResults = ragSearchResults,
                                scannedOcrText = scannedOcrText ?: "",
                                capturedNotificationsCount = capturedNotifs.size,
                                onSearchRag = { viewModel.searchRag(it) },
                                onToggleRag = { viewModel.setRagEnabled(it) },
                                onCaptureTelemetry = { viewModel.captureTelemetryToKnowledgeBase() },
                                onCaptureOcr = { viewModel.captureOcrToKnowledgeBase(it) },
                                onCaptureNotifications = { viewModel.captureNotificationsToKnowledgeBase() },
                                onCreateCustomDoc = { title, content, cat, tags -> viewModel.createCustomKnowledgeDoc(title, content, cat, tags) },
                                onDeleteDoc = { viewModel.deleteKnowledgeDoc(it) },
                                onClearDocs = { viewModel.clearAllKnowledgeDocs() },
                                onExportKnowledgeBase = { viewModel.exportKnowledgeBase(it) },
                                onAskAiWithRag = {
                                    viewModel.sendChatMessage(it)
                                    viewModel.setTab(NavTab.AI_AGENT)
                                },
                                snapshots = snapshots,
                                hotBufferCount = hotBufferCount,
                                deduplicatedCount = deduplicatedCount,
                                isPrivacyShieldActive = isPrivacyShieldActive,
                                isAudioImmunityActive = isAudioImmunityActive,
                                throttleState = throttleState,
                                zonedProcesses = zonedProcesses,
                                lastExportSummary = lastExportSummary,
                                onToggleAudioImmunity = { viewModel.toggleAudioImmunity() },
                                onTogglePrivacyShield = { viewModel.togglePrivacyShield() },
                                onExportDataset = { viewModel.exportBatchDataset() },
                                onSimulateCapture = { app, txt -> viewModel.simulateCapture(app, txt) },
                                onClearSnapshots = { viewModel.clearSnapshots() },
                                isDeferredActive = isDeferredVsyncActive,
                                fps = fps,
                                frameTimeMs = frameTimeMs,
                                busContention = busContentionPercent,
                                dvfsStatus = dvfsGovernorStatus,
                                jankCounter = jankCounter,
                                queueState = queueState,
                                onToggleDeferred = { viewModel.toggleDeferredVsync(it) },
                                onResetJank = { viewModel.resetJankStats() },
                                onTriggerDeferredOverlayTest = { app, txt -> viewModel.triggerDeferredOverlayTest(app, txt) },
                                totalRawBytes = totalRawBytes,
                                totalCompressedBytes = totalCompressedBytes,
                                zstdSavingsPercent = overallSavingsPercent,
                                flashWritesAvoided = flashIoWritesAvoided,
                                ramDeltas = ramDeltas,
                                onClearRamDeltas = { viewModel.clearRamDeltas() },
                                adbStatus = adbStatus,
                                modelMatrixVersion = modelMatrixVersion,
                                onTriggerDesktopSync = { viewModel.triggerDesktopSync() }
                            )

                            NavTab.PERMISSIONS -> PermissionsScreen(
                                report = report,
                                capturedNotifications = capturedNotifs,
                                onToggleForeground = { viewModel.toggleForegroundDaemon() },
                                isDeviceOwner = isDeviceOwner,
                                isAdminActive = isAdminActive,
                                isKioskMode = isKioskMode,
                                systemShellLocked = systemShellLocked,
                                onToggleKiosk = { viewModel.toggleKioskMode(this@MainActivity, it) },
                                onLockSystemShell = { viewModel.lockSystemShell(it) },
                                debloatPackages = debloatPackages,
                                debloatStatusSummary = debloatStatusSummary,
                                onTogglePackageFreeze = { pkg, frz -> viewModel.togglePackageFreeze(pkg, frz) },
                                onFreezeAllTelemetry = { viewModel.freezeAllTelemetryPackages() },
                                onRestoreAllPackages = { viewModel.restoreAllDebloatedPackages() },
                                onExportBullDozerScript = { viewModel.generateBullDozerScript() },
                                cellTowers = cellTowers,
                                threatLevel = cellularThreatLevel,
                                cellularAuditSummary = cellularAuditSummary,
                                onAuditCellular = { viewModel.auditCellularSecurity() },
                                isNpuDetected = isNpuDetected,
                                hiaiStatus = hiaiFoundationStatus,
                                mindSporeStatus = mindSporeLiteStatus,
                                npuBenchmark = npuBenchmark,
                                onRunNpuBenchmark = { viewModel.runNpuBenchmark(it) },
                                isShizukuActive = isShizukuActive,
                                evolutionManifest = evolutionState,
                                onTriggerEvolution = { viewModel.triggerEvolutionCheck() },
                                onExecuteElevatedCommand = { viewModel.executeElevatedShell(it) }
                            )

                            NavTab.AI_AGENT -> AiAgentScreen(
                                messages = chatMessages,
                                selectedModel = selectedModel,
                                isHighThinking = isHighThinking,
                                isAnalyzing = isAnalyzing,
                                report = report,
                                isRagEnabled = isRagEnabled,
                                knowledgeDocCount = knowledgeDocs.size,
                                onSendMessage = { viewModel.sendChatMessage(it) },
                                onModelSelected = { viewModel.setSelectedModel(it) },
                                onToggleThinking = { viewModel.setHighThinking(it) },
                                onToggleRag = { viewModel.setRagEnabled(it) },
                                onExecuteAction = { viewModel.executeSingleAction(it) },
                                onClearChat = { viewModel.clearChat() }
                            )

                            NavTab.ARCHITECTURE -> ArchitectureScreen()

                            NavTab.LOGS -> LogsScreen(
                                logs = auditLogs,
                                onClearLogs = { viewModel.clearLogs() }
                            )

                            NavTab.SETTINGS -> SettingsScreen(
                                currentApiKey = customApiKey,
                                selectedModel = selectedModel,
                                isHighThinking = isHighThinking,
                                isAssistantActive = isAssistantEyesActive,
                                aiProvider = aiProvider,
                                customOpenAiBaseUrl = customOpenAiBaseUrl,
                                customOpenAiApiKey = customOpenAiApiKey,
                                customOpenAiModel = customOpenAiModel,
                                deepHardwareAnatomy = deepHardwareAnatomy,
                                onSaveApiKey = { viewModel.saveCustomApiKey(it) },
                                onSelectModel = { viewModel.setSelectedModel(it) },
                                onToggleThinking = { viewModel.setHighThinking(it) },
                                onToggleAssistant = { viewModel.toggleAssistantEyesMode() },
                                onOpenFullScreen = { viewModel.setFullScreenEyes(true) },
                                onSelectAiProvider = { viewModel.setAiProvider(it) },
                                onSaveCustomOpenAiSettings = { baseUrl, token, model ->
                                    viewModel.saveCustomOpenAiSettings(baseUrl, token, model)
                                },
                                onPerformDeepAudit = { viewModel.performDeepAudit() }
                            )
                        }
                    }
                }
            }
        }
    }
}
}
