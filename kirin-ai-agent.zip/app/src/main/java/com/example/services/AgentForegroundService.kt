package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.utils.NativeHardwareController
import com.example.utils.SystemPermissionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AgentForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var monitorJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var isAudioImmunityRunning = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForegroundService()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_AUDIO_IMMUNITY -> {
                val enable = intent.getBooleanExtra(EXTRA_AUDIO_IMMUNITY, true)
                if (enable) startSilentAudioImmunity() else stopSilentAudioImmunity()
            }
            else -> {
                startForegroundWithNotification()
                startMonitoringLoop()
                if (isAudioImmunityEnabledGlobally) {
                    startSilentAudioImmunity()
                }
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        SystemPermissionManager.isForegroundServiceRunning = true

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = buildNotification("Monitoring Kirin 710A & Background Agent Daemon", pendingIntent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startMonitoringLoop() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            while (isActive) {
                delay(8000)
                val temp = NativeHardwareController.readCpuTemperature()
                val throttleState = NativeHardwareController.throttleState.value
                val audioTag = if (isAudioImmunityRunning) " • Audio Immunity Active" else ""
                val statusText = "Kirin Temp: $temp°C [${throttleState.label}]$audioTag"

                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                val pendingIntent = PendingIntent.getActivity(
                    this@AgentForegroundService,
                    0,
                    Intent(this@AgentForegroundService, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
                manager?.notify(NOTIFICATION_ID, buildNotification(statusText, pendingIntent))
            }
        }
    }

    /**
     * Silent Audio Track Keep-Alive (EMUI IAware / PowerGenie Immunity):
     * Generates a 0.5s silent PCM buffer played cyclically.
     * In Android/EMUI, active audio output marks the process with top media priority,
     * granting immunity against background SIGKILL termination.
     */
    private fun startSilentAudioImmunity() {
        if (isAudioImmunityRunning) return

        serviceScope.launch(Dispatchers.IO) {
            try {
                val sampleRate = 44100
                val bufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(sampleRate / 2)

                val silentBuffer = ShortArray(bufferSize) { 0 }

                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()

                val format = AudioFormat.Builder()
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .build()

                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack?.play()
                isAudioImmunityRunning = true
                Log.i(TAG, "EMUI Audio Keep-Alive immunity started: Process has audio priority")

                while (isActive && isAudioImmunityRunning) {
                    audioTrack?.write(silentBuffer, 0, silentBuffer.size)
                    delay(500)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Audio immunity initialization: ${e.message}")
            }
        }
    }

    private fun stopSilentAudioImmunity() {
        isAudioImmunityRunning = false
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) { }
        audioTrack = null
        Log.i(TAG, "EMUI Audio Keep-Alive stopped")
    }

    private fun buildNotification(contentText: String, contentIntent: PendingIntent): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Kirin AI Agent Active")
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun stopForegroundService() {
        SystemPermissionManager.isForegroundServiceRunning = false
        stopSilentAudioImmunity()
        monitorJob?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        SystemPermissionManager.isForegroundServiceRunning = false
        stopSilentAudioImmunity()
        monitorJob?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kirin AI Agent Background Daemon",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the AI Agent, hardware metrics, and accessibility services alive."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "KirinForegroundService"
        private const val CHANNEL_ID = "kirin_agent_daemon_channel"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.example.services.START"
        const val ACTION_STOP = "com.example.services.STOP"
        const val ACTION_TOGGLE_AUDIO_IMMUNITY = "com.example.services.TOGGLE_AUDIO"
        const val EXTRA_AUDIO_IMMUNITY = "extra_audio_immunity"

        var isAudioImmunityEnabledGlobally: Boolean = true

        fun start(context: Context) {
            val intent = Intent(context, AgentForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AgentForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun setAudioImmunity(context: Context, enabled: Boolean) {
            isAudioImmunityEnabledGlobally = enabled
            val intent = Intent(context, AgentForegroundService::class.java).apply {
                action = ACTION_TOGGLE_AUDIO_IMMUNITY
                putExtra(EXTRA_AUDIO_IMMUNITY, enabled)
            }
            context.startService(intent)
        }
    }
}
