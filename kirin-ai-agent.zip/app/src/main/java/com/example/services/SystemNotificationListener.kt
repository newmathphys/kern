package com.example.services

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CapturedNotification(
    val id: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postTime: Long
)

class SystemNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isConnected.value = true
        Log.i(TAG, "NotificationListener connected and listening")
    }

    override fun onListenerDisconnected() {
        _isConnected.value = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val pkg = sbn.packageName

        if (title.isBlank() && text.isBlank()) return

        val appLabel = try {
            val pm = packageManager
            val ai = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }

        val captured = CapturedNotification(
            id = "${sbn.id}_${sbn.postTime}",
            packageName = pkg,
            appLabel = appLabel,
            title = title,
            text = text,
            postTime = sbn.postTime
        )

        val currentList = _notificationsFlow.value.toMutableList()
        currentList.add(0, captured)
        if (currentList.size > 50) {
            currentList.removeAt(currentList.lastIndex)
        }
        _notificationsFlow.value = currentList

        // Ingest into Archivist 3-tier memory pipeline
        com.example.utils.ContextSnapshotManager.ingestEvent(
            context = this,
            sourceApp = pkg,
            eventType = "NOTIFICATION",
            content = "[$appLabel] $title: $text"
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }

    companion object {
        private const val TAG = "KirinNotifListener"

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _notificationsFlow = MutableStateFlow<List<CapturedNotification>>(emptyList())
        val notificationsFlow: StateFlow<List<CapturedNotification>> = _notificationsFlow.asStateFlow()

        fun clearHistory() {
            _notificationsFlow.value = emptyList()
        }
    }
}
