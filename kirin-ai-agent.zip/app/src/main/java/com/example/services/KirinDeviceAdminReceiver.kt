package com.example.services

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class KirinDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "Device Admin enabled for Kirin AI Agent")
        _isAdminActive.value = true
        Toast.makeText(context, "Kirin Device Admin: ACTIVE", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Device Admin disabled for Kirin AI Agent")
        _isAdminActive.value = false
        _isDeviceOwner.value = false
        Toast.makeText(context, "Kirin Device Admin: DISABLED", Toast.LENGTH_SHORT).show()
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        Log.i(TAG, "Device Owner provisioning complete")
        _isDeviceOwner.value = true
    }

    override fun onLockTaskModeEntering(context: Context, intent: Intent, pkg: String) {
        super.onLockTaskModeEntering(context, intent, pkg)
        Log.i(TAG, "Entered LockTaskMode (Kiosk) for $pkg")
        _isKioskModeActive.value = true
    }

    override fun onLockTaskModeExiting(context: Context, intent: Intent) {
        super.onLockTaskModeExiting(context, intent)
        Log.i(TAG, "Exited LockTaskMode (Kiosk)")
        _isKioskModeActive.value = false
    }

    companion object {
        private const val TAG = "KirinDeviceAdmin"

        private val _isAdminActive = MutableStateFlow(false)
        val isAdminActive: StateFlow<Boolean> = _isAdminActive.asStateFlow()

        private val _isDeviceOwner = MutableStateFlow(false)
        val isDeviceOwner: StateFlow<Boolean> = _isDeviceOwner.asStateFlow()

        private val _isKioskModeActive = MutableStateFlow(false)
        val isKioskModeActive: StateFlow<Boolean> = _isKioskModeActive.asStateFlow()

        fun updateStatus(isAdmin: Boolean, isOwner: Boolean) {
            _isAdminActive.value = isAdmin
            _isDeviceOwner.value = isOwner
        }
    }
}
