package com.example.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.utils.ContextSnapshotManager
import java.lang.ref.WeakReference

class SystemAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        Log.i(TAG, "Kirin AI SystemAccessibilityService connected and ready")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (ContextSnapshotManager.isPackageSensitive(pkg)) return

        val eventType = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW_CHANGE"
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> "VIEW_SCROLL"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "CONTENT_CHANGE"
            else -> "UI_EVENT"
        }

        val textDump = StringBuilder()
        event.text?.forEach { charSeq ->
            if (!charSeq.isNullOrBlank()) {
                textDump.append(charSeq).append(" ")
            }
        }

        if (textDump.isBlank()) {
            rootInActiveWindow?.let { root ->
                extractVisibleText(root, textDump, 0)
            }
        }

        val content = textDump.toString().trim()
        if (content.length > 5) {
            ContextSnapshotManager.ingestEvent(
                context = this,
                sourceApp = pkg,
                eventType = eventType,
                content = content
            )
        }
    }

    private fun extractVisibleText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 4 || sb.length > 300) return
        node.text?.let { if (it.isNotBlank()) sb.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            extractVisibleText(node.getChild(i), sb, depth + 1)
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Kirin AI SystemAccessibilityService interrupted")
    }

    override fun onDestroy() {
        instanceRef = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "KirinAccessibility"
        private var instanceRef: WeakReference<SystemAccessibilityService>? = null

        val isServiceConnected: Boolean
            get() = instanceRef?.get() != null

        fun executeGlobal(action: Int): Boolean {
            val service = instanceRef?.get() ?: return false
            return service.performGlobalAction(action)
        }

        fun clickNodeByText(text: String): Boolean {
            val service = instanceRef?.get() ?: return false
            val root = service.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(text)
            for (node in nodes) {
                if (node.isClickable) {
                    val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        val clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        if (clicked) return true
                    }
                    parent = parent.parent
                }
            }
            return false
        }

        fun clickNodeById(viewId: String): Boolean {
            val service = instanceRef?.get() ?: return false
            val root = service.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
            for (node in nodes) {
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            return false
        }

        fun emulateTap(x: Float, y: Float, onComplete: ((Boolean) -> Unit)? = null): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
            val service = instanceRef?.get() ?: return false

            val path = Path().apply {
                moveTo(x, y)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            return service.dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    onComplete?.invoke(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    onComplete?.invoke(false)
                }
            }, null)
        }

        fun inspectActiveHierarchy(): String {
            val service = instanceRef?.get() ?: return "Accessibility Service is not active. Please grant permission in System Settings."
            val root = service.rootInActiveWindow ?: return "No active window found or screen is locked."

            val sb = StringBuilder()
            sb.appendLine("Active Window Hierarchy:")
            traverseNode(root, sb, 0)
            return sb.toString()
        }

        private fun traverseNode(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
            val indent = "  ".repeat(depth)
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            val text = node.text?.toString()?.take(40) ?: ""
            val cls = node.className?.toString()?.substringAfterLast('.') ?: "View"
            val id = node.viewIdResourceName?.substringAfterLast('/') ?: ""

            sb.append(indent)
            sb.append("• [$cls]")
            if (id.isNotEmpty()) sb.append(" id: $id")
            if (text.isNotEmpty()) sb.append(" text: \"$text\"")
            sb.append(" bounds: ${bounds.toShortString()}")
            if (node.isClickable) sb.append(" [Clickable]")
            sb.appendLine()

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                traverseNode(child, sb, depth + 1)
            }
        }
    }
}
