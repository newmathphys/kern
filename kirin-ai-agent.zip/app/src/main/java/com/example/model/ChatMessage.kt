package com.example.model

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String, // "user", "assistant", "system"
    val content: String,
    val thinking: String? = null,
    val isThinking: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val modelUsed: String? = null,
    val actionPlan: List<AgentAction>? = null
)
