package com.example.model

data class CpuCoreInfo(
    val id: Int,
    val cluster: String, // "LITTLE (Cortex-A53)" or "BIG (Cortex-A73)"
    val curFreqMhz: Int,
    val maxFreqMhz: Int,
    val isOnline: Boolean,
    val isPinned: Boolean
)

data class DeviceReport(
    val brand: String,
    val model: String,
    val hardware: String,
    val emuiBuild: String,
    val androidRelease: String,
    val securityPatch: String,
    val kernelVersion: String,
    val cpuArch: String,
    val isTrebleEnabled: Boolean,
    val isSelinuxEnforcing: Boolean,
    val cpuTempCelsius: Int,
    val ramTotalMb: Long,
    val ramAvailMb: Long,
    val batteryPercent: Int,
    val isBatteryOptimizationIgnored: Boolean,
    val isAccessibilityEnabled: Boolean,
    val isNotificationListenerEnabled: Boolean,
    val isForegroundServiceRunning: Boolean,
    val affinityPinnedToBigCores: Boolean,
    val memoryLocked: Boolean,
    val partitionLayout: String = "AB (Seamless / ro.build.ab_update)",
    val gpuNpuAccelerator: String = "ARM Mali-G51 MP4 (MNN / Bolt / OpenCL)",
    val cores: List<CpuCoreInfo> = emptyList()
) {
    val ramUsedMb: Long get() = (ramTotalMb - ramAvailMb).coerceAtLeast(0)
    val ramUsagePercent: Int get() = if (ramTotalMb > 0) ((ramUsedMb * 100) / ramTotalMb).toInt() else 0
}
