package com.example.model

enum class ActionType {
    SCAN_SYSTEM,
    SET_CPU_AFFINITY,
    LOCK_MEMORY_PAGES,
    INSPECT_ACCESSIBILITY_NODES,
    EMULATE_CLICK,
    GLOBAL_NAV_ACTION,
    PROCESS_NOTIFICATION,
    OPTIMIZE_EMUI_RETENTION,
    EXPORT_TELEMETRY,
    // Autonomous Hardware & Phone tools
    DEBLOAT_PACKAGE,
    AUDIT_CELLULAR,
    SET_KIOSK_MODE,
    BENCHMARK_NPU,
    TOGGLE_TORCH,
    CAPTURE_KNOWLEDGE,
    TRIGGER_DESKTOP_SYNC,
    RAM_COMPACT_ZSTD,
    MEASURE_PULSE_PPG,
    VOICE_TTS_FEEDBACK
}

data class AgentAction(
    val id: String,
    val type: ActionType,
    val target: String,
    val details: String,
    val status: String = "READY", // READY, EXECUTING, SUCCESS, SIMULATED, FAILED
    val timestamp: Long = System.currentTimeMillis()
)
