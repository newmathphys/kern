package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.utils.LocalizationManager
import kotlinx.coroutines.delay

@Composable
fun CyberEyesComponent(
    isAssistantActive: Boolean,
    isListening: Boolean,
    isTorchOn: Boolean,
    soundAngle: Float,
    decibels: Float,
    pulseBpm: Int,
    stressIndex: String,
    cpuTempCelsius: Int,
    fps: Int,
    batteryPercent: Int,
    zstdSavingsPercent: Float,
    uptimeSeconds: Long,
    onToggleAssistant: () -> Unit,
    onOpenFullScreen: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val lang by LocalizationManager.currentLanguage.collectAsState()

    // Natural periodic blinking loop
    var blinkProgress by remember { mutableStateOf(0f) }
    LaunchedEffect(isAssistantActive) {
        if (!isAssistantActive) return@LaunchedEffect
        while (true) {
            delay((2800..4500).random().toLong())
            // Fast blink close
            blinkProgress = 1f
            delay(120)
            // Open
            blinkProgress = 0f
        }
    }

    val animatedBlink by animateFloatAsState(
        targetValue = blinkProgress,
        animationSpec = tween(durationMillis = 100, easing = FastOutLinearInEasing),
        label = "blinkAnimation"
    )

    // Pulse animation synchronized with live BPM
    val infiniteTransition = rememberInfiniteTransition(label = "cyberEyes")
    val pulseDurationMs = ((60f / pulseBpm.coerceIn(50, 140)) * 1000).toInt()
    val heartPulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartPulse"
    )

    // Gaze offset from sound angle
    val targetGazeX = (soundAngle / 45f).coerceIn(-1f, 1f)
    val animatedGazeX by animateFloatAsState(
        targetValue = targetGazeX,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "gazeX"
    )

    // Format uptime: 00:00:00
    val hours = uptimeSeconds / 3600
    val minutes = (uptimeSeconds % 3600) / 60
    val seconds = uptimeSeconds % 60
    val uptimeString = String.format("%02d:%02d:%02d", hours, minutes, seconds)

    Card(
        modifier = modifier.fillMaxWidth().testTag("cyber_eyes_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF03060A)),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isAssistantActive) Brush.horizontalGradient(listOf(TechEmerald, TechCyan, TechAmber))
            else Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header with Master Toggle Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isAssistantActive) TechEmerald else TextMuted)
                        )
                        Text(
                            text = if (lang.code == "ru") "РЕЖИМ АССИСТЕНТА С ГЛАЗАМИ" else "ALWAYS-ON CYBER EYES ASSISTANT",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isAssistantActive) TechEmerald else TextPrimary,
                            fontSize = 11.5.sp
                        )
                    }
                    Text(
                        text = if (lang.code == "ru") "Работает непрерывно со всеми показателями (Экран не гаснет)" else "Runs continuously with all live telemetry (Screen awake)",
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary,
                        fontSize = 9.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Fullscreen Button
                    OutlinedButton(
                        onClick = onOpenFullScreen,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TechCyan
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan.copy(alpha = 0.6f)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("open_fullscreen_eyes_btn")
                    ) {
                        Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (lang.code == "ru") "ВЕСЬ ЭКРАН" else "FULLSCREEN",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }

                    // Master Toggle Button
                    Button(
                        onClick = onToggleAssistant,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAssistantActive) TechEmerald else DarkSurfaceVariant,
                            contentColor = if (isAssistantActive) Color.Black else TextPrimary
                        ),
                        modifier = Modifier.testTag("toggle_assistant_eyes_btn")
                    ) {
                        Text(
                            text = if (isAssistantActive) {
                                if (lang.code == "ru") "ВКЛ (АКТИВЕН)" else "ON (ACTIVE)"
                            } else {
                                if (lang.code == "ru") "ВЫКЛ" else "OFF"
                            },
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Continuous Uptime & Status Banner
            if (isAssistantActive) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF07121C),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Timer, contentDescription = null, tint = TechCyan, modifier = Modifier.size(14.dp))
                            Text(
                                text = if (lang.code == "ru") "НЕПРЕРЫВНЫЙ МОНИТОРИНГ: $uptimeString" else "CONTINUOUS UPTIME: $uptimeString",
                                fontFamily = FontFamily.Monospace,
                                color = TechCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = TechEmerald.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "WAKELOCK: 100%",
                                fontFamily = FontFamily.Monospace,
                                color = TechEmerald,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Animated Cyber Eyes Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF010204))
                    .border(1.dp, TechEmerald.copy(alpha = if (isAssistantActive) 0.5f else 0.2f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val eyeRadiusX = w * 0.16f
                    val eyeRadiusY = h * 0.32f
                    val leftEyeCenter = Offset(w * 0.32f, h * 0.46f)
                    val rightEyeCenter = Offset(w * 0.68f, h * 0.46f)

                    val eyeCenters = listOf(leftEyeCenter, rightEyeCenter)

                    // Draw both eyes
                    for (center in eyeCenters) {
                        // Sclera / Cyber Eye Outer Shell
                        drawOval(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF0B1726), Color(0xFF03070D)),
                                center = center,
                                radius = eyeRadiusX * 1.3f
                            ),
                            topLeft = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY),
                            size = Size(eyeRadiusX * 2, eyeRadiusY * 2)
                        )

                        // Outer Glowing Cyber Arc
                        drawOval(
                            brush = Brush.sweepGradient(
                                colors = listOf(TechEmerald, TechCyan, TechAmber, TechEmerald),
                                center = center
                            ),
                            topLeft = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY),
                            size = Size(eyeRadiusX * 2, eyeRadiusY * 2),
                            style = Stroke(width = 2.5f)
                        )

                        // Iris with Gaze shift
                        val maxShiftX = eyeRadiusX * 0.35f
                        val gazeShift = animatedGazeX * maxShiftX
                        val irisCenter = Offset(center.x + gazeShift, center.y)
                        val irisRadius = eyeRadiusX * 0.55f * (if (isAssistantActive) heartPulseScale else 1f)

                        // Iris Radial Glow
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = if (isListening) listOf(Color.White, TechCyan, Color(0xFF003B5C))
                                else listOf(Color(0xFFE0FFF4), TechEmerald, Color(0xFF004D36)),
                                center = irisCenter,
                                radius = irisRadius
                            ),
                            center = irisCenter,
                            radius = irisRadius
                        )

                        // Pupil (Dilates when listening or in high cognitive focus)
                        val pupilRadius = if (isListening) irisRadius * 0.52f else irisRadius * 0.35f
                        drawCircle(
                            color = Color(0xFF010408),
                            center = irisCenter,
                            radius = pupilRadius
                        )

                        // Cyber Reticle Glint
                        drawCircle(
                            color = Color.White.copy(alpha = 0.85f),
                            center = Offset(irisCenter.x - pupilRadius * 0.4f, irisCenter.y - pupilRadius * 0.4f),
                            radius = pupilRadius * 0.28f
                        )

                        // Blink Eyelid overlay
                        if (animatedBlink > 0.01f) {
                            val blinkHeight = eyeRadiusY * 2 * animatedBlink
                            drawRect(
                                color = Color(0xFF010204),
                                topLeft = Offset(center.x - eyeRadiusX - 4f, center.y - eyeRadiusY - 2f),
                                size = Size(eyeRadiusX * 2 + 8f, blinkHeight)
                            )
                            // Eyelid neon lash edge
                            drawLine(
                                color = TechEmerald,
                                start = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY + blinkHeight),
                                end = Offset(center.x + eyeRadiusX, center.y - eyeRadiusY + blinkHeight),
                                strokeWidth = 2.5f,
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    // Equalizer mouth wave beneath the eyes
                    val mouthY = h * 0.86f
                    val mouthCenter = w * 0.5f
                    val waveBars = 15
                    val barWidth = 4f
                    val spacing = 7f
                    val startX = mouthCenter - (waveBars * (barWidth + spacing)) / 2f
                    val normDb = ((decibels - 30f) / 50f).coerceIn(0.1f, 1f)

                    for (i in 0 until waveBars) {
                        val barH = (normDb * 18f * (1f - (Math.abs(i - waveBars / 2f) / (waveBars / 2f)) * 0.6f)).coerceAtLeast(3f)
                        val x = startX + i * (barWidth + spacing)
                        drawLine(
                            color = if (isListening) TechCyan else TechEmerald,
                            start = Offset(x, mouthY - barH / 2f),
                            end = Offset(x, mouthY + barH / 2f),
                            strokeWidth = barWidth,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Gaze Label Indicator
                val gazeLabel = when {
                    soundAngle < -15f -> if (lang.code == "ru") "ВЗГЛЯД: ВЛЕВО <-" else "GAZE: LEFT <-"
                    soundAngle > 15f -> if (lang.code == "ru") "ВЗГЛЯД: ВПРАВО ->" else "GAZE: RIGHT ->"
                    else -> if (lang.code == "ru") "ВЗГЛЯД: ВПЕРЕД [ФОКУС]" else "GAZE: CENTER [FOCUSED]"
                }
                Box(modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp)) {
                    Text(
                        text = gazeLabel,
                        fontFamily = FontFamily.Monospace,
                        color = TechCyan.copy(alpha = 0.8f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ALL LIVE INDICATORS GRID (Continuous Telemetry)
            Text(
                text = if (lang.code == "ru") "АКТИВНЫЕ ПОКАЗАТЕЛИ СИСТЕМЫ В РЕАЛЬНОМ ВРЕМЕНИ:" else "ALL LIVE SYSTEM TELEMETRY METRICS:",
                fontFamily = FontFamily.Monospace,
                color = TextMuted,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold
            )

            // Grid of telemetry cards
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TelemetryCard(
                        icon = Icons.Default.Favorite,
                        label = if (lang.code == "ru") "ПУЛЬС (PPG)" else "PULSE (PPG)",
                        value = "$pulseBpm BPM",
                        sub = stressIndex.take(18),
                        color = TechRed,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryCard(
                        icon = Icons.Default.Speed,
                        label = if (lang.code == "ru") "ПРОЦЕССОР" else "CPU SoC",
                        value = "4x A73: 2.0 GHz",
                        sub = "$cpuTempCelsius°C / Kirin 710A",
                        color = TechCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TelemetryCard(
                        icon = Icons.Default.Mic,
                        label = if (lang.code == "ru") "АУДИО TDOA" else "AUDIO TDOA",
                        value = "${decibels.toInt()} dB",
                        sub = if (soundAngle < -15f) "Left Mic" else if (soundAngle > 15f) "Right Mic" else "Center",
                        color = TechAmber,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryCard(
                        icon = Icons.Default.Tv,
                        label = if (lang.code == "ru") "V-SYNC GPU" else "GPU V-SYNC",
                        value = "$fps FPS (Mali-G51)",
                        sub = if (lang.code == "ru") "Очередь: 0 задержек" else "Queue: 0 jank",
                        color = TechEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TelemetryCard(
                        icon = Icons.Default.BatteryChargingFull,
                        label = if (lang.code == "ru") "БАТАРЕЯ" else "BATTERY",
                        value = "$batteryPercent%",
                        sub = if (lang.code == "ru") "DVFS: Balanced" else "DVFS: Balanced",
                        color = TechEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryCard(
                        icon = Icons.Default.Memory,
                        label = if (lang.code == "ru") "RAM ZSTD" else "RAM ZSTD",
                        value = "$zstdSavingsPercent%",
                        sub = if (lang.code == "ru") "0 записей во флэш" else "0 Flash I/O writes",
                        color = TechPurple,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    sub: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF060B12),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
                Text(text = label, fontFamily = FontFamily.Monospace, color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
            }
            Text(text = value, fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(text = sub, fontFamily = FontFamily.Monospace, color = TextMuted, fontSize = 8.sp)
        }
    }
}
