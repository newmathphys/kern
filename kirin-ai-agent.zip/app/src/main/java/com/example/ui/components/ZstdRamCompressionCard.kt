package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.utils.CompressedDelta

@Composable
fun ZstdRamCompressionCard(
    totalRawBytes: Long,
    totalCompressedBytes: Long,
    savingsPercent: Float,
    flashWritesAvoided: Int,
    deltas: List<CompressedDelta>,
    onClearRamDeltas: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("zstd_ram_compression_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Archive,
                        contentDescription = null,
                        tint = TechAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "ObjectBox & Zstandard • RAM Delta Packing",
                            style = MaterialTheme.typography.titleMedium,
                            color = TechAmber
                        )
                        Text(
                            text = "Zero Flash Memory Wear • In-Memory Dictionary Compression",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = onClearRamDeltas,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Clear RAM Deltas", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
            }

            HorizontalDivider(color = DarkSurfaceVariant)

            // 3 Stat Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "RAM Ratio", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                        Text(text = "$savingsPercent%", style = MaterialTheme.typography.titleMedium, color = TechEmerald)
                        Text(text = "Volume Saved", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "In-RAM Footprint", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                        Text(text = "${totalCompressedBytes / 1024} KB", style = MaterialTheme.typography.titleMedium, color = TechCyan)
                        Text(text = "Raw: ${totalRawBytes / 1024} KB", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "Flash Protection", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                        Text(text = "$flashWritesAvoided%", style = MaterialTheme.typography.titleMedium, color = TechPurple)
                        Text(text = "0 Wear on UFS", style = MaterialTheme.typography.bodySmall, color = TechPurple, fontSize = 9.sp)
                    }
                }
            }

            // Recent In-RAM Compressed Deltas
            if (deltas.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Active In-RAM Deltas (${deltas.size})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    deltas.take(3).forEach { delta ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = DarkSurface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = delta.sourceApp.replace("org.", "").replace("com.", ""),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TechAmber,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "${delta.originalSize} B raw → ${delta.compressedSize} B Zstd",
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = TechEmerald.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "-${delta.compressionRatio}%",
                                        color = TechEmerald,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
