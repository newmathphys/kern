package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AgentDarkColorScheme = darkColorScheme(
    primary = TechCyan,
    onPrimary = DarkBackground,
    primaryContainer = TechCyanDim,
    onPrimaryContainer = TextPrimary,
    secondary = TechAmber,
    onSecondary = DarkBackground,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = TechAmber,
    tertiary = TechPurple,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceVariant,
    error = TechRed,
    onError = DarkBackground
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AgentDarkColorScheme,
        typography = Typography,
        content = content
    )
}
