package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeviceReport
import com.example.ui.components.CpuCoreTopologyCard
import com.example.ui.components.CyberEyesComponent
import com.example.ui.theme.*
import com.example.utils.LocalizationManager

@Composable
fun DashboardScreen(
    report: DeviceReport?,
    isLoading: Boolean,
    isAssistantActive: Boolean = true,
    isListening: Boolean = false,
    isTorchOn: Boolean = false,
    soundAngle: Float = 0f,
    decibels: Float = 38.5f,
    pulseBpm: Int = 72,
    stressIndex: String = "Normal (62/100)",
    fps: Int = 60,
    zstdSavingsPercent: Float = 48.5f,
    assistantUptimeSeconds: Long = 0L,
    onToggleAssistant: () -> Unit = {},
    onOpenFullScreen: () -> Unit = {},
    onRefresh: () -> Unit,
    onOptimizeKirin: () -> Unit,
    onSendTelemetryToAi: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang.code == "ru"

    if (report == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = TechCyan)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        // 1. ALWAYS-ON CYBER EYES ASSISTANT COMPONENT
        item {
            CyberEyesComponent(
                isAssistantActive = isAssistantActive,
                isListening = isListening,
                isTorchOn = isTorchOn,
                soundAngle = soundAngle,
                decibels = decibels,
                pulseBpm = pulseBpm,
                stressIndex = stressIndex,
                cpuTempCelsius = report.cpuTempCelsius,
                fps = fps,
                batteryPercent = report.batteryPercent,
                zstdSavingsPercent = zstdSavingsPercent,
                uptimeSeconds = assistantUptimeSeconds,
                onToggleAssistant = onToggleAssistant,
                onOpenFullScreen = onOpenFullScreen
            )
        }

        // 2. Hero Hardware Spec Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("device_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${report.brand.uppercase()} ${report.model}",
                                style = MaterialTheme.typography.titleLarge,
                                color = TechCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "SoC: ${report.hardware} • Kernel: ${report.kernelVersion}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(
                            onClick = onRefresh,
                            enabled = !isLoading,
                            modifier = Modifier.testTag("refresh_dashboard_btn")
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TechCyan, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TechCyan)
                            }
                        }
                    }

                    HorizontalDivider(color = DarkSurfaceVariant)

                    // Quick Spec Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecPill(label = if (isRu) "Сборка / EMUI" else "EMUI / Build", value = report.emuiBuild.take(14))
                        SpecPill(label = "Android", value = report.androidRelease)
                        SpecPill(label = if (isRu) "Патч безоп." else "Security", value = report.securityPatch)
                        SpecPill(label = "Treble", value = if (report.isTrebleEnabled) "Enabled" else "No", isHighlight = report.isTrebleEnabled)
                    }
                }
            }
        }

        // 3. Telemetry Metrics Row (Thermal + RAM)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = if (isRu) "Температура SoC" else "SoC Thermal",
                    value = "${report.cpuTempCelsius}°C",
                    subtext = if (report.cpuTempCelsius > 48) (if (isRu) "Нагрев чипа" else "High Thermal") else (if (isRu) "Штатный режим" else "Normal State"),
                    icon = Icons.Default.Thermostat,
                    tint = if (report.cpuTempCelsius > 48) TechRed else TechAmber,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = if (isRu) "ОЗУ (RAM)" else "RAM Usage",
                    value = "${report.ramUsedMb} / ${report.ramTotalMb} MB",
                    subtext = "${report.ramUsagePercent}% " + (if (isRu) "занято" else "in use"),
                    icon = Icons.Default.SdCard,
                    tint = TechEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 4. CPU Core Topology Visualizer
        item {
            CpuCoreTopologyCard(
                report = report,
                onOptimizeClicked = onOptimizeKirin
            )
        }

        // 5. Mali-G51 GPU & V-Sync Arbiter Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_gpu_arbiter_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(14.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideogameAsset,
                            contentDescription = null,
                            tint = TechEmerald,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = if (isRu) "Mali-G51 MP4 • V-Sync Арбитр" else "Mali-G51 MP4 • V-Sync Arbiter",
                                style = MaterialTheme.typography.titleSmall,
                                color = TechEmerald
                            )
                            Text(
                                text = if (isRu) "Очередь отложенного рендера (60 FPS без лагов)" else "Deferred Render Queue • Inter-Frame Soft Injection (60 FPS)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = TechEmerald.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (isRu) "60 FPS • 0 лагов" else "60 FPS • 0 Jank",
                            color = TechEmerald,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }

        // 6. Quick AI Dispatch Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isRu) "ИИ-анализ безопасности и эксплойтов" else "AI System Security & Exploit Analysis",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isRu) "Отправить телеметрию Kirin 710A в нейросеть Gemini 3.1 Pro." else "Send live Kirin 710A telemetry and partition state to Gemini 3.1 Pro (High Thinking).",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onSendTelemetryToAi,
                        colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("analyze_telemetry_btn")
                    ) {
                        Text(if (isRu) "Анализ" else "Analyze", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SpecPill(label: String, value: String, isHighlight: Boolean = false) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = if (isHighlight) TechEmerald else TextPrimary,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    tint: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                Text(text = title, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            }
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Text(text = subtext, style = MaterialTheme.typography.bodySmall, color = tint, fontSize = 11.sp)
        }
    }
}
