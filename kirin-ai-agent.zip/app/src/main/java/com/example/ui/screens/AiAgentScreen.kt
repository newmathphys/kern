package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgentAction
import com.example.model.ChatMessage
import com.example.model.DeviceReport
import com.example.ui.components.ChatBubble
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.utils.LocalizationManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAgentScreen(
    messages: List<ChatMessage>,
    selectedModel: String,
    isHighThinking: Boolean,
    isAnalyzing: Boolean,
    report: DeviceReport?,
    isRagEnabled: Boolean = true,
    knowledgeDocCount: Int = 0,
    onSendMessage: (String) -> Unit,
    onModelSelected: (String) -> Unit,
    onToggleThinking: (Boolean) -> Unit,
    onToggleRag: (Boolean) -> Unit = {},
    onExecuteAction: (AgentAction) -> Unit,
    onClearChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var isModelMenuExpanded by remember { mutableStateOf(false) }
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    val modelsList = listOf(
        "gemini-3.1-pro-preview" to "Gemini 3.1 Pro (High Thinking & Complex Reasoning)",
        "gemini-3.5-flash" to "Gemini 3.5 Flash (Fast Execution & General Tasks)",
        "gemini-3.1-flash-lite-preview" to "Gemini 3.1 Flash Lite (Ultra Low Latency)"
    )

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Model & Thinking Control Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkCard,
            tonalElevation = 2.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Model Dropdown
                    Box {
                        OutlinedButton(
                            onClick = { isModelMenuExpanded = true },
                            modifier = Modifier.testTag("model_selector_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TechCyan),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanDim)
                        ) {
                            Icon(Icons.Default.Memory, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedModel.contains("pro")) "Gemini 3.1 Pro" else "Gemini 3.5 Flash",
                                fontSize = 12.sp
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = isModelMenuExpanded,
                            onDismissRequest = { isModelMenuExpanded = false },
                            modifier = Modifier.background(DarkCard)
                        ) {
                            modelsList.forEach { (modelId, label) ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(text = modelId, color = if (modelId == selectedModel) TechCyan else TextPrimary)
                                            Text(text = label, color = TextSecondary, fontSize = 11.sp)
                                        }
                                    },
                                    onClick = {
                                        onModelSelected(modelId)
                                        isModelMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // High Thinking Toggle / Status
                    if (selectedModel.contains("pro")) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = TechPurple.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TechPurple.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Psychology, contentDescription = null, tint = TechPurple, modifier = Modifier.size(14.dp))
                                Text(text = "High Thinking Active", style = MaterialTheme.typography.labelSmall, color = TechPurple, fontSize = 11.sp)
                            }
                        }
                    }

                    // RAG Knowledge Base Toggle & Status
                    Surface(
                        onClick = { onToggleRag(!isRagEnabled) },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isRagEnabled) TechEmerald.copy(alpha = 0.2f) else DarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isRagEnabled) TechEmerald.copy(alpha = 0.6f) else TextMuted)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = if (isRagEnabled) TechEmerald else TextMuted, modifier = Modifier.size(13.dp))
                            Text(
                                text = if (isRagEnabled) (if (isRu) "RAG: Вкл ($knowledgeDocCount)" else "RAG: ON ($knowledgeDocCount)") else "RAG: OFF",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isRagEnabled) TechEmerald else TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(onClick = onClearChat, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Chat", tint = TextMuted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Quick Prompt Suggestions Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PromptChip(label = if (isRu) "🧠 RAG: База Знаний Nova Y61" else "🧠 RAG: Nova Y61 Knowledge", isPrimary = true) {
                onSendMessage(if (isRu) "Сделай подробный отчет на основе базы знаний о характеристиках телефона, температуре процессора, батарее и фоновых службах."
                else "Provide an in-depth report based on the local knowledge base regarding device specs, CPU thermal headroom, battery, and background retention.")
            }
            PromptChip(label = if (isRu) "🔍 RAG: Анализ Уведомлений" else "🔍 RAG: Notifications") {
                onSendMessage(if (isRu) "Проанализируй задокументированные в базе знаний уведомления и сделай краткую выжимку."
                else "Analyze the documented notifications from the local knowledge base and summarize key messages.")
            }
            PromptChip(label = "Audit Kirin 710A & Treble") {
                onSendMessage("Conduct an in-depth security and hardware audit of this Huawei Nova Y61 with Kirin 710A SoC. Assess Treble compatibility and bootloader partition architecture.")
            }
            PromptChip(label = "Mali-G51 V-Sync Queue") {
                onSendMessage("Explain how the Deferred Render Queue eliminates Mali-G51 shared memory bus collisions with Kirin 710A CPU using Choreographer V-Sync inter-frame soft injection for 60 FPS in Telegram.")
            }
            PromptChip(label = "ObjectBox Zstd RAM Packing") {
                onSendMessage("Detail how Zstandard dictionary compression packs UI deltas in RAM to achieve 78% compression with zero flash wear on mobile storage.")
            }
            PromptChip(label = "PC ADB Symbiosis") {
                onSendMessage("Explain the symbiosis architecture between Android Studio App Inspection, ADB Port 5037, and the local command matrix for hot updates.")
            }
            PromptChip(label = "Bypass EMUI PowerGenie") {
                onSendMessage("Explain how to bypass EMUI 12 PowerGenie killer using foreground service, battery optimization exemptions, and mlockall memory locking.")
            }
            PromptChip(label = "Plan Accessibility Script") {
                onSendMessage("Generate a JSON action plan using SystemAccessibilityService to navigate to Settings and inspect current window nodes.")
            }
            PromptChip(label = "C++ NDK CPU Affinity Code") {
                onSendMessage("Show the exact C++ JNI code using sched_setaffinity to bind threads to Kirin 710A Cortex-A73 Big-cores 4-7.")
            }
            if (report != null) {
                PromptChip(label = "Inject Live Telemetry", isPrimary = true) {
                    val quickData = "Brand: ${report.brand}, Model: ${report.model}, Chipset: ${report.hardware}, Temp: ${report.cpuTempCelsius}°C, Treble: ${report.isTrebleEnabled}, Big-Core Pinned: ${report.affinityPinnedToBigCores}"
                    onSendMessage("Here is my device status:\n$quickData\nAnalyze CPU thermal performance and suggest optimal background configuration.")
                }
            }
        }

        // Chat Message Stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatBubble(
                    message = msg,
                    onExecuteAction = onExecuteAction
                )
            }

            if (isAnalyzing) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = TechCyan,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = if (isHighThinking && selectedModel.contains("pro")) {
                                if (isRu) "Gemini 3.1 Pro думает в режиме глубокого рассуждения..." else "Gemini 3.1 Pro is thinking with High Reasoning depth..."
                            } else {
                                if (isRu) "Gemini выполняет анализ..." else "Gemini is analyzing..."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TechCyan
                        )
                    }
                }
            }
        }

        // Bottom Input Row
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkCard,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = if (isRu) "Спросите о Kirin 710A, правах, ИИ-агенте..." else "Ask about Kirin 710A, system rights, AI agent...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_input_field"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TechCyan,
                        unfocusedBorderColor = DarkSurfaceVariant,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    maxLines = 4
                )

                IconButton(
                    onClick = {
                        val text = inputText.trim()
                        if (text.isNotEmpty() && !isAnalyzing) {
                            inputText = ""
                            onSendMessage(text)
                            coroutineScope.launch {
                                listState.animateScrollToItem(messages.size)
                            }
                        }
                    },
                    enabled = inputText.isNotBlank() && !isAnalyzing,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (inputText.isNotBlank() && !isAnalyzing) TechCyan else DarkSurfaceVariant)
                        .testTag("send_message_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = if (inputText.isNotBlank() && !isAnalyzing) DarkBackground else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PromptChip(label: String, isPrimary: Boolean = false, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (isPrimary) TechCyan.copy(alpha = 0.2f) else DarkCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isPrimary) TechCyan else DarkSurfaceVariant
        )
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall,
            color = if (isPrimary) TechCyan else TextSecondary
        )
    }
}
