package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.utils.AdbTunnelStatus
import com.example.utils.DeferredQueueState

@Composable
fun InteractiveMessengerOverlayDemo(
    isDeferredActive: Boolean,
    queueState: DeferredQueueState,
    adbStatus: AdbTunnelStatus,
    modelMatrixVersion: String,
    onTriggerEvent: (appName: String, text: String) -> Unit,
    onTriggerDesktopSync: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isOverlayVisible by remember { mutableStateOf(false) }
    var lastSimulatedApp by remember { mutableStateOf("org.telegram.messenger") }
    var lastSimulatedText by remember { mutableStateOf("Выхожу через 5 минут, надел шапку") }
    var lastOverlayMode by remember { mutableStateOf(isDeferredActive) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("messenger_overlay_demo_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = TechCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Column {
                        Text(
                            text = "Live Glassmorphism Overlay & Messenger Feed",
                            style = MaterialTheme.typography.titleMedium,
                            color = TechCyan
                        )
                        Text(
                            text = "Simulated Telegram / Viber Host UI with Jetpack Compose Injection",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isDeferredActive) TechEmerald.copy(alpha = 0.15f) else TechRed.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (isDeferredActive) "Mode: V-Sync Queue" else "Mode: Direct Render",
                        color = if (isDeferredActive) TechEmerald else TechRed,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            // Simulated Host App (Telegram Feed) Window
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF17212B)) // Telegram Dark Theme Blue-Grey
                    .border(1.dp, DarkSurfaceVariant, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Telegram Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2AABEE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Column {
                                Text(
                                    text = if (lastSimulatedApp.contains("telegram")) "Telegram (Host Process)" else "Viber (Host Process)",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Active Surface • Mali-G51 GPU Frame: 60Hz",
                                    color = Color(0xFF7F91A4),
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF242F3D)
                        ) {
                            Text(
                                text = "PID: 12480",
                                color = Color(0xFF7F91A4),
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFF242F3D))

                    // Host Chat Messages
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TelegramBubble(
                            sender = "Alex (Team Lead)",
                            text = "Выезжаю на тестовый полигон с Nova Y61.",
                            time = "14:20",
                            isIncoming = true
                        )
                        TelegramBubble(
                            sender = "You",
                            text = lastSimulatedText,
                            time = "14:21",
                            isIncoming = false
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Semi-Transparent Jetpack Compose Glassmorphism Overlay (The Archimedes Card)
                androidx.compose.animation.AnimatedVisibility(
                    visible = isOverlayVisible,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically(),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp)
                            .testTag("glassmorphic_overlay_card"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = DarkCard.copy(alpha = 0.88f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            Brush.horizontalGradient(
                                listOf(TechCyan.copy(alpha = 0.6f), TechPurple.copy(alpha = 0.6f))
                            )
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = null,
                                        tint = TechCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Kirin AI Assist • Glassmorphism Layer",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TechCyan,
                                        fontSize = 11.sp
                                    )
                                }

                                IconButton(
                                    onClick = { isOverlayVisible = false },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted, modifier = Modifier.size(14.dp))
                                }
                            }

                            Text(
                                text = "Captured: \"$lastSimulatedText\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                fontSize = 11.sp
                            )

                            // Status Banner inside overlay showing render verdict
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (lastOverlayMode) TechEmerald.copy(alpha = 0.15f) else TechRed.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = if (lastOverlayMode) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = if (lastOverlayMode) TechEmerald else TechRed,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = if (lastOverlayMode) {
                                            "V-Sync Choreographer Aligned: 60.0 FPS • Zero Bus Contention"
                                        } else {
                                            "Immediate Draw: Memory Bus Clash • Frame Dropped to 41 FPS!"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (lastOverlayMode) TechEmerald else TechRed,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Interactive Simulation Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        lastSimulatedApp = "org.telegram.messenger"
                        lastSimulatedText = "Снимок чата: Зафиксирован адрес и время встречи"
                        lastOverlayMode = isDeferredActive
                        onTriggerEvent(lastSimulatedApp, lastSimulatedText)
                        isOverlayVisible = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("simulate_telegram_event_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TechCyan,
                        contentColor = DarkBackground
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Test Telegram Event", fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        lastSimulatedApp = "com.viber.voip"
                        lastSimulatedText = "Входящий вызов: согласование релиза GSI Treble"
                        lastOverlayMode = isDeferredActive
                        onTriggerEvent(lastSimulatedApp, lastSimulatedText)
                        isOverlayVisible = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("simulate_viber_event_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TechPurple,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Test Viber Event", fontSize = 11.sp)
                }
            }

            // Desktop Symbiosis & PC Link Row
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Computer,
                            contentDescription = null,
                            tint = TechCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "Desktop PC Symbiosis • ${adbStatus.label}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Matrix: $modelMatrixVersion • App Inspection Ready",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onTriggerDesktopSync,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TechCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanDim),
                        modifier = Modifier.testTag("adb_desktop_sync_btn")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Sync ADB", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelegramBubble(
    sender: String,
    text: String,
    time: String,
    isIncoming: Boolean
) {
    val bubbleColor = if (isIncoming) Color(0xFF182533) else Color(0xFF2B5278)
    val align = if (isIncoming) Alignment.Start else Alignment.End

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isIncoming) Alignment.CenterStart else Alignment.CenterEnd
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 240.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(bubbleColor)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            if (isIncoming) {
                Text(text = sender, color = Color(0xFF64B5F6), fontSize = 10.sp, style = MaterialTheme.typography.labelSmall)
            }
            Text(text = text, color = Color.White, fontSize = 11.sp)
            Text(
                text = time,
                color = Color(0xFF7F91A4),
                fontSize = 9.sp,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}
