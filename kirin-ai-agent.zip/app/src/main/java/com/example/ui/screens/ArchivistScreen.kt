package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Input
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.KnowledgeDocEntity
import com.example.data.SnapshotEntity
import com.example.ui.components.InteractiveMessengerOverlayDemo
import com.example.ui.components.MaliG51GpuVisualizer
import com.example.ui.components.ZstdRamCompressionCard
import com.example.ui.theme.*
import com.example.utils.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ArchivistScreen(
    // Knowledge Base & RAG Parameters
    knowledgeDocs: List<KnowledgeDocEntity> = emptyList(),
    isRagEnabled: Boolean = true,
    ragQuery: String = "",
    ragSearchResults: List<RagSearchResult> = emptyList(),
    scannedOcrText: String = "",
    capturedNotificationsCount: Int = 0,
    onSearchRag: (String) -> Unit = {},
    onToggleRag: (Boolean) -> Unit = {},
    onCaptureTelemetry: () -> Unit = {},
    onCaptureOcr: (String) -> Unit = {},
    onCaptureNotifications: () -> Unit = {},
    onCreateCustomDoc: (String, String, String, String) -> Unit = { _, _, _, _ -> },
    onDeleteDoc: (Long) -> Unit = {},
    onClearDocs: () -> Unit = {},
    onExportKnowledgeBase: (Boolean) -> String = { "" },
    onAskAiWithRag: (String) -> Unit = {},

    // Legacy Snapshot & Pipeline Parameters
    snapshots: List<SnapshotEntity>,
    hotBufferCount: Int,
    deduplicatedCount: Int,
    isPrivacyShieldActive: Boolean,
    isAudioImmunityActive: Boolean,
    throttleState: ThrottleState,
    zonedProcesses: List<ZonedProcess>,
    lastExportSummary: String?,
    onToggleAudioImmunity: () -> Unit,
    onTogglePrivacyShield: () -> Unit,
    onExportDataset: () -> Unit,
    onSimulateCapture: (String, String) -> Unit,
    onClearSnapshots: () -> Unit,

    // Mali-G51 GPU & V-Sync Parameters
    isDeferredActive: Boolean = true,
    fps: Float = 60.0f,
    frameTimeMs: Float = 16.6f,
    busContention: Int = 2,
    dvfsStatus: String = "LOCKED 2.0 GHz (Optimal)",
    jankCounter: Int = 0,
    queueState: DeferredQueueState = DeferredQueueState.IDLE,
    onToggleDeferred: (Boolean) -> Unit = {},
    onResetJank: () -> Unit = {},
    onTriggerDeferredOverlayTest: (String, String) -> Unit = { _, _ -> },

    // ObjectBox & Zstandard Parameters
    totalRawBytes: Long = 0L,
    totalCompressedBytes: Long = 0L,
    zstdSavingsPercent: Float = 78.4f,
    flashWritesAvoided: Int = 100,
    ramDeltas: List<CompressedDelta> = emptyList(),
    onClearRamDeltas: () -> Unit = {},

    // Desktop Symbiosis Parameters
    adbStatus: AdbTunnelStatus = AdbTunnelStatus.LISTENING_PORT_5037,
    modelMatrixVersion: String = "v2.4-Kirin710A-Tuned",
    onTriggerDesktopSync: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    var selectedArchivistTab by remember { mutableIntStateOf(0) }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    var showCreateDocDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportContent by remember { mutableStateOf("") }
    var localRagSearchInput by remember { mutableStateOf(ragQuery) }

    // Dialog state for creating new doc
    var newDocTitle by remember { mutableStateOf("") }
    var newDocCategory by remember { mutableStateOf("MANUAL") }
    var newDocTags by remember { mutableStateOf("note,custom") }
    var newDocContent by remember { mutableStateOf("") }

    val categories = listOf("ALL", "TELEMETRY", "OCR_SCAN", "NOTIFICATION", "ARCHITECTURE", "SYSTEM_LOG", "MANUAL")

    val filteredDocs = remember(knowledgeDocs, selectedCategoryFilter) {
        if (selectedCategoryFilter == "ALL") {
            knowledgeDocs
        } else {
            knowledgeDocs.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top Sub-Tab Switcher
        ScrollableTabRow(
            selectedTabIndex = selectedArchivistTab,
            containerColor = DarkSurface,
            contentColor = TechCyan,
            edgePadding = 12.dp,
            divider = { HorizontalDivider(color = DarkSurfaceVariant) }
        ) {
            Tab(
                selected = selectedArchivistTab == 0,
                onClick = { selectedArchivistTab = 0 },
                text = {
                    Text(
                        text = if (isRu) "База Знаний & Документы" else "Knowledge Base & Docs",
                        fontSize = 12.sp,
                        fontWeight = if (selectedArchivistTab == 0) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedArchivistTab == 0) TechCyan else TextMuted
                    )
                },
                icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.testTag("tab_knowledge_base")
            )
            Tab(
                selected = selectedArchivistTab == 1,
                onClick = { selectedArchivistTab = 1 },
                text = {
                    Text(
                        text = if (isRu) "RAG Поиск & Синтез" else "RAG Query & Synthesis",
                        fontSize = 12.sp,
                        fontWeight = if (selectedArchivistTab == 1) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedArchivistTab == 1) TechEmerald else TextMuted
                    )
                },
                icon = { Icon(Icons.Default.FindInPage, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.testTag("tab_rag_query")
            )
            Tab(
                selected = selectedArchivistTab == 2,
                onClick = { selectedArchivistTab = 2 },
                text = {
                    Text(
                        text = if (isRu) "Пайплайн Данных & Буфер" else "Data Pipeline & Buffer",
                        fontSize = 12.sp,
                        fontWeight = if (selectedArchivistTab == 2) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedArchivistTab == 2) TechAmber else TextMuted
                    )
                },
                icon = { Icon(Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.testTag("tab_data_pipeline")
            )
            Tab(
                selected = selectedArchivistTab == 3,
                onClick = { selectedArchivistTab = 3 },
                text = {
                    Text(
                        text = if (isRu) "Mali-G51 V-Sync & ПК" else "Mali-G51 & Symbiosis",
                        fontSize = 12.sp,
                        fontWeight = if (selectedArchivistTab == 3) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedArchivistTab == 3) TechPurple else TextMuted
                    )
                },
                icon = { Icon(Icons.Default.VideogameAsset, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.testTag("tab_vsync_symbiosis")
            )
        }

        when (selectedArchivistTab) {
            // TAB 0: KNOWLEDGE BASE & PHONE DATA INTAKE
            0 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
                ) {
                    // Header Card: Summary & Stats
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.AutoStories, contentDescription = null, tint = TechCyan, modifier = Modifier.size(24.dp))
                                        Column {
                                            Text(
                                                text = if (isRu) "База Знаний (Local Room RAG)" else "Local Knowledge Base & RAG",
                                                style = MaterialTheme.typography.titleMedium,
                                                color = TechCyan,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (isRu) "Документирование всех функций телефона и аппаратных снимков" else "Documenting phone telemetry, OCR, and system archives",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isRagEnabled) TechEmerald.copy(alpha = 0.15f) else DarkSurface,
                                        modifier = Modifier.clickable { onToggleRag(!isRagEnabled) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(if (isRagEnabled) TechEmerald else TextMuted)
                                            )
                                            Text(
                                                text = if (isRagEnabled) "RAG: ON" else "RAG: OFF",
                                                color = if (isRagEnabled) TechEmerald else TextMuted,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                HorizontalDivider(color = DarkSurfaceVariant)

                                // 3 Metric Pills
                                val totalWords = knowledgeDocs.sumOf { it.wordCount }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    ArchivistStatPill(
                                        label = if (isRu) "Документов" else "Documents",
                                        value = "${knowledgeDocs.size} шт.",
                                        subtext = if (isRu) "Room SQLite" else "Local DB",
                                        tint = TechCyan
                                    )
                                    ArchivistStatPill(
                                        label = if (isRu) "Слов в базе" else "Words Indexed",
                                        value = "$totalWords слов",
                                        subtext = if (isRu) "Готово к RAG" else "Tokenized",
                                        tint = TechEmerald
                                    )
                                    ArchivistStatPill(
                                        label = if (isRu) "Статус RAG" else "RAG Engine",
                                        value = if (isRagEnabled) "АКТИВЕН" else "ВЫКЛ",
                                        subtext = if (isRu) "Векторный поиск" else "TF-IDF + Tags",
                                        tint = if (isRagEnabled) TechAmber else TextMuted
                                    )
                                }
                            }
                        }
                    }

                    // Quick-Intake Actions: Capture Phone Functions into Knowledge Base
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = if (isRu) "⚡ Захват функций телефона в Базу Знаний" else "⚡ Capture Phone Functions into Knowledge Base",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onCaptureTelemetry,
                                    modifier = Modifier.weight(1f).testTag("capture_telemetry_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "Снимок Железа" else "Telemetry Snap", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }

                                Button(
                                    onClick = {
                                        val text = scannedOcrText.ifBlank { "DOC #KIRIN-710A-HW-REVISION-EMUI12-PASS" }
                                        onCaptureOcr(text)
                                    },
                                    modifier = Modifier.weight(1f).testTag("capture_ocr_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = DarkBackground),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "Захват OCR" else "OCR Capture", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onCaptureNotifications,
                                    modifier = Modifier.weight(1f).testTag("capture_notifs_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TechAmber),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "Уведомления ($capturedNotificationsCount)" else "Notifs ($capturedNotificationsCount)", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { showCreateDocDialog = true },
                                    modifier = Modifier.weight(1f).testTag("create_custom_doc_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TechPurple),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "+ Заметка / Док" else "+ Custom Doc", fontSize = 11.sp)
                                }
                            }

                            // Export buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        exportContent = onExportKnowledgeBase(true)
                                        showExportDialog = true
                                    },
                                    modifier = Modifier.weight(1f).testTag("export_kb_md_btn"),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyanDim),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TechCyan)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "Экспорт Markdown" else "Export MD", fontSize = 10.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        exportContent = onExportKnowledgeBase(false)
                                        showExportDialog = true
                                    },
                                    modifier = Modifier.weight(1f).testTag("export_kb_json_btn"),
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TechEmeraldDim),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TechEmerald)
                                ) {
                                    Icon(Icons.Default.DataObject, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isRu) "Экспорт JSON" else "Export JSON", fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    // Category Filter Chips
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(categories) { cat ->
                                val isSelected = selectedCategoryFilter == cat
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCategoryFilter = cat },
                                    label = { Text(text = cat, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TechCyan.copy(alpha = 0.2f),
                                        selectedLabelColor = TechCyan,
                                        containerColor = DarkSurface,
                                        labelColor = TextMuted
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = if (isSelected) TechCyan else DarkSurfaceVariant
                                    )
                                )
                            }
                        }
                    }

                    // Documents List
                    if (filteredDocs.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkSurface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                                    Text(
                                        text = if (isRu) "В базе знаний пока нет документов этой категории" else "No documents in this category yet",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = if (isRu) "Нажмите «Снимок Железа» или «Захват OCR» выше для документирования!" else "Click 'Telemetry Snap' or 'OCR Capture' to document phone data!",
                                        color = TechCyan,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    } else {
                        items(filteredDocs, key = { it.id }) { doc ->
                            KnowledgeDocCard(
                                doc = doc,
                                isRu = isRu,
                                onDelete = { onDeleteDoc(doc.id) },
                                onCopy = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("KnowledgeDoc", doc.content))
                                }
                            )
                        }
                    }
                }
            }

            // TAB 1: RAG SEARCH & REAL-TIME RETRIEVAL TESTER
            1 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
                ) {
                    // RAG Query Input Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Psychology, contentDescription = null, tint = TechEmerald, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = if (isRu) "Интерактивный RAG-Поиск" else "Interactive RAG Retrieval Engine",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TechEmerald,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isRu) "Семантический и токенный поиск по локальным данным телефона" else "Semantic & keyword retrieval across local knowledge base",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = localRagSearchInput,
                                    onValueChange = {
                                        localRagSearchInput = it
                                        onSearchRag(it)
                                    },
                                    placeholder = {
                                        Text(
                                            text = if (isRu) "Например: состояние процессора, батарея, telegram, ppg..." else "e.g. cpu temperature, battery, telegram, ocr...",
                                            fontSize = 12.sp,
                                            color = TextMuted
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("rag_search_input"),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TechEmerald,
                                        unfocusedBorderColor = DarkSurfaceVariant,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    trailingIcon = {
                                        if (localRagSearchInput.isNotBlank()) {
                                            IconButton(onClick = {
                                                localRagSearchInput = ""
                                                onSearchRag("")
                                            }) {
                                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextMuted)
                                            }
                                        }
                                    }
                                )

                                // Quick Query Chips
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val quickQueries = if (isRu) listOf(
                                        "температура и ядра Kirin 710A",
                                        "состояние батареи и зарядка",
                                        "Mali-G51 V-Sync Telegram",
                                        "оптический пульс PPG",
                                        "уведомления"
                                    ) else listOf(
                                        "Kirin 710A core temperature",
                                        "battery status and charging",
                                        "Mali-G51 V-Sync Telegram",
                                        "optical PPG pulse",
                                        "notifications"
                                    )

                                    items(quickQueries) { q ->
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = DarkSurface,
                                            modifier = Modifier.clickable {
                                                localRagSearchInput = q
                                                onSearchRag(q)
                                            }
                                        ) {
                                            Text(
                                                text = q,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                fontSize = 10.sp,
                                                color = TechEmerald
                                            )
                                        }
                                    }
                                }

                                if (localRagSearchInput.isNotBlank()) {
                                    Button(
                                        onClick = { onAskAiWithRag(localRagSearchInput) },
                                        modifier = Modifier.fillMaxWidth().testTag("ask_ai_with_rag_btn"),
                                        colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = DarkBackground),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isRu) "Спросить Gemini через RAG-контекст" else "Ask Gemini with RAG Context",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Search Results Breakdown
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isRu) "Результаты RAG-извлечения (${ragSearchResults.size})" else "RAG Retrieval Results (${ragSearchResults.size})",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            if (ragSearchResults.isNotEmpty()) {
                                Text(
                                    text = if (isRu) "Топ релевантность: ${ragSearchResults.first().scorePercent}%" else "Top Match: ${ragSearchResults.first().scorePercent}%",
                                    color = TechEmerald,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    if (ragSearchResults.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkSurface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                                    Text(
                                        text = if (isRu) "Введите запрос выше для проверки RAG-поиска" else "Enter a query above to test RAG retrieval",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    } else {
                        items(ragSearchResults) { result ->
                            RagResultCard(result = result, isRu = isRu)
                        }
                    }
                }
            }

            // TAB 2: DATA PIPELINE & HOT BUFFER (LEGACY)
            2 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = TechCyan, modifier = Modifier.size(24.dp))
                                        Column {
                                            Text(text = "Digital Archivist & Dispatcher", style = MaterialTheme.typography.titleMedium, color = TechCyan)
                                            Text(text = "3-Tier Data Pipeline & Kirin 710A Resource Governance", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                        }
                                    }

                                    IconButton(onClick = onClearSnapshots, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Clear", tint = TextMuted)
                                    }
                                }

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    ArchivistStatPill(
                                        label = "Hot RAM Buffer",
                                        value = "$hotBufferCount items",
                                        subtext = "mlockall active",
                                        tint = TechCyan
                                    )
                                    ArchivistStatPill(
                                        label = "Noise Filtered",
                                        value = "$deduplicatedCount diffs",
                                        subtext = "90% flash I/O saved",
                                        tint = TechEmerald
                                    )
                                    ArchivistStatPill(
                                        label = "Warm Storage",
                                        value = "${snapshots.size} records",
                                        subtext = "Room SQLite",
                                        tint = TechAmber
                                    )
                                }
                            }
                        }
                    }

                    // Adaptive Throttle & Audio Immunity
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (throttleState == ThrottleState.THERMAL_COOLDOWN) Icons.Default.Warning else Icons.Default.Speed,
                                            contentDescription = null,
                                            tint = if (throttleState == ThrottleState.THERMAL_COOLDOWN) TechAmber else TechCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(text = "CPU Governor: ${throttleState.label}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isAudioImmunityActive) TechEmerald.copy(alpha = 0.15f) else DarkSurface
                                    ) {
                                        Text(
                                            text = if (isAudioImmunityActive) "Audio Immunity: ON" else "Audio Immunity: OFF",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isAudioImmunityActive) TechEmerald else TextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Text(
                                    text = throttleState.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Controls
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(text = "Archivist Controls & Actions", style = MaterialTheme.typography.titleSmall, color = TextPrimary)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onToggleAudioImmunity,
                                    modifier = Modifier.weight(1f).testTag("toggle_audio_immunity_btn"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isAudioImmunityActive) TechEmerald else DarkSurfaceVariant,
                                        contentColor = if (isAudioImmunityActive) DarkBackground else TextPrimary
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.VolumeMute, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isAudioImmunityActive) "Immunity Active" else "Enable Immunity", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = onTogglePrivacyShield,
                                    modifier = Modifier.weight(1f).testTag("toggle_privacy_shield_btn"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isPrivacyShieldActive) TechPurple else DarkSurfaceVariant,
                                        contentColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = if (isPrivacyShieldActive) "Shield Active" else "Shield Masking", fontSize = 11.sp)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onExportDataset,
                                    modifier = Modifier.weight(1f).testTag("export_dataset_btn"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = TechAmber,
                                        contentColor = DarkBackground
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Export Cold JSON.GZ", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { onSimulateCapture("org.telegram.messenger", "Снимок переписки Telegram") },
                                    modifier = Modifier.weight(1f).testTag("simulate_capture_dialog_btn"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DarkSurfaceVariant,
                                        contentColor = TechCyan
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Input, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Simulate Event", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    // Process Zoning
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Dynamic Process Zoning (Kirin 710A)", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                    Text(text = "${zonedProcesses.size} tracked apps", style = MaterialTheme.typography.labelSmall, color = TechCyan)
                                }

                                zonedProcesses.take(5).forEach { proc ->
                                    val zoneColor = when (proc.zone) {
                                        ProcessZone.HOT -> TechCyan
                                        ProcessZone.WARM -> TechAmber
                                        ProcessZone.COLD -> TextMuted
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = DarkSurface,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                                .fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = proc.appName, style = MaterialTheme.typography.labelMedium, color = TextPrimary, fontSize = 12.sp)
                                                Text(text = proc.packageName, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = zoneColor.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "${proc.zone.name} (${proc.ramEstimateMb} MB)",
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = zoneColor,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 3: MALI-G51 V-SYNC & PC SYMBIOSIS
            3 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    item {
                        MaliG51GpuVisualizer(
                            isDeferredActive = isDeferredActive,
                            fps = fps,
                            frameTimeMs = frameTimeMs,
                            busContention = busContention,
                            dvfsStatus = dvfsStatus,
                            jankCounter = jankCounter,
                            queueState = queueState,
                            onToggleDeferred = onToggleDeferred,
                            onResetJank = onResetJank
                        )
                    }

                    item {
                        InteractiveMessengerOverlayDemo(
                            isDeferredActive = isDeferredActive,
                            queueState = queueState,
                            adbStatus = adbStatus,
                            modelMatrixVersion = modelMatrixVersion,
                            onTriggerEvent = onTriggerDeferredOverlayTest,
                            onTriggerDesktopSync = onTriggerDesktopSync
                        )
                    }

                    item {
                        ZstdRamCompressionCard(
                            totalRawBytes = totalRawBytes,
                            totalCompressedBytes = totalCompressedBytes,
                            savingsPercent = zstdSavingsPercent,
                            flashWritesAvoided = flashWritesAvoided,
                            deltas = ramDeltas,
                            onClearRamDeltas = onClearRamDeltas
                        )
                    }
                }
            }
        }
    }

    // DIALOG: CREATE CUSTOM DOCUMENT / NOTE
    if (showCreateDocDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDocDialog = false },
            containerColor = DarkCard,
            title = {
                Text(
                    text = if (isRu) "Добавить в Базу Знаний" else "Add to Knowledge Base",
                    color = TechCyan,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = newDocTitle,
                        onValueChange = { newDocTitle = it },
                        label = { Text("Заголовок документа / Title", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().testTag("new_doc_title_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newDocTags,
                        onValueChange = { newDocTags = it },
                        label = { Text("Теги через запятую / Tags", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newDocContent,
                        onValueChange = { newDocContent = it },
                        label = { Text("Содержимое / Content (Markdown)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().height(140.dp).testTag("new_doc_content_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newDocTitle.isNotBlank() && newDocContent.isNotBlank()) {
                            onCreateCustomDoc(newDocTitle, newDocContent, newDocCategory, newDocTags)
                            showCreateDocDialog = false
                            newDocTitle = ""
                            newDocContent = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground)
                ) {
                    Text(text = if (isRu) "Сохранить" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDocDialog = false }) {
                    Text(text = if (isRu) "Отмена" else "Cancel", color = TextMuted)
                }
            }
        )
    }

    // DIALOG: EXPORT PREVIEW & COPY
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = DarkCard,
            title = {
                Text(
                    text = if (isRu) "Экспорт Базы Знаний" else "Knowledge Base Export",
                    color = TechEmerald,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isRu) "Все документы и телеметрия сформированы для сохранения:" else "All documents formatted for export:",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    OutlinedTextField(
                        value = exportContent,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(220.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("KnowledgeBaseExport", exportContent))
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = DarkBackground)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = if (isRu) "Копировать всё" else "Copy All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text(text = if (isRu) "Закрыть" else "Close", color = TextMuted)
                }
            }
        )
    }
}

@Composable
private fun KnowledgeDocCard(
    doc: KnowledgeDocEntity,
    isRu: Boolean,
    onDelete: () -> Unit,
    onCopy: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val timeStr = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(doc.timestamp))

    val categoryColor = when (doc.category.uppercase()) {
        "TELEMETRY" -> TechCyan
        "OCR_SCAN" -> TechEmerald
        "NOTIFICATION" -> TechAmber
        "ARCHITECTURE" -> TechPurple
        "SYSTEM_LOG" -> TechCyanDim
        else -> TextPrimary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = categoryColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = doc.category,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = categoryColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (doc.isPinned) {
                        Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = TechAmber, modifier = Modifier.size(12.dp))
                    }

                    Text(
                        text = timeStr,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextMuted, modifier = Modifier.size(15.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(15.dp))
                    }
                }
            }

            Text(
                text = doc.title,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )

            if (!isExpanded) {
                Text(
                    text = doc.summary.ifBlank { doc.content.take(120) },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            } else {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = doc.content,
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Теги: ${doc.tags} • ${doc.wordCount} сл.",
                    color = TextMuted,
                    fontSize = 10.sp
                )

                TextButton(
                    onClick = { isExpanded = !isExpanded },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                    Text(
                        text = if (isExpanded) (if (isRu) "Свернуть ▲" else "Collapse ▲") else (if (isRu) "Развернуть ▼" else "Expand ▼"),
                        fontSize = 11.sp,
                        color = TechCyan
                    )
                }
            }
        }
    }
}

@Composable
private fun RagResultCard(
    result: RagSearchResult,
    isRu: Boolean
) {
    val scoreColor = when {
        result.scorePercent >= 80 -> TechEmerald
        result.scorePercent >= 50 -> TechCyan
        else -> TechAmber
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = result.doc.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = scoreColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${result.scorePercent}% СОВПАДЕНИЕ",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        color = scoreColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = result.matchedSnippet,
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            if (result.matchedKeywords.isNotEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = if (isRu) "Ключи:" else "Keys:", color = TextMuted, fontSize = 10.sp)
                    result.matchedKeywords.take(4).forEach { kw ->
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = TechEmerald.copy(alpha = 0.1f)
                        ) {
                            Text(
                                text = kw,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                color = TechEmerald,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArchivistStatPill(
    label: String,
    value: String,
    subtext: String,
    tint: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSurface,
        modifier = Modifier.width(100.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
            Text(text = value, style = MaterialTheme.typography.titleSmall, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(text = subtext, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
        }
    }
}
