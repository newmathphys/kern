package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D1A)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkCard = Color(0xFF131F37)

val TechCyan = Color(0xFF00E5FF)
val TechCyanDim = Color(0xFF0090A8)
val TechBlue = Color(0xFF3B82F6)
val TechAmber = Color(0xFFFFB703)
val TechAmberDark = Color(0xFFFB8500)
val TechEmerald = Color(0xFF10B981)
val TechEmeraldDim = Color(0xFF059669)
val TechRed = Color(0xFFEF4444)
val TechPurple = Color(0xFF8B5CF6)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BigCoreGold = Color(0xFFFFD166)
val LittleCoreBlue = Color(0xFF4CC9F0)
