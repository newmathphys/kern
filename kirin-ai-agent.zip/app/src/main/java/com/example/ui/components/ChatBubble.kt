package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgentAction
import com.example.model.ChatMessage
import com.example.ui.theme.*

@Composable
fun ChatBubble(
    message: ChatMessage,
    onExecuteAction: (AgentAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    var isThinkingExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (!isUser && message.modelUsed != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = TechCyan,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = message.modelUsed,
                    style = MaterialTheme.typography.labelSmall,
                    color = TechCyan,
                    fontSize = 11.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(if (isUser) TechCyan.copy(alpha = 0.18f) else DarkCard)
                .border(
                    1.dp,
                    if (isUser) TechCyan.copy(alpha = 0.4f) else DarkSurfaceVariant,
                    RoundedCornerShape(16.dp)
                )
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {

                // High Thinking Section (if available from gemini-3.1-pro-preview)
                if (!message.thinking.isNullOrBlank()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { isThinkingExpanded = !isThinkingExpanded },
                        color = TechPurple.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TechPurple.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = "Thinking Mode",
                                        tint = TechPurple,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "High Thinking Reasoning",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TechPurple,
                                        fontSize = 12.sp
                                    )
                                }
                                Icon(
                                    imageVector = if (isThinkingExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "Toggle",
                                    tint = TechPurple,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            AnimatedVisibility(visible = isThinkingExpanded) {
                                Text(
                                    text = message.thinking,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }

                // Main Message Content
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    lineHeight = 20.sp
                )

                // Parsed Action Plan (if any)
                if (!message.actionPlan.isNullOrEmpty()) {
                    HorizontalDivider(color = DarkSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "Suggested Automation Actions:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TechAmber
                    )
                    message.actionPlan.forEach { action ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            color = DarkSurfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = action.type.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TechCyan,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "${action.target} • ${action.details}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                IconButton(
                                    onClick = { onExecuteAction(action) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Execute Action",
                                        tint = TechEmerald,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
