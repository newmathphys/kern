package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberEyesComponent
import com.example.ui.theme.*
import com.example.utils.LocalizationManager
import com.example.utils.VoiceHardwareController

@Composable
fun CliTerminalScreen(
    isTorchOn: Boolean,
    isListening: Boolean,
    soundAngle: Float,
    soundSourceLabel: String,
    decibels: Float,
    terminalLogs: List<String>,
    isFrontCamera: Boolean,
    isScanningActive: Boolean,
    scannedQr: String?,
    scannedOcr: String?,
    keystoreStatus: String,
    asciiFrame: List<String>,
    isMatrixRainActive: Boolean = false,
    lastRecognizedSpeech: String = "",
    pulseBpm: Int = 72,
    stressIndex: String = "NORMAL (Stress Index: 16.8)",
    opticalDensityVariation: String = "G-Channel Absorption: Δ0.34% @ 1.2 Hz",
    flickerFrequencyHz: Int = 60,
    isAssistantActive: Boolean = true,
    assistantUptimeSeconds: Long = 0L,
    cpuTempCelsius: Int = 37,
    fps: Int = 60,
    batteryPercent: Int = 85,
    zstdSavingsPercent: Float = 78.4f,
    onToggleTorch: () -> Unit,
    onVoiceCommand: (String) -> Unit,
    onToggleListening: (Boolean) -> Unit,
    onAcousticPulse: (Float) -> Unit,
    onToggleCameraFacing: () -> Unit,
    onSimulateQr: (String) -> Unit,
    onSimulateOcr: (String) -> Unit,
    onClearTerminal: () -> Unit,
    onToggleMatrixRain: (Boolean?) -> Unit = {},
    onMeasurePulseAndStress: () -> Unit = {},
    onDetectAmbientFlicker: () -> Unit = {},
    onToggleAssistant: () -> Unit = {},
    onToggleLanguage: () -> Unit = {},
    onOpenFullScreen: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by LocalizationManager.currentLanguage.collectAsState()
    var touchPos by remember { mutableStateOf<Offset?>(null) }
    var touchTrailSymbol by remember { mutableStateOf("0x7D68") }
    var voiceInputText by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        touchPos = offset
                        touchTrailSymbol = listOf("0x7D68", "A73_2GHz", "KIRIN", "ZSTD", "10110", "DOD_ECS", "VOICE").random()
                    },
                    onDrag = { change, _ ->
                        touchPos = change.position
                        if (change.position.x > 600f && change.position.y > 1200f) {
                            VoiceHardwareController.speak(if (lang.code == "ru") "Инженерная консоль активна." else "Engineering console active.")
                        }
                    },
                    onDragEnd = { touchPos = null }
                )
            }
    ) {
        if (isMatrixRainActive) {
            MatrixRainEffect(modifier = Modifier.fillMaxSize())
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp)
        ) {
            // Top Terminal Header with Language Switcher and Matrix Rain Switch
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("cli_header_card"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF05080E)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechEmerald.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Terminal, contentDescription = null, tint = TechEmerald, modifier = Modifier.size(16.dp))
                                Text(
                                    text = if (lang.code == "ru") "МАТРИЦА // Kirin 710A" else "MATRIX CORE // Kirin 710A",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TechEmerald,
                                    fontSize = 12.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                // Dynamic Language Switcher Badge (RU | EN)
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = TechCyan.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan),
                                    onClick = onToggleLanguage,
                                    modifier = Modifier.testTag("lang_toggle_btn")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Language, contentDescription = "Language", tint = TechCyan, modifier = Modifier.size(12.dp))
                                        Text(
                                            text = if (lang.code == "ru") "RU | en" else "ru | EN",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 9.sp
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isMatrixRainActive) TechEmerald.copy(alpha = 0.25f) else Color(0xFF151D28),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isMatrixRainActive) TechEmerald else Color(0xFF263238)),
                                    onClick = { onToggleMatrixRain(!isMatrixRainActive) },
                                    modifier = Modifier.testTag("toggle_matrix_rain_btn")
                                ) {
                                    Text(
                                        text = if (isMatrixRainActive) "RAIN: ON" else "RAIN: OFF",
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isMatrixRainActive) TechEmerald else TextMuted,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isTorchOn) TechAmber.copy(alpha = 0.2f) else TechEmerald.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (isTorchOn) "TORCH: ON" else "TORCH: OFF",
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isTorchOn) TechAmber else TechEmerald,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "mlockall: OK", fontFamily = FontFamily.Monospace, color = TechEmerald, fontSize = 9.sp)
                            Text(text = "4x A73: 2.0 GHz", fontFamily = FontFamily.Monospace, color = TechCyan, fontSize = 9.sp)
                            Text(text = "Lang: ${lang.displayName}", fontFamily = FontFamily.Monospace, color = TechAmber, fontSize = 9.sp)
                            Text(text = "OLED: Pitch Black", fontFamily = FontFamily.Monospace, color = TechPurple, fontSize = 9.sp)
                        }
                    }
                }
            }

            // ALWAYS-ON CYBER EYES ASSISTANT COMPONENT
            item {
                CyberEyesComponent(
                    isAssistantActive = isAssistantActive,
                    isListening = isListening,
                    isTorchOn = isTorchOn,
                    soundAngle = soundAngle,
                    decibels = decibels,
                    pulseBpm = pulseBpm,
                    stressIndex = stressIndex,
                    cpuTempCelsius = cpuTempCelsius,
                    fps = fps,
                    batteryPercent = batteryPercent,
                    zstdSavingsPercent = zstdSavingsPercent,
                    uptimeSeconds = assistantUptimeSeconds,
                    onToggleAssistant = onToggleAssistant,
                    onOpenFullScreen = onOpenFullScreen
                )
            }

            // PRIMARY VOICE CONTROL DISPATCHER (All Phone Functions by Voice)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("primary_voice_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070C13)),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isListening) Brush.horizontalGradient(listOf(TechEmerald, TechCyan, TechAmber))
                        else Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang.code == "ru") "ГОЛОСОВОЙ ДИСПЕТЧЕР // ВСЕ ФУНКЦИИ" else "VOICE DISPATCHER // ALL PHONE FUNCTIONS",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isListening) TechEmerald else TechCyan,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = if (isListening) {
                                        if (lang.code == "ru") "Слушаю... Скажите: 'Фонарик', 'Позвони', 'Пульс'..." else "Listening... Say: 'Flashlight', 'Call', 'Pulse'..."
                                    } else {
                                        if (lang.code == "ru") "Нажмите микрофон или выберите команду" else "Tap mic or choose a command below"
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    color = TextSecondary,
                                    fontSize = 9.sp
                                )
                            }

                            // Big Pulsating Microphone Button
                            IconButton(
                                onClick = { onToggleListening(!isListening) },
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isListening) TechEmerald.copy(alpha = pulseAlpha)
                                        else Color(0xFF1E293B)
                                    )
                                    .border(
                                        2.dp,
                                        if (isListening) TechCyan else TechEmerald.copy(alpha = 0.5f),
                                        CircleShape
                                    )
                                    .testTag("main_mic_button")
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                                    contentDescription = "Voice Mic",
                                    tint = if (isListening) Color.Black else TechEmerald,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        // Real-time audio VU Meter
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "VU:", fontFamily = FontFamily.Monospace, color = TextMuted, fontSize = 9.sp)
                            val normalizedLevel = ((decibels - 30f) / 50f).coerceIn(0.05f, 1f)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF0F172A))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(normalizedLevel)
                                        .background(Brush.horizontalGradient(listOf(TechEmerald, TechCyan, TechAmber, TechRed)))
                                )
                            }
                            Text(text = "${decibels.toInt()} dB", fontFamily = FontFamily.Monospace, color = TechEmerald, fontSize = 9.sp)
                        }

                        // Last Recognized Speech or Last TTS Response
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF040608),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF152232)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                if (lastRecognizedSpeech.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = "VOICE INPUT >", fontFamily = FontFamily.Monospace, color = TechCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "\"$lastRecognizedSpeech\"", fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 10.sp)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = TechAmber, modifier = Modifier.size(12.dp))
                                    Text(
                                        text = VoiceHardwareController.lastSpokenText.value,
                                        fontFamily = FontFamily.Monospace,
                                        color = TechAmber,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }

                        // Text Voice Command Input bar (Type voice command or press Enter)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = voiceInputText,
                                onValueChange = { voiceInputText = it },
                                placeholder = {
                                    Text(
                                        if (lang.code == "ru") "Введите команду ('фонарик', 'пульс', 'позвони 112')..."
                                        else "Type voice command ('flashlight', 'pulse', 'call 911')...",
                                        fontSize = 9.sp,
                                        color = TextMuted
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("voice_command_input"),
                                shape = RoundedCornerShape(6.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color.White
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TechEmerald,
                                    unfocusedBorderColor = Color(0xFF1E293B),
                                    focusedContainerColor = Color(0xFF040609),
                                    unfocusedContainerColor = Color(0xFF040609)
                                ),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (voiceInputText.isNotBlank()) {
                                            onVoiceCommand(voiceInputText)
                                            voiceInputText = ""
                                            keyboardController?.hide()
                                        }
                                    }
                                )
                            )

                            IconButton(
                                onClick = {
                                    if (voiceInputText.isNotBlank()) {
                                        onVoiceCommand(voiceInputText)
                                        voiceInputText = ""
                                        keyboardController?.hide()
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(TechEmerald)
                                    .testTag("send_voice_cmd_btn")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Horizontal Quick Voice Command Chips
                        Text(
                            text = if (lang.code == "ru") "БЫСТРЫЕ ГОЛОСОВЫЕ КОМАНДЫ:" else "QUICK VOICE COMMANDS:",
                            fontFamily = FontFamily.Monospace,
                            color = TextMuted,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            item { VoiceChip(if (lang.code == "ru") "💡 Фонарик" else "💡 Flashlight", TechAmber) { onVoiceCommand(if (lang.code == "ru") "Включи фонарик" else "Turn on flashlight") } }
                            item { VoiceChip(if (lang.code == "ru") "💓 Пульс/PPG" else "💓 Pulse/PPG", TechRed) { onVoiceCommand(if (lang.code == "ru") "Измерь пульс" else "Measure pulse") } }
                            item { VoiceChip(if (lang.code == "ru") "👁️ Ассистент" else "👁️ Assistant", TechEmerald) { onToggleAssistant() } }
                            item { VoiceChip(if (lang.code == "ru") "📷 Камера" else "📷 Camera", TechCyan) { onVoiceCommand(if (lang.code == "ru") "Переключи камеру" else "Switch camera") } }
                            item { VoiceChip(if (lang.code == "ru") "📞 Звонок (112)" else "📞 Call (911)", TechEmerald) { onVoiceCommand(if (lang.code == "ru") "Позвони 112" else "Call 911") } }
                            item { VoiceChip(if (lang.code == "ru") "✉️ СМС" else "✉️ SMS", TechPurple) { onVoiceCommand(if (lang.code == "ru") "Открой СМС" else "Open messages") } }
                            item { VoiceChip(if (lang.code == "ru") "🔊 Громче" else "🔊 Volume Up", TechCyan) { onVoiceCommand(if (lang.code == "ru") "Громче" else "Volume up") } }
                            item { VoiceChip(if (lang.code == "ru") "🔇 Без звука" else "🔇 Mute", TextMuted) { onVoiceCommand(if (lang.code == "ru") "Без звука" else "Mute") } }
                            item { VoiceChip(if (lang.code == "ru") "🔋 Батарея" else "🔋 Battery", TechEmerald) { onVoiceCommand(if (lang.code == "ru") "Сколько процентов заряд" else "Battery status") } }
                            item { VoiceChip("📶 Wi-Fi", TechCyan) { onVoiceCommand("Вайфай") } }
                            item { VoiceChip("🔵 Bluetooth", TechCyan) { onVoiceCommand("Блютуз") } }
                            item { VoiceChip(if (lang.code == "ru") "🗺️ Карты" else "🗺️ Maps", TechAmber) { onVoiceCommand(if (lang.code == "ru") "Карты" else "Maps") } }
                            item { VoiceChip(if (lang.code == "ru") "⏰ Будильник" else "⏰ Alarm", TechEmerald) { onVoiceCommand(if (lang.code == "ru") "Будильник" else "Alarm") } }
                            item { VoiceChip(if (lang.code == "ru") "🧮 Калькулятор" else "🧮 Calculator", TechPurple) { onVoiceCommand(if (lang.code == "ru") "Калькулятор" else "Calculator") } }
                            item { VoiceChip(if (lang.code == "ru") "⚡ Разгон A73" else "⚡ A73 Boost", TechEmerald) { onVoiceCommand(if (lang.code == "ru") "Турбо разгон ядра A73" else "Turbo boost A73 cores") } }
                            item { VoiceChip(if (lang.code == "ru") "🗜️ Сжатие RAM" else "🗜️ Zstd RAM", TechCyan) { onVoiceCommand(if (lang.code == "ru") "Очисти память" else "Compact RAM memory") } }
                            item { VoiceChip(if (lang.code == "ru") "❓ Все команды" else "❓ All Commands", TechAmber) { onVoiceCommand(if (lang.code == "ru") "Все команды" else "Help commands") } }
                        }
                    }
                }
            }

            // Optical Neural Eyes, QR/OCR Scanner & Photoplethysmography (PPG)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("optical_scanner_card"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF05080E)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechAmber.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = TechAmber, modifier = Modifier.size(16.dp))
                                Text(
                                    text = if (isFrontCamera) {
                                        if (lang.code == "ru") "ОПТИКА // ФРОНТ (Пульс PPG / Взгляд)" else "OPTICAL // FRONT (PPG Pulse & Gaze)"
                                    } else {
                                        if (lang.code == "ru") "ОПТИКА // ОСНОВНАЯ КАМЕРА (QR / OCR)" else "OPTICAL // REAR (Macro QR & OCR)"
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    color = TechAmber,
                                    fontSize = 10.sp
                                )
                            }

                            TextButton(
                                onClick = onToggleCameraFacing,
                                modifier = Modifier.testTag("toggle_camera_facing_btn")
                            ) {
                                Text(
                                    text = if (isFrontCamera) {
                                        if (lang.code == "ru") "Переключить на заднюю" else "Switch to Rear"
                                    } else {
                                        if (lang.code == "ru") "Переключить на фронт" else "Switch to Front"
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = TechCyan
                                )
                            }
                        }

                        // ASCII Camera Viewfinder Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF020305))
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                asciiFrame.forEach { line ->
                                    Text(
                                        text = line,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isFrontCamera) TechEmerald else TechCyan,
                                        fontSize = 10.sp,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }

                        // Live Photoplethysmography (PPG) Heart Rate & Stress Readout
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0A0F17),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TechRed.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Favorite, contentDescription = null, tint = TechRed, modifier = Modifier.size(14.dp))
                                        Text(
                                            text = if (lang.code == "ru") "ФОТОПЛЕТИЗМОГРАФИЯ // Пульс по лицу" else "PHOTOPLETHYSMOGRAPHY // Pulse",
                                            fontFamily = FontFamily.Monospace,
                                            color = TechRed,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(text = "$pulseBpm BPM", fontFamily = FontFamily.Monospace, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(text = "HRV: $stressIndex", fontFamily = FontFamily.Monospace, color = TechEmerald, fontSize = 9.sp)
                                Text(text = opticalDensityVariation, fontFamily = FontFamily.Monospace, color = TechCyan, fontSize = 8.5.sp)
                                Text(text = "Ambient Flicker: $flickerFrequencyHz Hz", fontFamily = FontFamily.Monospace, color = TextMuted, fontSize = 8.5.sp)
                            }
                        }

                        // Scanned QR & OCR Results
                        if (scannedQr != null) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = TechEmerald.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "> QR: $scannedQr",
                                    fontFamily = FontFamily.Monospace,
                                    color = TechEmerald,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }

                        if (scannedOcr != null) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = TechCyan.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "> OCR: $scannedOcr",
                                    fontFamily = FontFamily.Monospace,
                                    color = TechCyan,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }

                        // Action Test Triggers for Pulse, QR and OCR
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = onMeasurePulseAndStress,
                                modifier = Modifier.weight(1f).testTag("measure_ppg_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = TechRed, contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(if (lang.code == "ru") "Измерить пульс" else "Measure Pulse", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }

                            Button(
                                onClick = { onSimulateQr("WIFI:S:Kirin_Secure_Net;P:Pass987654321;;") },
                                modifier = Modifier.weight(1f).testTag("sim_qr_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = Color.Black),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(if (lang.code == "ru") "Скан QR" else "Scan QR", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }

                            Button(
                                onClick = { onSimulateOcr("ID: #961-A73-NOVA-EMUI12-ZSTD-OK") },
                                modifier = Modifier.weight(1f).testTag("sim_ocr_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = Color.Black),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(if (lang.code == "ru") "Скан Текста" else "Scan OCR", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            // Quick Direct Hardware Syscalls Buttons
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("hardware_actions_card"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF05080E)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (lang.code == "ru") "ПРЯМЫЕ СИСТЕМНЫЕ ВЫЗОВЫ ТЕЛЕФОНА" else "HARDWARE DIRECT SYSCALLS",
                            fontFamily = FontFamily.Monospace,
                            color = TechCyan,
                            fontSize = 10.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = onToggleTorch,
                                modifier = Modifier.weight(1f).testTag("toggle_torch_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isTorchOn) TechAmber else DarkSurfaceVariant,
                                    contentColor = if (isTorchOn) Color.Black else TextPrimary
                                ),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.FlashlightOn, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = if (isTorchOn) "Torch ON" else "Torch", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }

                            Button(
                                onClick = { onVoiceCommand("Вайфай") },
                                modifier = Modifier.weight(1f).testTag("open_wifi_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TechCyan),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Wi-Fi", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }

                            Button(
                                onClick = { onVoiceCommand("Браузер") },
                                modifier = Modifier.weight(1f).testTag("open_browser_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TechEmerald),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Browser", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }

                            Button(
                                onClick = { onVoiceCommand("Статус") },
                                modifier = Modifier.weight(1f).testTag("cpu_status_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TechPurple),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Status", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            // Live Terminal Log Output Stream (stdout)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("terminal_stream_card"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF020305)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "RAW MACHINE LOG // stdout",
                                    fontFamily = FontFamily.Monospace,
                                    color = TextMuted,
                                    fontSize = 9.5.sp
                                )
                                Text(
                                    text = "(${terminalLogs.size} lines)",
                                    fontFamily = FontFamily.Monospace,
                                    color = TechEmerald.copy(alpha = 0.7f),
                                    fontSize = 8.5.sp
                                )
                            }
                            IconButton(onClick = onClearTerminal, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(12.dp))
                            }
                        }

                        terminalLogs.take(10).forEach { log ->
                            val color = when {
                                log.contains("Error", ignoreCase = true) -> TechRed
                                log.contains("Syscall") || log.contains("Kernel") || log.contains("Acoustic") -> TechCyan
                                log.contains("TTS") || log.contains("Voice") || log.contains("User") -> TechAmber
                                log.contains("PPG") || log.contains("Pulse") -> TechRed
                                else -> TechEmerald
                            }
                            Text(
                                text = log,
                                fontFamily = FontFamily.Monospace,
                                color = color,
                                fontSize = 9.5.sp,
                                lineHeight = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Tactile Finger Trail Overlay (where user touches/drags)
        touchPos?.let { pos ->
            Box(
                modifier = Modifier
                    .offset(x = (pos.x / 2.8f).dp, y = (pos.y / 2.8f).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(TechCyan.copy(alpha = 0.25f))
                    .border(1.dp, TechCyan, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$touchTrailSymbol [X:${pos.x.toInt()} Y:${pos.y.toInt()}]",
                    fontFamily = FontFamily.Monospace,
                    color = TechCyan,
                    fontSize = 8.5.sp
                )
            }
        }
    }
}

@Composable
private fun VoiceChip(label: String, color: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(4.dp),
        color = Color(0xFF0F172A),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Text(
            text = label,
            fontFamily = FontFamily.Monospace,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun MatrixRainEffect(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "matrixRain")
    val rainPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rainPhase"
    )

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val columns = 16
        val colWidth = width / columns

        for (i in 0 until columns) {
            val speedFactor = ((i * 37) % 10 + 5) / 10f
            val yOffset = ((rainPhase * speedFactor + (i * 0.13f)) % 1f) * height
            val x = i * colWidth + colWidth / 2f

            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        TechEmerald.copy(alpha = 0.15f),
                        TechEmerald.copy(alpha = 0.6f),
                        Color.White.copy(alpha = 0.9f)
                    ),
                    startY = (yOffset - 180f).coerceAtLeast(0f),
                    endY = yOffset
                ),
                start = Offset(x, (yOffset - 180f).coerceAtLeast(0f)),
                end = Offset(x, yOffset),
                strokeWidth = 2.5f
            )
        }
    }
}
