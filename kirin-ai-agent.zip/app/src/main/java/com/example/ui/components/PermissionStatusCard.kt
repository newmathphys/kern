package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeviceReport
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.utils.LocalizationManager
import com.example.utils.SystemPermissionManager

@Composable
fun PermissionStatusSection(
    report: DeviceReport,
    onToggleForeground: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Foreground Service Daemon
        PermissionRow(
            title = if (isRu) "Фоновый демон ИИ-агента" else "Agent Foreground Daemon",
            subtitle = if (isRu) "Непрерывный мониторинг и постоянное уведомление" else "Active notification & real-time monitoring loop",
            isGranted = report.isForegroundServiceRunning,
            icon = Icons.Default.Sync,
            actionLabel = if (report.isForegroundServiceRunning) (if (isRu) "Остановить" else "Stop Daemon") else (if (isRu) "Запустить" else "Start Daemon"),
            onAction = onToggleForeground,
            testTag = "toggle_daemon_btn"
        )

        // Accessibility Service
        PermissionRow(
            title = if (isRu) "Служба автоматизации (Accessibility)" else "Accessibility Automation Service",
            subtitle = if (isRu) "Анализ интерфейса экрана, эмуляция нажатий" else "Screen reading, UI hierarchy inspection, simulated taps",
            isGranted = report.isAccessibilityEnabled,
            icon = Icons.Default.TouchApp,
            actionLabel = if (report.isAccessibilityEnabled) (if (isRu) "Активно" else "Active") else (if (isRu) "Настройки" else "Grant in Settings"),
            onAction = {
                context.startActivity(SystemPermissionManager.createAccessibilitySettingsIntent())
            },
            testTag = "accessibility_perm_btn"
        )

        // Notification Listener
        PermissionRow(
            title = if (isRu) "Перехватчик уведомлений" else "Notification Interceptor Service",
            subtitle = if (isRu) "Чтение системных оповещений и мессенджеров" else "Listens to Telegram, system alerts, and SMS messages",
            isGranted = report.isNotificationListenerEnabled,
            icon = Icons.Default.NotificationsActive,
            actionLabel = if (report.isNotificationListenerEnabled) (if (isRu) "Активно" else "Active") else (if (isRu) "Настройки" else "Grant in Settings"),
            onAction = {
                context.startActivity(SystemPermissionManager.createNotificationListenerSettingsIntent())
            },
            testTag = "notification_perm_btn"
        )

        // Battery Optimization
        PermissionRow(
            title = if (isRu) "Игнорирование оптимизации батареи" else "Ignore Battery Optimizations",
            subtitle = if (isRu) "Предотвращает засыпание службы в режиме Doze" else "Prevents Android Doze mode from freezing daemon",
            isGranted = report.isBatteryOptimizationIgnored,
            icon = Icons.Default.BatteryAlert,
            actionLabel = if (report.isBatteryOptimizationIgnored) (if (isRu) "Разрешено" else "Exempted") else (if (isRu) "Запросить" else "Request Exemption"),
            onAction = {
                context.startActivity(SystemPermissionManager.createIgnoreBatteryOptimizationIntent(context))
            },
            testTag = "battery_perm_btn"
        )

        // Huawei Phone Manager / Startup
        PermissionRow(
            title = if (isRu) "Диспетчер телефона Huawei (EMUI)" else "EMUI Phone Manager (Huawei Startup)",
            subtitle = if (isRu) "Автозапуск, вторичный запуск, работа в фоне" else "Enable: Auto-launch, Secondary launch, Run in background",
            isGranted = false,
            icon = Icons.Default.Security,
            actionLabel = if (isRu) "Открыть диспетчер" else "Open Phone Manager",
            onAction = {
                context.startActivity(SystemPermissionManager.createHuaweiStartupManagerIntent(context))
            },
            testTag = "emui_phone_mgr_btn"
        )
    }
}

@Composable
fun PermissionRow(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    icon: ImageVector,
    actionLabel: String,
    onAction: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isGranted) TechEmerald.copy(alpha = 0.15f) else DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) TechEmerald else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) TechEmerald.copy(alpha = 0.2f) else TechCyan,
                    contentColor = if (isGranted) TechEmerald else DarkBackground
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag(testTag)
            ) {
                Text(actionLabel, fontSize = 11.sp)
            }
        }
    }
}
