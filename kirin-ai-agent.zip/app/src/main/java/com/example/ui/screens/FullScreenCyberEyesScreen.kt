package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.utils.LocalizationManager
import com.example.utils.VoiceHardwareController
import kotlinx.coroutines.delay

@Composable
fun FullScreenCyberEyesScreen(
    isListening: Boolean,
    isTorchOn: Boolean,
    soundAngle: Float,
    soundSourceLabel: String,
    decibels: Float,
    pulseBpm: Int,
    stressIndex: String,
    cpuTempCelsius: Int,
    fps: Int,
    batteryPercent: Int,
    zstdSavingsPercent: Float,
    uptimeSeconds: Long,
    lastSpokenText: String,
    lastRecognizedSpeech: String,
    isMatrixRainActive: Boolean,
    onToggleTorch: () -> Unit,
    onVoiceCommand: (String) -> Unit,
    onToggleListening: (Boolean) -> Unit,
    onToggleMatrixRain: (Boolean) -> Unit,
    onToggleLanguage: () -> Unit,
    onExitFullScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU
    val keyboardController = LocalSoftwareKeyboardController.current

    var textInput by remember { mutableStateOf("") }
    var touchPos by remember { mutableStateOf<Offset?>(null) }

    // Hardware back button exits fullscreen
    BackHandler {
        onExitFullScreen()
    }

    // Natural periodic blinking loop
    var blinkProgress by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay((2400..4200).random().toLong())
            blinkProgress = 1f
            delay(130)
            blinkProgress = 0f
        }
    }

    val animatedBlink by animateFloatAsState(
        targetValue = blinkProgress,
        animationSpec = tween(durationMillis = 90, easing = FastOutLinearInEasing),
        label = "fsBlink"
    )

    // Pulse animation synced with live heart rate
    val infiniteTransition = rememberInfiniteTransition(label = "fsCyberEyes")
    val pulseDurationMs = ((60f / pulseBpm.coerceIn(50, 140)) * 1000).toInt()
    val heartPulseScale by infiniteTransition.animateFloat(
        initialValue = 0.93f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "fsHeartPulse"
    )

    // Ambient glow pulse
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    // Gaze offset: influenced by sound angle or touch drag
    val targetGazeX = if (touchPos != null) {
        // Shift gaze towards touch
        ((touchPos!!.x - 400f) / 400f).coerceIn(-1f, 1f)
    } else {
        (soundAngle / 45f).coerceIn(-1f, 1f)
    }

    val animatedGazeX by animateFloatAsState(
        targetValue = targetGazeX,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "fsGazeX"
    )

    // Format uptime: 00:00:00
    val hours = uptimeSeconds / 3600
    val minutes = (uptimeSeconds % 3600) / 60
    val seconds = uptimeSeconds % 60
    val uptimeString = String.format("%02d:%02d:%02d", hours, minutes, seconds)

    // Quick Voice Commands
    val quickCommands = if (isRu) {
        listOf(
            "Включи фонарик",
            "Выключи фонарик",
            "Сколько батареи?",
            "Замерь пульс",
            "Запусти камеру",
            "Будильник",
            "Калькулятор",
            "Кто ты?",
            "Помощь"
        )
    } else {
        listOf(
            "Turn on flashlight",
            "Turn off flashlight",
            "Battery status",
            "Measure pulse",
            "Open camera",
            "Open alarm",
            "Calculator",
            "Who are you?",
            "Help"
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset -> touchPos = offset },
                    onDrag = { change, _ -> touchPos = change.position },
                    onDragEnd = { touchPos = null }
                )
            }
            .testTag("fullscreen_cyber_eyes_screen")
    ) {
        // Optional Matrix Rain background
        if (isMatrixRainActive) {
            MatrixRainEffect(modifier = Modifier.fillMaxSize())
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // =================================================================
            // 1. TOP HUD BAR: Status, Uptime, Matrix Rain, Language & Exit Button
            // =================================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(TechEmerald)
                    )
                    Text(
                        text = if (isRu) "КИРИН АССИСТЕНТ // HUD" else "KIRIN ASSISTANT // HUD",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TechEmerald,
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Rain toggle
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isMatrixRainActive) TechEmerald.copy(alpha = 0.25f) else Color(0xFF151D28),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isMatrixRainActive) TechEmerald else Color(0xFF263238)),
                        onClick = { onToggleMatrixRain(!isMatrixRainActive) },
                        modifier = Modifier.testTag("fs_matrix_rain_toggle")
                    ) {
                        Text(
                            text = if (isMatrixRainActive) "RAIN: ON" else "RAIN: OFF",
                            fontFamily = FontFamily.Monospace,
                            color = if (isMatrixRainActive) TechEmerald else TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    // Torch toggle
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isTorchOn) TechAmber.copy(alpha = 0.25f) else Color(0xFF151D28),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isTorchOn) TechAmber else Color(0xFF263238)),
                        onClick = onToggleTorch,
                        modifier = Modifier.testTag("fs_torch_toggle")
                    ) {
                        Text(
                            text = if (isTorchOn) "TORCH: ON" else "TORCH: OFF",
                            fontFamily = FontFamily.Monospace,
                            color = if (isTorchOn) TechAmber else TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    // Language toggle badge
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TechCyan.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan),
                        onClick = onToggleLanguage,
                        modifier = Modifier.testTag("fs_lang_toggle")
                    ) {
                        Text(
                            text = if (isRu) "РУС | en" else "рус | ENG",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    // Exit FullScreen Button
                    Button(
                        onClick = onExitFullScreen,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1F2937),
                            contentColor = TechCyan
                        ),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("exit_fullscreen_btn")
                    ) {
                        Icon(Icons.Default.FullscreenExit, contentDescription = "Minimize", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isRu) "СВЕРНУТЬ" else "MINIMIZE", fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Uptime & Keep-Awake Banner
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFF040A10),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = TechCyan, modifier = Modifier.size(13.dp))
                        Text(
                            text = if (isRu) "НЕПРЕРЫВНАЯ РАБОТА: $uptimeString" else "CONTINUOUS UPTIME: $uptimeString",
                            fontFamily = FontFamily.Monospace,
                            color = TechCyan,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "WAKELOCK: 100% [SCREEN AWAKE]",
                        fontFamily = FontFamily.Monospace,
                        color = TechEmerald,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // =================================================================
            // 2. CENTER HERO: GIANT CYBER EYES CANVAS (Fullscreen Focus)
            // =================================================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF010306))
                    .border(1.5.dp, Brush.horizontalGradient(listOf(TechEmerald, TechCyan, TechAmber)), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Giant eye dimensions
                    val eyeRadiusX = w * 0.22f
                    val eyeRadiusY = h * 0.30f
                    val leftEyeCenter = Offset(w * 0.30f, h * 0.48f)
                    val rightEyeCenter = Offset(w * 0.70f, h * 0.48f)

                    val eyeCenters = listOf(leftEyeCenter, rightEyeCenter)

                    for (center in eyeCenters) {
                        // Sclera / Outer Cyber Eye Socket
                        drawOval(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF0F2236), Color(0xFF040A12), Color(0xFF000306)),
                                center = center,
                                radius = eyeRadiusX * 1.35f
                            ),
                            topLeft = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY),
                            size = Size(eyeRadiusX * 2, eyeRadiusY * 2)
                        )

                        // Outer Glowing Cyber Arc (Neon Sweep)
                        drawOval(
                            brush = Brush.sweepGradient(
                                colors = listOf(TechEmerald, TechCyan, TechAmber, TechPurple, TechEmerald),
                                center = center
                            ),
                            topLeft = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY),
                            size = Size(eyeRadiusX * 2, eyeRadiusY * 2),
                            style = Stroke(width = 3.5f)
                        )

                        // Inner Reticle Dashed Ring
                        drawOval(
                            brush = Brush.radialGradient(
                                colors = listOf(TechCyan.copy(alpha = 0.4f), Color.Transparent),
                                center = center,
                                radius = eyeRadiusX * 0.85f
                            ),
                            topLeft = Offset(center.x - eyeRadiusX * 0.85f, center.y - eyeRadiusY * 0.85f),
                            size = Size(eyeRadiusX * 1.7f, eyeRadiusY * 1.7f),
                            style = Stroke(width = 1.5f)
                        )

                        // Iris with Gaze Shift (sound / touch tracked)
                        val maxShiftX = eyeRadiusX * 0.38f
                        val gazeShift = animatedGazeX * maxShiftX
                        val irisCenter = Offset(center.x + gazeShift, center.y)
                        val irisRadius = eyeRadiusX * 0.58f * heartPulseScale

                        // Iris Radial Color Glow
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = if (isListening) listOf(Color.White, TechCyan, Color(0xFF003853))
                                else listOf(Color(0xFFE8FFF6), TechEmerald, Color(0xFF004933)),
                                center = irisCenter,
                                radius = irisRadius
                            ),
                            center = irisCenter,
                            radius = irisRadius
                        )

                        // Pupil (Dilates when listening or analyzing)
                        val pupilRadius = if (isListening) irisRadius * 0.55f else irisRadius * 0.36f
                        drawCircle(
                            color = Color(0xFF01050A),
                            center = irisCenter,
                            radius = pupilRadius
                        )

                        // High-tech cyber reticle crosshair in pupil
                        drawLine(
                            color = TechCyan.copy(alpha = 0.6f),
                            start = Offset(irisCenter.x - pupilRadius * 0.7f, irisCenter.y),
                            end = Offset(irisCenter.x + pupilRadius * 0.7f, irisCenter.y),
                            strokeWidth = 1.2f
                        )
                        drawLine(
                            color = TechCyan.copy(alpha = 0.6f),
                            start = Offset(irisCenter.x, irisCenter.y - pupilRadius * 0.7f),
                            end = Offset(irisCenter.x, irisCenter.y + pupilRadius * 0.7f),
                            strokeWidth = 1.2f
                        )

                        // Cyber Specular Glint
                        drawCircle(
                            color = Color.White.copy(alpha = 0.9f),
                            center = Offset(irisCenter.x - pupilRadius * 0.42f, irisCenter.y - pupilRadius * 0.42f),
                            radius = pupilRadius * 0.32f
                        )

                        // Eyelid Blink Overlay
                        if (animatedBlink > 0.01f) {
                            val blinkHeight = eyeRadiusY * 2 * animatedBlink
                            drawRect(
                                color = Color(0xFF010204),
                                topLeft = Offset(center.x - eyeRadiusX - 4f, center.y - eyeRadiusY - 2f),
                                size = Size(eyeRadiusX * 2 + 8f, blinkHeight)
                            )
                            drawLine(
                                color = TechEmerald,
                                start = Offset(center.x - eyeRadiusX, center.y - eyeRadiusY + blinkHeight),
                                end = Offset(center.x + eyeRadiusX, center.y - eyeRadiusY + blinkHeight),
                                strokeWidth = 3f,
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    // Equalizer Mouth Wave beneath the eyes (audio activity)
                    val mouthY = h * 0.88f
                    val mouthCenter = w * 0.5f
                    val waveBars = 21
                    val barWidth = 4f
                    val spacing = 8f
                    val startX = mouthCenter - (waveBars * (barWidth + spacing)) / 2f
                    val normDb = ((decibels - 30f) / 50f).coerceIn(0.12f, 1f)

                    for (i in 0 until waveBars) {
                        val barH = (normDb * 26f * (1f - (Math.abs(i - waveBars / 2f) / (waveBars / 2f)) * 0.55f)).coerceAtLeast(3f)
                        val x = startX + i * (barWidth + spacing)
                        drawLine(
                            color = if (isListening) TechCyan else TechEmerald,
                            start = Offset(x, mouthY - barH / 2f),
                            end = Offset(x, mouthY + barH / 2f),
                            strokeWidth = barWidth,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Gaze & State Status Labels over the Eyes Canvas
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Assistant State: Waiting for voice vs Speaking
                    val stateText = when {
                        isListening -> if (isRu) "🔴 СЛУШАЮ ГОЛОС... ГОВОРИТЕ" else "🔴 LISTENING TO VOICE... SPEAK NOW"
                        lastSpokenText.isNotBlank() && !lastSpokenText.contains("Готов") -> if (isRu) "🔊 ОТВЕТ АССИСТЕНТА" else "🔊 ASSISTANT RESPONSE"
                        else -> if (isRu) "👁️ ЖДУ ГОЛОСОВУЮ КОМАНДУ" else "👁️ STANDING BY FOR VOICE"
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isListening) TechCyan else TechEmerald.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = stateText,
                            fontFamily = FontFamily.Monospace,
                            color = if (isListening) TechCyan else TechEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    val gazeDesc = when {
                        soundAngle < -15f -> if (isRu) "Фокус: ВЛЕВО (-${Math.abs(soundAngle.toInt())}°)" else "Focus: LEFT (-${Math.abs(soundAngle.toInt())}°)"
                        soundAngle > 15f -> if (isRu) "Фокус: ВПРАВО (+${soundAngle.toInt()}°)" else "Focus: RIGHT (+${soundAngle.toInt()}°)"
                        else -> if (isRu) "Фокус: ПО ЦЕНТРУ" else "Focus: CENTER"
                    }
                    Text(
                        text = gazeDesc,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // =================================================================
            // 3. INFORMATION / SPEECH SUBTITLE BOX ("Дает информацию")
            // =================================================================
            Card(
                modifier = Modifier.fillMaxWidth().testTag("fs_speech_subtitle_card"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF040810)),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isListening) TechCyan else TechEmerald.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isRu) "ПОТОК ДАННЫХ И ОТВЕТОВ:" else "LIVE DATA & VOICE STREAM:",
                            fontFamily = FontFamily.Monospace,
                            color = TechCyan,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${decibels.toInt()} dB",
                            fontFamily = FontFamily.Monospace,
                            color = TechAmber,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Display what was spoken or recognized
                    val displayText = when {
                        lastRecognizedSpeech.isNotBlank() && isListening -> "> Распознано: \"$lastRecognizedSpeech\""
                        lastSpokenText.isNotBlank() -> "> $lastSpokenText"
                        else -> if (isRu) "> Ассистент готов к приему команд. Скажите команду или нажмите кнопку."
                        else "> Assistant standing by for commands. Speak or tap microphone."
                    }

                    Text(
                        text = displayText,
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // =================================================================
            // 4. LIVE SYSTEM TELEMETRY HUD (All indicators continuously active)
            // =================================================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FsTelemetryPill(
                    icon = Icons.Default.Favorite,
                    label = if (isRu) "ПУЛЬС" else "PULSE",
                    value = "$pulseBpm BPM",
                    color = TechRed,
                    modifier = Modifier.weight(1f)
                )
                FsTelemetryPill(
                    icon = Icons.Default.Speed,
                    label = "KIRIN",
                    value = "$cpuTempCelsius°C",
                    color = TechCyan,
                    modifier = Modifier.weight(1f)
                )
                FsTelemetryPill(
                    icon = Icons.Default.Tv,
                    label = "GPU",
                    value = "$fps FPS",
                    color = TechEmerald,
                    modifier = Modifier.weight(1f)
                )
                FsTelemetryPill(
                    icon = Icons.Default.BatteryChargingFull,
                    label = if (isRu) "АКБ" else "BATT",
                    value = "$batteryPercent%",
                    color = TechAmber,
                    modifier = Modifier.weight(1f)
                )
                FsTelemetryPill(
                    icon = Icons.Default.SdCard,
                    label = "ZSTD",
                    value = "${zstdSavingsPercent.toInt()}%",
                    color = TechPurple,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // =================================================================
            // 5. QUICK VOICE COMMAND CHIPS
            // =================================================================
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(quickCommands) { cmd ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF091420),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan.copy(alpha = 0.4f)),
                        onClick = { onVoiceCommand(cmd) }
                    ) {
                        Text(
                            text = cmd,
                            fontFamily = FontFamily.Monospace,
                            color = TechCyan,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // =================================================================
            // 6. MICROPHONE & COMMAND INPUT ROW
            // =================================================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Large Glowing Microphone Button
                Button(
                    onClick = {
                        if (isListening) {
                            VoiceHardwareController.stopListening()
                            onToggleListening(false)
                        } else {
                            VoiceHardwareController.startListening(context) { recognized ->
                                onVoiceCommand(recognized)
                            }
                            onToggleListening(true)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isListening) TechRed else TechEmerald,
                        contentColor = Color.Black
                    ),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("fs_mic_btn")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Text Input Bar
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = if (isRu) "Введите команду или скажите вслух..." else "Type command or speak...",
                            fontFamily = FontFamily.Monospace,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("fs_text_command_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TechEmerald,
                        unfocusedBorderColor = Color(0xFF1E293B),
                        focusedContainerColor = Color(0xFF03070E),
                        unfocusedContainerColor = Color(0xFF03070E),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (textInput.isNotBlank()) {
                                onVoiceCommand(textInput.trim())
                                textInput = ""
                                keyboardController?.hide()
                            }
                        }
                    )
                )

                // Send Button
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onVoiceCommand(textInput.trim())
                            textInput = ""
                            keyboardController?.hide()
                        }
                    },
                    modifier = Modifier.testTag("fs_send_command_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = TechEmerald,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FsTelemetryPill(
    icon: ImageVector,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF040810),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(11.dp))
                Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = color, fontWeight = FontWeight.Bold)
            }
            Text(text = value, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
    }
}
