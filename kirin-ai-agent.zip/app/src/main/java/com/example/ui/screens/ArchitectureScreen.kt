package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArchitectureBlueprint
import com.example.model.ArchitectureLayer
import com.example.ui.theme.*

@Composable
fun ArchitectureScreen(modifier: Modifier = Modifier) {
    var selectedSection by remember { mutableStateOf(0) }
    val sectionTitles = listOf("4-Tier Stack", "Archivist & Dispatcher", "Kernel & NDK C++", "EMUI & PowerGenie", "GPU / Mali-G51", "Treble / GSI")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedSection,
            containerColor = DarkCard,
            contentColor = TechCyan,
            edgePadding = 16.dp,
            divider = {}
        ) {
            sectionTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSection == index,
                    onClick = { selectedSection = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            color = if (selectedSection == index) TechCyan else TextSecondary
                        )
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
        ) {
            when (selectedSection) {
                0 -> {
                    // 4-Tier System Stack Overview
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.AccountTree, contentDescription = null, tint = TechCyan)
                                    Text(
                                        text = "AI-Agent 4-Tier System Stack",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TechCyan
                                    )
                                }
                                Text(
                                    text = "To achieve full autonomous operation on Huawei Nova Y61 (Kirin 710A) and generic Android devices, the software stack is partitioned into 4 distinct security and execution boundaries.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    items(ArchitectureBlueprint.layers, key = { it.tier }) { layer ->
                        LayerCard(layer = layer)
                    }
                }

                1 -> {
                    // AI Archivist & Dispatcher
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "AI Archivist & Resource Dispatcher Concept",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TechCyan
                                )
                                Text(
                                    text = "Kirin 710A cannot train heavy neural networks locally. Instead, the phone operates as a high-efficiency 'Digital Archivist' while the external Gemini model acts as the learning engine.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Text(text = "Core Pillars of the Archivist Pipeline:", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                                MitigationBullet(
                                    title = "1. Three-Tier Memory Lifecycle",
                                    desc = "Hot Tier (RAM buffer with mlockall) -> Warm Tier (Room SQLite DB) -> Cold Tier (Night-time compressed GZIP JSON dataset package for Gemini training)."
                                )
                                MitigationBullet(
                                    title = "2. Semantic Deduplication & Hash Diffing",
                                    desc = "Computes text diff hashes on screen trees. Static UI elements and unchanged frames are dropped, saving over 90% flash I/O and preventing 14nm thermal throttling."
                                )
                                MitigationBullet(
                                    title = "3. Privacy Blind-Spot Shield",
                                    desc = "Automatically masks banking apps, crypto wallets, password managers, and credential fields before ingestion."
                                )
                                MitigationBullet(
                                    title = "4. Process Zoning (Hot / Warm / Cold Zones)",
                                    desc = "Hot Zone: Frequently cycled apps (Telegram/Viber) kept pinned in RAM. Warm Zone: Utility tools suspended via cgroups v2. Cold Zone: Background trackers pruned immediately."
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // C++ NDK Kernel Layer & Syscalls
                    item {
                        CodeCard(
                            title = "1. Kirin 710A Big-Core Affinity (C++ NDK)",
                            description = "Binds execution threads to Cortex-A73 Big-core cluster (cores 4-7) via sched_setaffinity, preventing core-hopping onto slow A53 cores.",
                            codeSnippet = """
#include <jni.h>
#include <sched.h>
#include <sys/mman.h>
#include <unistd.h>

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_utils_NativeHardwareController_optimizeForKirin(
    JNIEnv* env, jobject /* this */) {

    // Kirin 710A Core Affinity:
    // Cores 0-3: Cortex-A53 (LITTLE)
    // Cores 4-7: Cortex-A73 (BIG)
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(4, &cpuset);
    CPU_SET(5, &cpuset);
    CPU_SET(6, &cpuset);
    CPU_SET(7, &cpuset);

    pid_t tid = gettid();
    if (sched_setaffinity(tid, sizeof(cpu_set_t), &cpuset) == -1) {
        return JNI_FALSE;
    }

    // Lock memory pages against EMUI LowMemoryKiller eviction
    mlockall(MCL_CURRENT | MCL_FUTURE);

    return JNI_TRUE;
}
                            """.trimIndent()
                        )
                    }

                    item {
                        CodeCard(
                            title = "2. Real-Time Priorities & cgroups v2 (Scheduler Governance)",
                            description = "Boosts Linux process priority to maximum or requests SCHED_SP_TOP_APP profile via libprocessgroup.",
                            codeSnippet = """
#include <sys/resource.h>
#include <sched.h>

// Raise priority to highest for normal processes (-20)
setpriority(PRIO_PROCESS, 0, -20);

// Request real-time FIFO scheduler (if privileged/root)
struct sched_param param;
param.sched_priority = 99;
sched_setscheduler(gettid(), SCHED_FIFO, &param);

// Or via Android libprocessgroup.so:
// SetTaskProfiles(gettid(), {"SCHED_SP_TOP_APP"}, true);
                            """.trimIndent()
                        )
                    }

                    item {
                        CodeCard(
                            title = "3. Dual-Process Watchdog Daemon (Forking)",
                            description = "Spawns an independent Linux daemon via fork() that monitors and revives the Kotlin service if killed.",
                            codeSnippet = """
#include <unistd.h>
#include <sys/types.h>

void startWatchdogDaemon() {
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid > 0) _exit(0); // Exit parent

    if (setsid() < 0) _exit(0); // Detach terminal session

    pid = fork();
    if (pid < 0) return;
    if (pid > 0) _exit(0); // Detach child, leaving persistent daemon

    while (true) {
        // Heartbeat monitor: checks if Kotlin service is alive
        sleep(5);
    }
}
                            """.trimIndent()
                        )
                    }
                }

                3 -> {
                    // EMUI & PowerGenie Survival
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "EMUI 12 PowerGenie & IAware Immunity",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TechAmber
                                )
                                Text(
                                    text = "Huawei EMUI firmware incorporates 'PowerGenie' and 'IAware' daemons that send SIGKILL (signal 9) to background services regardless of standard battery whitelist.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Text(text = "The 4-Layer Immunity Shield:", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                                MitigationBullet(
                                    title = "1. Silent AudioTrack Keep-Alive",
                                    desc = "Cyclically outputs a silent PCM buffer. On Android/EMUI, active media audio output grants the process top audio priority, making it immune to PowerGenie SIGKILL."
                                )
                                MitigationBullet(
                                    title = "2. Foreground Service + Ongoing Notification",
                                    desc = "Lowers Linux OOM score from cached (900+) to foreground service (200)."
                                )
                                MitigationBullet(
                                    title = "3. REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
                                    desc = "Exempts app from standard Android PowerManager Doze maintenance windows."
                                )
                                MitigationBullet(
                                    title = "4. Phone Manager 'Manual Launch'",
                                    desc = "User enables: Auto-launch on boot, Secondary launch from other apps, and Run in background."
                                )
                            }
                        }
                    }
                }

                4 -> {
                    // GPU / Mali-G51 & NPU Acceleration
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "GPU (ARM Mali-G51 MP4) & NPU Inference",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TechCyan
                                )
                                Text(
                                    text = "Running local neural nets on Cortex-A73 CPU cores causes severe thermal throttling on the 14nm Kirin 710A. Offloading to Mali-G51 GPU yields 400% speedup and keeps the device cool.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Text(text = "Recommended Lightweight AI Engines:", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                                MitigationBullet(
                                    title = "Alibaba MNN / Huawei Bolt",
                                    desc = "Lightweight embedded AI inference engines specifically optimized for ARM Mali GPUs via OpenCL and Vulkan (MNN_FORWARD_OPENCL)."
                                )
                                MitigationBullet(
                                    title = "INT8 and FP16 Quantization",
                                    desc = "Reduces model footprint from 4GB to 500MB, cutting RAM bandwidth by 75% and preventing EMUI Low Memory Killer triggers."
                                )
                                MitigationBullet(
                                    title = "Adaptive Thermal Migration",
                                    desc = "When temperature reaches 55°C, compute tasks dynamically shift to Cortex-A53 cores for 8 seconds, avoiding harsh hardware step-drop throttling."
                                )
                            }
                        }
                    }
                }

                5 -> {
                    // Project Treble & GSI on Kirin 710A
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "Project Treble & GSI Partition Mapping",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TechCyan
                                )
                                Text(
                                    text = "Huawei Nova Y61 (EVE-LX9N) supports Project Treble (ro.treble.enabled=true). This decouples the generic Android framework (/system) from HiSilicon Kirin 710A hardware drivers (/vendor).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Text(text = "Key Engineering Boundaries:", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                                MitigationBullet(
                                    title = "Partition Layout Check (ro.build.ab_update)",
                                    desc = "Nova Y61 uses System-as-Root with AB partition layout. Flashing requires an ARM64_ab GSI image."
                                )
                                MitigationBullet(
                                    title = "Hardware TestPoint (USB COM 1.0 EDL)",
                                    desc = "Because Huawei bootloader codes are discontinued, unlocking requires grounding the service TestPoint on the board, uploading patched xloader via SigmaPlus/HCU."
                                )
                                MitigationBullet(
                                    title = "Phh-Treble & LineageOS Kirin Patches",
                                    desc = "Use Phh-Treble or LineageOS GSI containing HiSilicon Mali-G51 and RIL modem compatibility patches to avoid graphical or call drops."
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LayerCard(layer: ArchitectureLayer) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (layer.tier) {
                        1 -> TechPurple.copy(alpha = 0.2f)
                        2 -> TechCyan.copy(alpha = 0.2f)
                        3 -> TechAmber.copy(alpha = 0.2f)
                        else -> TechEmerald.copy(alpha = 0.2f)
                    }
                ) {
                    Text(
                        text = "TIER ${layer.tier}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = when (layer.tier) {
                            1 -> TechPurple
                            2 -> TechCyan
                            3 -> TechAmber
                            else -> TechEmerald
                        }
                    )
                }

                Text(
                    text = layer.securityLevel,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Text(text = layer.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Text(text = layer.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, lineHeight = 18.sp)

            HorizontalDivider(color = DarkSurfaceVariant)

            Text(text = "Key Components:", style = MaterialTheme.typography.labelSmall, color = TechCyan)
            layer.components.forEach { comp ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(modifier = Modifier.size(5.dp).clip(RoundedCornerShape(3.dp)).background(TechCyan))
                    Text(text = comp, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 12.sp)
                }
            }

            if (layer.emuiSpecificNotes.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = TechAmber, modifier = Modifier.size(16.dp))
                        Text(text = layer.emuiSpecificNotes, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeCard(title: String, description: String, codeSnippet: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = TechCyan)
            Text(text = description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 12.sp)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = DarkSurface
            ) {
                Text(
                    text = codeSnippet,
                    modifier = Modifier.padding(12.dp),
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = TextPrimary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun MitigationBullet(title: String, desc: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = title, style = MaterialTheme.typography.labelMedium, color = TechCyan, fontSize = 12.sp)
        Text(text = desc, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
    }
}
