package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeviceReport
import com.example.services.CapturedNotification
import com.example.ui.components.PermissionStatusSection
import com.example.ui.theme.*
import com.example.utils.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PermissionsScreen(
    report: DeviceReport?,
    capturedNotifications: List<CapturedNotification>,
    onToggleForeground: () -> Unit,
    // Device Owner & Kiosk
    isDeviceOwner: Boolean = false,
    isAdminActive: Boolean = false,
    isKioskMode: Boolean = false,
    systemShellLocked: Boolean = false,
    onToggleKiosk: (Boolean) -> Unit = {},
    onLockSystemShell: (Boolean) -> Unit = {},
    // Debloater UAD-NG
    debloatPackages: List<DebloatPackage> = emptyList(),
    debloatStatusSummary: String = "",
    onTogglePackageFreeze: (String, Boolean) -> Unit = { _, _ -> },
    onFreezeAllTelemetry: () -> Unit = {},
    onRestoreAllPackages: () -> Unit = {},
    onExportBullDozerScript: () -> String = { "" },
    // Cellular Security & IMSI Catcher
    cellTowers: List<CellTowerInfo> = emptyList(),
    threatLevel: CellularThreatLevel = CellularThreatLevel.SECURE,
    cellularAuditSummary: String = "",
    onAuditCellular: () -> Unit = {},
    // MindSpore Lite & HiAI
    isNpuDetected: Boolean = true,
    hiaiStatus: String = "",
    mindSporeStatus: String = "",
    npuBenchmark: NpuBenchmarkResult? = null,
    onRunNpuBenchmark: (String) -> Unit = {},
    // Shizuku & Evolution
    isShizukuActive: Boolean = true,
    evolutionManifest: EvolutionUpgradeManifest? = null,
    onTriggerEvolution: () -> Unit = {},
    onExecuteElevatedCommand: (String) -> String = { "" },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    var selectedTab by remember { mutableIntStateOf(0) }
    var showScriptDialog by remember { mutableStateOf(false) }
    var scriptContent by remember { mutableStateOf("") }
    var elevatedCommandInput by remember { mutableStateOf("pm list packages -e") }
    var elevatedCommandOutput by remember { mutableStateOf("") }

    val tabs = if (isRu) listOf(
        "Права & EMUI",
        "Device Owner & Kiosk",
        "Деблоатер UAD-NG",
        "IMSI Guard",
        "MindSpore & NPU"
    ) else listOf(
        "Permissions & EMUI",
        "Device Owner & Kiosk",
        "Debloater UAD-NG",
        "IMSI Guard",
        "MindSpore & NPU"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top Sub-Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = TechCyan,
            edgePadding = 12.dp,
            divider = { HorizontalDivider(color = DarkSurfaceVariant) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) TechCyan else TextMuted
                        )
                    },
                    modifier = Modifier.testTag("perm_tab_$index")
                )
            }
        }

        when (selectedTab) {
            // TAB 0: EMUI SURVIVAL & SYSTEM PERMISSIONS
            0 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = TechAmber, modifier = Modifier.size(22.dp))
                                    Text(
                                        text = if (isRu) "Руководство выживания в фоне EMUI 12" else "EMUI 12 Background Survival Guide",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TechAmber
                                    )
                                }

                                Text(
                                    text = if (isRu)
                                        "Прошивка Huawei EMUI содержит алгоритм 'PowerGenie', принудительно завершающий фоновые процессы. Для защиты ИИ-ассистента:"
                                    else
                                        "Huawei EMUI includes aggressive 'PowerGenie' and 'Phone Manager' background killers. To keep your AI Agent daemon running:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StepItem(
                                        number = "1",
                                        text = if (isRu) "Запустите фоновую службу Foreground Daemon (показывает уведомление)."
                                        else "Start Foreground Service daemon (shows ongoing notification)."
                                    )
                                    StepItem(
                                        number = "2",
                                        text = if (isRu) "Предоставьте 'Игнорировать оптимизацию батареи' для предотвращения сна."
                                        else "Grant 'Ignore Battery Optimizations' to bypass system sleep."
                                    )
                                    StepItem(
                                        number = "3",
                                        text = if (isRu) "Диспетчер телефона -> Запуск приложений -> Управление вручную."
                                        else "Open EMUI Phone Manager -> App Launch -> Select 'Manage Manually'."
                                    )
                                }
                            }
                        }
                    }

                    if (report != null) {
                        item {
                            PermissionStatusSection(report = report, onToggleForeground = onToggleForeground)
                        }
                    }

                    if (capturedNotifications.isNotEmpty()) {
                        item {
                            Text(
                                text = if (isRu) "История перехваченных уведомлений (${capturedNotifications.size})" else "Captured Notifications History (${capturedNotifications.size})",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                        }

                        items(capturedNotifications.take(8)) { notif ->
                            NotificationHistoryCard(notif = notif)
                        }
                    }
                }
            }

            // TAB 1: DEVICE OWNER & SYSTEM SHELL LOCKDOWN
            1 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = TechCyan, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = if (isRu) "Управление Device Owner & Kiosk" else "Device Owner & Kiosk Governance",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TechCyan,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isRu) "Полная блокировка оболочки EMUI, статус-бара и жестов" else "Complete lockdown of EMUI shell, status bar, and keyguard",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    GovernancePill(
                                        label = "Device Owner",
                                        value = if (isDeviceOwner) "ACTIVE" else "NOT SET",
                                        tint = if (isDeviceOwner) TechEmerald else TechAmber
                                    )
                                    GovernancePill(
                                        label = "Device Admin",
                                        value = if (isAdminActive) "ACTIVE" else "DISABLED",
                                        tint = if (isAdminActive) TechEmerald else TextMuted
                                    )
                                    GovernancePill(
                                        label = "Kiosk Mode",
                                        value = if (isKioskMode) "LOCKED" else "OFF",
                                        tint = if (isKioskMode) TechCyan else TextMuted
                                    )
                                }
                            }
                        }
                    }

                    // Shell Lockdown Toggles
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = if (isRu) "🔒 Блокировка системной оболочки" else "🔒 System Shell Lockdown",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = if (isRu) "Режим Киоска (LockTaskMode)" else "Kiosk LockTaskMode", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                        Text(text = if (isRu) "Фиксирует Kirin AI Agent на экране, блокирует кнопку Домой и шторку" else "Pins app to screen, disables Home button & notification shade", color = TextSecondary, fontSize = 10.sp)
                                    }
                                    Switch(
                                        checked = isKioskMode,
                                        onCheckedChange = { onToggleKiosk(it) },
                                        modifier = Modifier.testTag("toggle_kiosk_switch")
                                    )
                                }

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = if (isRu) "Заблокировать экран блокировки" else "Disable Keyguard & System UI", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                        Text(text = if (isRu) "Отключает виджеты экрана блокировки и доступ к камере" else "Disables keyguard features & unauthenticated widgets", color = TextSecondary, fontSize = 10.sp)
                                    }
                                    Switch(
                                        checked = systemShellLocked,
                                        onCheckedChange = { onLockSystemShell(it) },
                                        modifier = Modifier.testTag("toggle_shell_lock_switch")
                                    )
                                }
                            }
                        }
                    }

                    // ADB Command Instruction Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = if (isRu) "Команда активации Device Owner через ПК / ADB:" else "Activate Device Owner via PC / ADB Command:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TechCyan,
                                    fontWeight = FontWeight.Bold
                                )

                                val cmd = "adb shell dpm set-device-owner com.example/.services.KirinDeviceAdminReceiver"
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = DarkBackground,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = cmd,
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                            color = TechEmerald,
                                            fontSize = 10.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(onClick = {
                                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            cm.setPrimaryClip(ClipData.newPlainText("ADB Command", cmd))
                                        }) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TechCyan, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 2: UNIVERSAL ANDROID DEBLOATER (UAD-NG & BULLDOZER)
            2 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = TechEmerald, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = "Universal Android Debloater (UAD-NG / BullDozer)",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TechEmerald,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isRu) "Безопасная заморозка телеметрии и предустановленных сервисов EMUI" else "Safe disabling of Huawei telemetry & OEM bloatware",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Text(
                                    text = debloatStatusSummary,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TechCyan,
                                    fontSize = 11.sp
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = onFreezeAllTelemetry,
                                        modifier = Modifier.weight(1f).testTag("freeze_all_telemetry_btn"),
                                        colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = DarkBackground),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(text = if (isRu) "Заморозить всю слежку" else "Debloat Telemetry", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            scriptContent = onExportBullDozerScript()
                                            showScriptDialog = true
                                        },
                                        modifier = Modifier.weight(1f).testTag("export_bulldozer_btn"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TechCyan)
                                    ) {
                                        Text(text = if (isRu) "Скрипт BullDozer .sh" else "BullDozer Script", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = if (isRu) "Пакеты прошивки Huawei EMUI (${debloatPackages.size})" else "Huawei EMUI Bloatware Packages (${debloatPackages.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(debloatPackages, key = { it.packageName }) { pkg ->
                        DebloatPackageCard(
                            pkg = pkg,
                            isRu = isRu,
                            onToggle = { freeze -> onTogglePackageFreeze(pkg.packageName, freeze) }
                        )
                    }
                }
            }

            // TAB 3: IMSI GUARD & CELL TOWER AUDITOR
            3 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    item {
                        val threatColor = when (threatLevel) {
                            CellularThreatLevel.SECURE -> TechEmerald
                            CellularThreatLevel.ELEVATED_RISK -> TechAmber
                            CellularThreatLevel.ROGUE_TOWER_DETECTED -> TechRed
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CellTower, contentDescription = null, tint = threatColor, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = if (isRu) "IMSI-Catcher & Cell Security Guard" else "IMSI-Catcher & Base Station Guard",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = threatColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isRu) "Мониторинг базовых станций, шифрования и атак даунгрейда" else "Rogue tower detection, 2G downgrade protection & cipher checks",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = threatColor.copy(alpha = 0.15f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = cellularAuditSummary,
                                        modifier = Modifier.padding(10.dp),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = threatColor,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp
                                    )
                                }

                                Button(
                                    onClick = onAuditCellular,
                                    modifier = Modifier.fillMaxWidth().testTag("scan_cell_towers_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Radar, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = if (isRu) "Сканировать вышки связи (Telephony)" else "Scan Cell Towers", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = if (isRu) "Обнаруженные соты (${cellTowers.size})" else "Detected Cell Towers (${cellTowers.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(cellTowers) { tower ->
                        CellTowerCard(tower = tower, isRu = isRu)
                    }
                }
            }

            // TAB 4: MINDSPORE LITE & HIAI NPU + SHIZUKU EVOLUTION
            4 -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)
                ) {
                    // MindSpore & HiAI Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Memory, contentDescription = null, tint = TechPurple, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text(
                                            text = "MindSpore Lite & HiAI Foundation NPU",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TechPurple,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Kirin 710A DaVinci NPU Lite & Mali-G51 GPU OpenCL Acceleration",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = DarkSurfaceVariant)

                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(text = "• HiAI DDK: $hiaiStatus", color = TextPrimary, fontSize = 11.sp)
                                    Text(text = "• MindSpore Runtime: $mindSporeStatus", color = TextPrimary, fontSize = 11.sp)
                                    Text(text = "• NPU Topology: 1x DaVinci Core (0.5 TOPS INT8 / 1.0 TFLOPS FP16)", color = TechEmerald, fontSize = 11.sp)
                                }

                                if (npuBenchmark != null) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = DarkSurface,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "Throughput: ${npuBenchmark.throughputGflops} GFLOPS", color = TechCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            Text(text = "Latency: ${npuBenchmark.inferenceTimeMs} ms", color = TechEmerald, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            Text(text = "Bandwidth: ${npuBenchmark.memoryBandwidthGbps} GB/s", color = TechAmber, fontSize = 11.sp)
                                        }
                                    }
                                }

                                Button(
                                    onClick = { onRunNpuBenchmark("FP16") },
                                    modifier = Modifier.fillMaxWidth().testTag("run_npu_benchmark_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = TechPurple, contentColor = TextPrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = if (isRu) "Запустить тест NPU / GPU GEMM" else "Run NPU Benchmark", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Shizuku & PC Evolution Bridge
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.SyncAlt, contentDescription = null, tint = TechCyan, modifier = Modifier.size(22.dp))
                                    Column {
                                        Text(text = if (isRu) "Shizuku & PC Symbiosis (Self-Evolution)" else "Shizuku & PC Self-Evolution", style = MaterialTheme.typography.titleMedium, color = TechCyan)
                                        Text(text = "ADB Port 5037 / 5555 OTA Hot Update Bridge", color = TextSecondary, fontSize = 10.sp)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = onTriggerEvolution,
                                        modifier = Modifier.weight(1f).testTag("trigger_evolution_btn"),
                                        colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Upgrade, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = if (isRu) "Обновить / Эволюция" else "Sync Evolution", fontSize = 11.sp)
                                    }
                                }

                                if (evolutionManifest != null && evolutionManifest.evolutionLog.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = DarkBackground,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            evolutionManifest.evolutionLog.take(4).forEach { line ->
                                                Text(text = line, color = TechEmerald, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                }

                                // Elevated Shell Tester
                                OutlinedTextField(
                                    value = elevatedCommandInput,
                                    onValueChange = { elevatedCommandInput = it },
                                    label = { Text("Shizuku Elevated Shell", fontSize = 10.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            elevatedCommandOutput = onExecuteElevatedCommand(elevatedCommandInput)
                                        }) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = TechEmerald)
                                        }
                                    }
                                )

                                if (elevatedCommandOutput.isNotBlank()) {
                                    Text(text = elevatedCommandOutput, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showScriptDialog) {
        AlertDialog(
            onDismissRequest = { showScriptDialog = false },
            containerColor = DarkCard,
            title = { Text(text = "BullDozer / UAD-NG Shell Script", color = TechCyan) },
            text = {
                OutlinedTextField(
                    value = scriptContent,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().height(240.dp),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("BullDozerScript", scriptContent))
                        showScriptDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground)
                ) {
                    Text(text = "Copy Script")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScriptDialog = false }) { Text("Close", color = TextMuted) }
            }
        )
    }
}

@Composable
private fun DebloatPackageCard(
    pkg: DebloatPackage,
    isRu: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = pkg.label, style = MaterialTheme.typography.labelLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (pkg.isFrozen) TechRed.copy(alpha = 0.15f) else TechEmerald.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (pkg.isFrozen) "FROZEN" else "ACTIVE",
                            color = if (pkg.isFrozen) TechRed else TechEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(text = pkg.packageName, style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
                Text(text = pkg.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
            }

            Switch(
                checked = pkg.isFrozen,
                onCheckedChange = { onToggle(it) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = TechRed,
                    checkedTrackColor = TechRed.copy(alpha = 0.3f)
                )
            )
        }
    }
}

@Composable
private fun CellTowerCard(
    tower: CellTowerInfo,
    isRu: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = tower.radioType, style = MaterialTheme.typography.labelLarge, color = if (tower.isSuspicious) TechRed else TechCyan, fontWeight = FontWeight.Bold)
                    if (tower.isRegistered) {
                        Surface(shape = RoundedCornerShape(4.dp), color = TechEmerald.copy(alpha = 0.15f)) {
                            Text(text = "SERVING", color = TechEmerald, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                }

                Text(text = "${tower.signalDbm} dBm", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Text(
                text = "CID: ${tower.cellId} • TAC/LAC: ${tower.tacOrLac} • MCC/MNC: ${tower.mcc}-${tower.mnc}",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = if (tower.isSuspicious) TechRed.copy(alpha = 0.15f) else TechEmerald.copy(alpha = 0.1f)
            ) {
                Text(
                    text = "Security: ${tower.securityAssessment}",
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = if (tower.isSuspicious) TechRed else TechEmerald,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun GovernancePill(
    label: String,
    value: String,
    tint: Color
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = DarkSurface,
        modifier = Modifier.width(96.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
            Text(text = value, style = MaterialTheme.typography.titleSmall, color = tint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StepItem(number: String, text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(4.dp),
            color = TechAmber.copy(alpha = 0.2f),
            modifier = Modifier.size(18.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = number,
                    style = MaterialTheme.typography.labelSmall,
                    color = TechAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary,
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun NotificationHistoryCard(notif: CapturedNotification) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(notif.postTime))
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.Notifications, contentDescription = null, tint = TechCyan, modifier = Modifier.size(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = notif.appLabel, style = MaterialTheme.typography.labelMedium, color = TechCyan)
                    Text(text = timeStr, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
                if (notif.title.isNotBlank()) {
                    Text(text = notif.title, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                if (notif.text.isNotBlank()) {
                    Text(text = notif.text, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 2)
                }
            }
        }
    }
}
