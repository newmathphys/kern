package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.utils.DeferredQueueState

@Composable
fun MaliG51GpuVisualizer(
    isDeferredActive: Boolean,
    fps: Float,
    frameTimeMs: Float,
    busContention: Int,
    dvfsStatus: String,
    jankCounter: Int,
    queueState: DeferredQueueState,
    onToggleDeferred: (Boolean) -> Unit,
    onResetJank: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedBusWidth by animateFloatAsState(
        targetValue = busContention / 100f,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "busContentionWidth"
    )

    val contentionColor by animateColorAsState(
        targetValue = when {
            busContention > 50 -> TechRed
            busContention > 20 -> TechAmber
            else -> TechEmerald
        },
        label = "contentionColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("mali_gpu_visualizer_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VideogameAsset,
                        contentDescription = null,
                        tint = TechCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Mali-G51 MP4 • Deferred Render Queue",
                            style = MaterialTheme.typography.titleMedium,
                            color = TechCyan
                        )
                        Text(
                            text = "Unified Memory Bus Arbiter & Choreographer V-Sync Lock",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Mode Toggle Switch
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isDeferredActive) "V-Sync Queue" else "Direct",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDeferredActive) TechEmerald else TechRed,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = isDeferredActive,
                        onCheckedChange = onToggleDeferred,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TechEmerald,
                            checkedTrackColor = TechEmerald.copy(alpha = 0.3f),
                            uncheckedThumbColor = TechRed,
                            uncheckedTrackColor = TechRed.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.testTag("toggle_vsync_queue_switch")
                    )
                }
            }

            HorizontalDivider(color = DarkSurfaceVariant)

            // Live Performance Metrics (FPS, Frame Time, Contention, DVFS)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // FPS Meter
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "Display Rate", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = "$fps FPS",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (fps >= 58f) TechEmerald else TechRed
                        )
                        Text(
                            text = "${frameTimeMs} ms / frame",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                // Bus Contention Meter
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = "GPU Bus Load", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = "$busContention%",
                            style = MaterialTheme.typography.titleMedium,
                            color = contentionColor
                        )
                        Text(
                            text = if (busContention <= 10) "Zero Clash" else "High Bottleneck",
                            style = MaterialTheme.typography.bodySmall,
                            color = contentionColor,
                            fontSize = 10.sp
                        )
                    }
                }

                // Jank / Drops Meter
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Jank Drops", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                            if (jankCounter > 0) {
                                Text(
                                    text = "Reset",
                                    color = TechCyan,
                                    fontSize = 9.sp,
                                    modifier = Modifier.testTag("reset_jank_btn"),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                        Text(
                            text = "$jankCounter",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (jankCounter == 0) TechEmerald else TechAmber
                        )
                        Text(
                            text = if (jankCounter == 0) "Locked 60 FPS" else "Frames Skipped",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // GPU Bus Contention Progress Bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Mali-G51 Shared Memory Bus Contention", fontSize = 11.sp, color = TextSecondary)
                    Text(text = "$busContention% occupied", fontSize = 11.sp, color = contentionColor)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkSurfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedBusWidth)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(contentionColor)
                    )
                }
            }

            // Huawei DVFS Governor Status Banner
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isDeferredActive) TechEmerald.copy(alpha = 0.12f) else TechRed.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isDeferredActive) TechEmerald.copy(alpha = 0.4f) else TechRed.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (isDeferredActive) Icons.Default.Speed else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isDeferredActive) TechEmerald else TechRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Huawei DVFS Governor: $dvfsStatus",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isDeferredActive) TechEmerald else TechRed,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (isDeferredActive) {
                                "GPU inter-frame slot exploited. Memory bus clash avoided; Kirin CPU stays at 2.0 GHz."
                            } else {
                                "Direct render triggered GPU memory bus contention. DVFS dropped CPU clock to prevent overheating!"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // 3-Step Deferred Queue Pipeline Visualizer
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "3-Step Deferred Render Queue Protocol",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PipelineStepCard(
                        stepNumber = 1,
                        title = "Tick Decouple",
                        sub = "Halt immediate Compose invalidate",
                        isActive = queueState == DeferredQueueState.DECOUPLE_TICK,
                        isDone = queueState.step > 1,
                        modifier = Modifier.weight(1f)
                    )

                    PipelineStepCard(
                        stepNumber = 2,
                        title = "V-Sync Lock",
                        sub = "Choreographer 16.6ms blanking",
                        isActive = queueState == DeferredQueueState.AWAIT_VSYNC_SIGNAL,
                        isDone = queueState.step > 2,
                        modifier = Modifier.weight(1f)
                    )

                    PipelineStepCard(
                        stepNumber = 3,
                        title = "Soft Inject",
                        sub = "Mali-G51 idle slot write",
                        isActive = queueState == DeferredQueueState.GPU_SOFT_INJECTION,
                        isDone = queueState.step >= 3,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun PipelineStepCard(
    stepNumber: Int,
    title: String,
    sub: String,
    isActive: Boolean,
    isDone: Boolean,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        isActive -> TechCyan
        isDone -> TechEmerald
        else -> DarkSurfaceVariant
    }

    val bgColor = when {
        isActive -> TechCyan.copy(alpha = 0.15f)
        isDone -> TechEmerald.copy(alpha = 0.1f)
        else -> DarkSurface
    }

    Card(
        modifier = modifier.border(1.dp, borderColor, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (isDone) TechEmerald else if (isActive) TechCyan else TextMuted),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$stepNumber",
                        fontSize = 9.sp,
                        color = DarkBackground,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isActive) TechCyan else if (isDone) TechEmerald else TextPrimary,
                    fontSize = 10.sp
                )
            }
            Text(text = sub, style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 9.sp)
        }
    }
}
