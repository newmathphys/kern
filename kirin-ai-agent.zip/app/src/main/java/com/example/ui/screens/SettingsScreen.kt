package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.network.AiProvider
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.utils.DeepHardwareAnatomy
import com.example.utils.LocalizationManager

@Composable
fun SettingsScreen(
    currentApiKey: String,
    selectedModel: String,
    isHighThinking: Boolean,
    isAssistantActive: Boolean = true,
    aiProvider: AiProvider = AiProvider.GEMINI,
    customOpenAiBaseUrl: String = "http://192.168.1.100:11434/v1",
    customOpenAiApiKey: String = "",
    customOpenAiModel: String = "llama3:8b",
    deepHardwareAnatomy: DeepHardwareAnatomy? = null,
    onSaveApiKey: (String) -> Unit,
    onSelectModel: (String) -> Unit,
    onToggleThinking: (Boolean) -> Unit,
    onToggleAssistant: () -> Unit = {},
    onOpenFullScreen: () -> Unit = {},
    onSelectAiProvider: (AiProvider) -> Unit = {},
    onSaveCustomOpenAiSettings: (String, String, String) -> Unit = { _, _, _ -> },
    onPerformDeepAudit: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    var apiKeyInput by remember(currentApiKey) { mutableStateOf(currentApiKey) }
    var isKeyVisible by remember { mutableStateOf(false) }

    var baseUrlInput by remember(customOpenAiBaseUrl) { mutableStateOf(customOpenAiBaseUrl) }
    var customTokenInput by remember(customOpenAiApiKey) { mutableStateOf(customOpenAiApiKey) }
    var customModelInput by remember(customOpenAiModel) { mutableStateOf(customOpenAiModel) }
    var isTokenVisible by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Language Switcher Card (RU / EN)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("language_settings_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = TechCyan)
                    Text(
                        text = if (isRu) "Язык интерфейса / App Language" else "App Language / Язык интерфейса",
                        style = MaterialTheme.typography.titleMedium,
                        color = TechCyan,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { LocalizationManager.setLanguage(AppLanguage.RU) },
                        modifier = Modifier.weight(1f).testTag("select_lang_ru_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRu) TechCyan else DarkSurfaceVariant,
                            contentColor = if (isRu) DarkBackground else TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "🇷🇺 Русский (RU)",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isRu) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = { LocalizationManager.setLanguage(AppLanguage.EN) },
                        modifier = Modifier.weight(1f).testTag("select_lang_en_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isRu) TechCyan else DarkSurfaceVariant,
                            contentColor = if (!isRu) DarkBackground else TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "🇬🇧 English (EN)",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (!isRu) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // 2. AI ENGINE & ARCHITECTURE MODE (OFFLINE LOCAL / GEMINI / CUSTOM API)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("ai_provider_settings_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                when (aiProvider) {
                    AiProvider.OFFLINE_LOCAL -> TechEmerald.copy(alpha = 0.8f)
                    AiProvider.CUSTOM_OPENAI_COMPATIBLE -> TechPurple.copy(alpha = 0.8f)
                    AiProvider.GEMINI -> TechCyan.copy(alpha = 0.8f)
                }
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = when (aiProvider) {
                            AiProvider.OFFLINE_LOCAL -> Icons.Default.OfflineBolt
                            AiProvider.CUSTOM_OPENAI_COMPATIBLE -> Icons.Default.Hub
                            AiProvider.GEMINI -> Icons.Default.Cloud
                        },
                        contentDescription = null,
                        tint = when (aiProvider) {
                            AiProvider.OFFLINE_LOCAL -> TechEmerald
                            AiProvider.CUSTOM_OPENAI_COMPATIBLE -> TechPurple
                            AiProvider.GEMINI -> TechCyan
                        }
                    )
                    Column {
                        Text(
                            text = if (isRu) "Движок интеллекта и режим сети" else "AI Brain Engine & Network Mode",
                            style = MaterialTheme.typography.titleMedium,
                            color = when (aiProvider) {
                                AiProvider.OFFLINE_LOCAL -> TechEmerald
                                AiProvider.CUSTOM_OPENAI_COMPATIBLE -> TechPurple
                                AiProvider.GEMINI -> TechCyan
                            },
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isRu) "Работа без интернета, локальные модели или облачные API"
                            else "100% Offline execution, custom local models, or cloud APIs",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Option A: 100% Offline Local Engine
                EngineModeOption(
                    title = if (isRu) "📱 100% Автономный режим ядра (Без сети)" else "📱 100% Offline On-Device Kernel Engine",
                    subtitle = if (isRu)
                        "Работает без интернета! Мгновенная реакция (0 мс задержки), все функции телефона, ядро, фонарик, киоск, деблоатер, RAG и голос под прямым управлением."
                    else
                        "Zero network dependency! Instant execution, full hardware syscalls, flashlight, kiosk, debloater, RAG, and voice entirely on-device.",
                    isSelected = aiProvider == AiProvider.OFFLINE_LOCAL,
                    badgeColor = TechEmerald,
                    onSelect = { onSelectAiProvider(AiProvider.OFFLINE_LOCAL) }
                )

                // Option B: Google Gemini API
                EngineModeOption(
                    title = "🌐 Google Gemini API (ThinkingLevel.HIGH)",
                    subtitle = if (isRu)
                        "Официальные модели Gemini 3.1 Pro Preview, 3.5 Flash и 3.1 Flash-Lite с аппаратным Function Calling и автоматическим откатом в офлайн при сбоях сети."
                    else
                        "Gemini 3.1 Pro with High Thinking and Function Calling, with automatic offline fallback when network is unreachable.",
                    isSelected = aiProvider == AiProvider.GEMINI,
                    badgeColor = TechCyan,
                    onSelect = { onSelectAiProvider(AiProvider.GEMINI) }
                )

                // Option C: Custom OpenAI-Compatible / Local LLM (Ollama, vLLM, OpenRouter, DeepSeek)
                EngineModeOption(
                    title = if (isRu) "🔌 Пользовательский API / Локальная LLM (Ollama, OpenRouter, DeepSeek)"
                    else "🔌 Custom OpenAI-Compatible API / Local LLM (Ollama, vLLM, OpenRouter)",
                    subtitle = if (isRu)
                        "Подключение к любой локальной модели в домашней сети Wi-Fi (например, Ollama на ПК `http://192.168.x.x:11434/v1`) или сторонним API с токенами."
                    else
                        "Connect to local LAN LLM (Ollama on laptop/PC), OpenRouter, DeepSeek, or custom OpenAI endpoints with personal tokens.",
                    isSelected = aiProvider == AiProvider.CUSTOM_OPENAI_COMPATIBLE,
                    badgeColor = TechPurple,
                    onSelect = { onSelectAiProvider(AiProvider.CUSTOM_OPENAI_COMPATIBLE) }
                )
            }
        }

        // 3. CUSTOM API / LOCAL LLM CONFIGURATION (Shown when CUSTOM_OPENAI_COMPATIBLE is selected)
        if (aiProvider == AiProvider.CUSTOM_OPENAI_COMPATIBLE) {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("custom_api_config_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechPurple.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Dns, contentDescription = null, tint = TechPurple)
                        Text(
                            text = if (isRu) "Параметры пользовательского API / Ollama" else "Custom Endpoint & Token Configuration",
                            style = MaterialTheme.typography.titleMedium,
                            color = TechPurple,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (isRu)
                            "Укажите адрес сервера (например `http://192.168.1.100:11434/v1` для Ollama или `https://openrouter.ai/api/v1`), имя модели и токен доступа при необходимости."
                        else
                            "Specify the API Base URL (e.g. `http://192.168.1.100:11434/v1` for local Ollama or `https://openrouter.ai/api/v1`), model name, and Bearer token.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    OutlinedTextField(
                        value = baseUrlInput,
                        onValueChange = { baseUrlInput = it },
                        label = { Text("Base URL (e.g. http://192.168.x.x:11434/v1)") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_base_url_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = customFieldColors()
                    )

                    OutlinedTextField(
                        value = customModelInput,
                        onValueChange = { customModelInput = it },
                        label = { Text(if (isRu) "Имя модели (напр. llama3:8b, deepseek-chat)" else "Model Name (e.g. llama3:8b, deepseek-chat)") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_model_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = customFieldColors()
                    )

                    OutlinedTextField(
                        value = customTokenInput,
                        onValueChange = { customTokenInput = it },
                        label = { Text(if (isRu) "API Токен / Ключ (Bearer token, необязательно для Ollama)" else "API Token / Key (Optional for Ollama)") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_token_input"),
                        shape = RoundedCornerShape(10.dp),
                        visualTransformation = if (isTokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isTokenVisible = !isTokenVisible }) {
                                Icon(
                                    imageVector = if (isTokenVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = TextSecondary
                                )
                            }
                        },
                        singleLine = true,
                        colors = customFieldColors()
                    )

                    Button(
                        onClick = {
                            onSaveCustomOpenAiSettings(
                                baseUrlInput.trim(),
                                customTokenInput.trim(),
                                customModelInput.trim()
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_custom_api_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TechPurple, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isRu) "Сохранить и активировать API" else "Save & Activate Custom API", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 4. GOOGLE GEMINI API KEY & THINKING (Shown when GEMINI is selected)
        if (aiProvider == AiProvider.GEMINI) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = TechCyan)
                        Text(
                            text = if (isRu) "Ключ Google Gemini API" else "Google Gemini API Key & Account",
                            style = MaterialTheme.typography.titleMedium,
                            color = TechCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (isRu)
                            "По умолчанию используется ключ AI Studio. Вы можете ввести свой персональный API-ключ Gemini для использования личных квот."
                        else
                            "Uses the injected AI Studio key by default. You can specify a custom Google Gemini API key below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        placeholder = { Text("AIzaSy...", color = TextMuted) },
                        label = { Text(if (isRu) "API-ключ Gemini" else "Gemini API Key") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_api_key_input"),
                        shape = RoundedCornerShape(10.dp),
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                Icon(
                                    imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle visibility",
                                    tint = TextSecondary
                                )
                            }
                        },
                        colors = customFieldColors(),
                        singleLine = true
                    )

                    Button(
                        onClick = { onSaveApiKey(apiKeyInput.trim()) },
                        modifier = Modifier.fillMaxWidth().testTag("save_api_key_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TechCyan, contentColor = DarkBackground),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (isRu) "Сохранить и применить ключ" else "Save & Apply API Key", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    HorizontalDivider(color = DarkSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))

                    // Thinking Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isRu) "Включить глубокое мышление (Thinking)" else "Enable High Thinking (ThinkingLevel.HIGH)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = if (isRu) "Цепочка рассуждений Gemini 3.1 Pro для сложного системного анализа."
                                else "Internal chain-of-thought on gemini-3.1-pro-preview for deep architectural evaluation.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isHighThinking,
                            onCheckedChange = onToggleThinking,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TechCyan,
                                checkedTrackColor = TechCyan.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("thinking_mode_switch")
                        )
                    }

                    ModelOption(
                        title = "gemini-3.1-pro-preview",
                        subtitle = if (isRu) "Рекомендуется для глубокого анализа, кода, архитектуры и системных задач."
                        else "Recommended for complex system analysis, coding, math, and thinking mode.",
                        isSelected = selectedModel == "gemini-3.1-pro-preview",
                        onSelect = { onSelectModel("gemini-3.1-pro-preview") }
                    )

                    ModelOption(
                        title = "gemini-3.5-flash",
                        subtitle = if (isRu) "Высокая скорость, общий ассистент, быстрые голосовые ответы."
                        else "High speed, general assistant, summaries, quick command responses.",
                        isSelected = selectedModel == "gemini-3.5-flash",
                        onSelect = { onSelectModel("gemini-3.5-flash") }
                    )

                    ModelOption(
                        title = "gemini-3.1-flash-lite-preview",
                        subtitle = if (isRu) "Сверхнизкая задержка для быстрого разбора телеметрии."
                        else "Ultra low latency for fast telemetry stream parsing.",
                        isSelected = selectedModel == "gemini-3.1-flash-lite-preview",
                        onSelect = { onSelectModel("gemini-3.1-flash-lite-preview") }
                    )
                }
            }
        }

        // 5. DEEP SYSTEM & KERNEL ANATOMY CARD
        Card(
            modifier = Modifier.fillMaxWidth().testTag("deep_system_anatomy_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, TechEmerald.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = TechEmerald)
                        Column {
                            Text(
                                text = if (isRu) "Глубокая анатомия ядра и SoC" else "Deep Kernel & Hardware Anatomy",
                                style = MaterialTheme.typography.titleMedium,
                                color = TechEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isRu) "Kirin 710A • Linux 4.14 • Дисплей • Сенсоры" else "Kirin 710A • Linux 4.14 • Display • Sensors",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Button(
                        onClick = onPerformDeepAudit,
                        colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isRu) "Сканировать" else "Audit Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (deepHardwareAnatomy != null) {
                    val a = deepHardwareAnatomy
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurface, RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AnatomyRow(if (isRu) "SoC / Чипсет:" else "SoC Chipset:", a.socModel, TechCyan)
                        AnatomyRow(if (isRu) "Ядро Linux:" else "Linux Kernel:", a.kernelRelease.take(30), TextPrimary)
                        AnatomyRow(if (isRu) "Кластер A73 (Производительный):" else "A73 Performance:", "4 ядра @ 2.0-2.2 GHz", TechEmerald)
                        AnatomyRow(if (isRu) "Кластер A53 (Энергоэффективный):" else "A53 Efficiency:", "4 ядра @ 1.7 GHz", TextSecondary)
                        AnatomyRow(if (isRu) "Графика GPU / NPU:" else "GPU / NPU:", "${a.gpuModel.take(16)} / DaVinci NPU", TechPurple)
                        AnatomyRow(if (isRu) "ОЗУ / Flash-память:" else "RAM / Storage:", "${a.ramAvailMb}/${a.ramTotalMb} MB • %.1f GB своб.".format(a.internalStorageFreeGb), TextPrimary)
                        AnatomyRow(if (isRu) "Дисплей и частота:" else "Display & Refresh:", "${a.displayResolution} @ ${a.displayRefreshRate} Гц", TechCyan)
                        AnatomyRow(if (isRu) "Device Owner / Shizuku:" else "Device Owner / Shizuku:", "${if (a.isDeviceOwnerActive) "✅ Owner" else "⚠️ User"} • ${if (a.isShizukuActive) "✅ Shizuku" else "Ожидание"}", if (a.isDeviceOwnerActive) TechEmerald else TechRed)
                        AnatomyRow(if (isRu) "IMSI-Catcher угрозы:" else "IMSI Threats:", a.cellularThreatLevel, if (a.cellularThreatLevel == "SAFE") TechEmerald else TechRed)
                    }
                } else {
                    Text(
                        text = if (isRu)
                            "Нажмите «Сканировать», чтобы извлечь полную топологию ядер Kirin 710A, сенсоров, хранилища и сохранить дамп в локальную базу знаний RAG."
                        else
                            "Tap 'Audit Now' to extract full Kirin 710A core topology, sensors, storage, and save snapshot into local RAG knowledge base.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // 6. Always-On Cyber Eyes Assistant Mode Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("assistant_settings_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isAssistantActive) TechEmerald.copy(alpha = 0.6f) else Color(0xFF1E293B)
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = TechEmerald)
                        Column {
                            Text(
                                text = if (isRu) "Режим ассистента с глазами" else "Cyber Eyes Assistant Mode",
                                style = MaterialTheme.typography.titleMedium,
                                color = TechEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAssistantActive) (if (isRu) "АКТИВЕН (ПОСТОЯННО)" else "ACTIVE (ALWAYS-ON)")
                                else (if (isRu) "ВЫКЛЮЧЕН" else "STANDBY"),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = if (isAssistantActive) TechEmerald else TextMuted
                            )
                        }
                    }

                    Switch(
                        checked = isAssistantActive,
                        onCheckedChange = { onToggleAssistant() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TechEmerald,
                            checkedTrackColor = TechEmerald.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.testTag("settings_assistant_toggle_switch")
                    )
                }

                Text(
                    text = if (isRu)
                        "Работает непрерывно со всеми показателями (пульс PPG, температура SoC, V-Sync, TDOA звук, батарея, Zstd ОЗУ), пока не будет выключен вручную. Экран не гаснет благодаря блокировке сна (WakeLock)."
                    else
                        "Runs continuously with all live telemetry (PPG pulse, SoC thermal, V-Sync, TDOA sound, battery, Zstd RAM), until explicitly toggled off. Screen stays awake (WakeLock).",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Button(
                    onClick = onOpenFullScreen,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TechEmerald,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("settings_open_fullscreen_btn")
                ) {
                    Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRu) "Глаза на весь экран (OLED Черный HUD)" else "Open Fullscreen Cyber Eyes (OLED Black HUD)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun AnatomyRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = valueColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun EngineModeOption(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    badgeColor: Color,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isSelected) badgeColor else DarkSurfaceVariant,
                RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) badgeColor.copy(alpha = 0.08f) else DarkSurface,
        onClick = onSelect
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = badgeColor,
                    unselectedColor = TextSecondary
                )
            )
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isSelected) badgeColor else TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun ModelOption(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isSelected) TechCyan else DarkSurfaceVariant,
                RoundedCornerShape(10.dp)
            ),
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) TechCyan.copy(alpha = 0.1f) else DarkSurface,
        onClick = onSelect
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = TechCyan,
                    unselectedColor = TextSecondary
                )
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isSelected) TechCyan else TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun customFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = TechCyan,
    unfocusedBorderColor = DarkSurfaceVariant,
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary
)
