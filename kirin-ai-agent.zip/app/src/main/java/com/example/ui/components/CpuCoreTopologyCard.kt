package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CpuCoreInfo
import com.example.model.DeviceReport
import com.example.ui.theme.*
import com.example.utils.AppLanguage
import com.example.utils.LocalizationManager

@Composable
fun CpuCoreTopologyCard(
    report: DeviceReport,
    onOptimizeClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang by LocalizationManager.currentLanguage.collectAsState()
    val isRu = lang == AppLanguage.RU

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("cpu_topology_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "CPU Icon",
                        tint = TechCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = if (isRu) "Топология ядер Kirin 710A" else "Kirin 710A Core Topology",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isRu) "${report.cores.size} Ядер • Архитектура ARM big.LITTLE"
                            else "${report.cores.size} Cores • ARM big.LITTLE Architecture",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                if (report.affinityPinnedToBigCores) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = TechEmerald.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Pinned",
                                tint = TechEmerald,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "A73 Pinned",
                                style = MaterialTheme.typography.labelSmall,
                                color = TechEmerald
                            )
                        }
                    }
                }
            }

            // Cluster 0: Little Cores (0-3)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (isRu) "Кластер 0: 4x Cortex-A53 (Энергоэффективные @ 1.7 ГГц)"
                    else "Cluster 0: 4x Cortex-A53 (Energy Efficient @ 1.7 GHz)",
                    style = MaterialTheme.typography.labelMedium,
                    color = LittleCoreBlue
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    report.cores.take(4).forEach { core ->
                        CoreItem(core = core, isBig = false, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Cluster 1: Big Cores (4-7)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (isRu) "Кластер 1: 4x Cortex-A73 (Производительные @ 2.0 ГГц)"
                    else "Cluster 1: 4x Cortex-A73 (High Performance @ 2.0 GHz)",
                    style = MaterialTheme.typography.labelMedium,
                    color = BigCoreGold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    report.cores.drop(4).take(4).forEach { core ->
                        CoreItem(core = core, isBig = true, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Optimization Button
            Button(
                onClick = onOptimizeClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("optimize_kirin_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (report.affinityPinnedToBigCores) DarkSurfaceVariant else TechCyan,
                    contentColor = if (report.affinityPinnedToBigCores) TechCyan else DarkBackground
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRu) {
                        if (report.affinityPinnedToBigCores) "Перепривязать ядра A73 и mlockall" else "Привязать процесс к ядрам A73 (sched_setaffinity)"
                    } else {
                        if (report.affinityPinnedToBigCores) "Re-Engage Big-Core Affinity & mlockall" else "Engage Kirin A73 Big-Core Affinity (sched_setaffinity)"
                    },
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun CoreItem(
    core: CpuCoreInfo,
    isBig: Boolean,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        core.isPinned -> TechEmerald
        isBig -> BigCoreGold.copy(alpha = 0.6f)
        else -> LittleCoreBlue.copy(alpha = 0.5f)
    }

    val bg = if (core.isPinned) TechEmerald.copy(alpha = 0.08f) else DarkSurface

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = "CPU ${core.id}",
                style = MaterialTheme.typography.labelSmall,
                color = if (isBig) BigCoreGold else LittleCoreBlue
            )
            Text(
                text = "${core.curFreqMhz}",
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimary
            )
            Text(
                text = "MHz",
                fontSize = 9.sp,
                color = TextMuted
            )
        }
    }
}
