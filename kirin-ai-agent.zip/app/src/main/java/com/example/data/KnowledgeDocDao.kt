package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDocDao {
    @Query("SELECT * FROM knowledge_documents ORDER BY isPinned DESC, timestamp DESC")
    fun getAllDocs(): Flow<List<KnowledgeDocEntity>>

    @Query("SELECT * FROM knowledge_documents WHERE category = :category ORDER BY timestamp DESC")
    fun getDocsByCategory(category: String): Flow<List<KnowledgeDocEntity>>

    @Query("SELECT * FROM knowledge_documents WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchDocs(query: String): Flow<List<KnowledgeDocEntity>>

    @Query("SELECT * FROM knowledge_documents ORDER BY timestamp DESC")
    suspend fun getAllDocsList(): List<KnowledgeDocEntity>

    @Query("SELECT * FROM knowledge_documents WHERE id = :id")
    suspend fun getDocById(id: Long): KnowledgeDocEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoc(doc: KnowledgeDocEntity): Long

    @Update
    suspend fun updateDoc(doc: KnowledgeDocEntity)

    @Delete
    suspend fun deleteDoc(doc: KnowledgeDocEntity)

    @Query("DELETE FROM knowledge_documents WHERE id = :id")
    suspend fun deleteDocById(id: Long)

    @Query("DELETE FROM knowledge_documents")
    suspend fun clearAllDocs()

    @Query("SELECT COUNT(*) FROM knowledge_documents")
    fun getDocCount(): Flow<Int>
}
