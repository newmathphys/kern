package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge_documents")
data class KnowledgeDocEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String, // "TELEMETRY", "OCR_SCAN", "NOTIFICATION", "SYSTEM_LOG", "MANUAL", "ARCHITECTURE"
    val content: String,
    val summary: String,
    val tags: String, // comma-separated e.g. "hardware,kirin710a,battery"
    val wordCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val sourceApp: String? = null
)
