package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AuditLogEntity::class, SnapshotEntity::class, KnowledgeDocEntity::class], version = 3, exportSchema = false)
abstract class AgentDatabase : RoomDatabase() {
    abstract fun auditLogDao(): AuditLogDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun knowledgeDocDao(): KnowledgeDocDao

    companion object {
        @Volatile
        private var INSTANCE: AgentDatabase? = null

        fun getDatabase(context: Context): AgentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AgentDatabase::class.java,
                    "kirin_agent_database"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
