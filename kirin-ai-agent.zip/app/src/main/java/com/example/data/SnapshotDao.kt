package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SnapshotDao {
    @Query("SELECT * FROM context_snapshots ORDER BY timestamp DESC")
    fun getAllSnapshots(): Flow<List<SnapshotEntity>>

    @Query("SELECT * FROM context_snapshots ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentSnapshots(limit: Int): List<SnapshotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: SnapshotEntity): Long

    @Query("SELECT COUNT(*) FROM context_snapshots")
    fun getSnapshotCount(): Flow<Int>

    @Query("DELETE FROM context_snapshots")
    suspend fun clearAllSnapshots()

    @Query("SELECT contentHash FROM context_snapshots ORDER BY timestamp DESC LIMIT 5")
    suspend fun getRecentHashes(): List<String>
}
