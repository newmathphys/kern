package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String, // SYSTEM_SCAN, AI_ANALYSIS, ACTION_EXECUTION, HARDWARE_OPTIMIZATION
    val title: String,
    val content: String,
    val deviceModel: String,
    val isSuccess: Boolean = true
)
