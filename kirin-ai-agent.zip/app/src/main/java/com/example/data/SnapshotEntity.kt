package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "context_snapshots")
data class SnapshotEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceApp: String, // e.g. "org.telegram.messenger", "com.viber.voip", "system"
    val eventType: String, // "SCREEN_DUMP", "NOTIFICATION", "VOICE_INPUT", "TELEMETRY"
    val content: String,
    val contentHash: String,
    val isDeduplicated: Boolean = false,
    val cpuTemp: Int = 38,
    val ramFreeMb: Long = 1850,
    val batteryPct: Int = 85,
    val coreCluster: String = "A73_BIG"
)
