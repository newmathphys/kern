package com.example.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AdbTunnelStatus(val label: String, val isConnected: Boolean) {
    LISTENING_PORT_5037("ADB Port 5037 Tunnel Active", true),
    APP_INSPECTION_LINKED("Android Studio App Inspection Linked", true),
    OFFLINE_STANDALONE("Local Standalone Device Mode", false)
}

object DesktopSymbiosisManager {
    private val _adbStatus = MutableStateFlow(AdbTunnelStatus.LISTENING_PORT_5037)
    val adbStatus: StateFlow<AdbTunnelStatus> = _adbStatus.asStateFlow()

    private val _modelMatrixVersion = MutableStateFlow("v2.4-Kirin710A-Tuned")
    val modelMatrixVersion: StateFlow<String> = _modelMatrixVersion.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow(
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
    )
    val lastSyncTimestamp: StateFlow<String> = _lastSyncTimestamp.asStateFlow()

    private val _syncPacketCount = MutableStateFlow(142)
    val syncPacketCount: StateFlow<Int> = _syncPacketCount.asStateFlow()

    private val _isHotReloadReady = MutableStateFlow(true)
    val isHotReloadReady: StateFlow<Boolean> = _isHotReloadReady.asStateFlow()

    private val _telemetryStreamActive = MutableStateFlow(true)
    val telemetryStreamActive: StateFlow<Boolean> = _telemetryStreamActive.asStateFlow()

    /**
     * Simulates desktop synchronization with PC Global AI (Android Studio / App Inspection / ADB).
     */
    fun triggerDesktopSync(): String {
        _syncPacketCount.value += 18
        _lastSyncTimestamp.value = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        _modelMatrixVersion.value = "v2.5-Kirin710A-Enhanced"
        return "Daily archive (18 delta packets) exported via ADB Port 5037. Matrix weights synchronized."
    }

    fun toggleAdbTunnel() {
        _adbStatus.value = if (_adbStatus.value.isConnected) {
            AdbTunnelStatus.OFFLINE_STANDALONE
        } else {
            AdbTunnelStatus.APP_INSPECTION_LINKED
        }
    }
}
