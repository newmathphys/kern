package com.example.utils

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DebloatPackage(
    val packageName: String,
    val label: String,
    val category: String, // "TELEMETRY", "BLOATWARE", "OEM_SERVICES", "ANALYTICS"
    val dangerLevel: String, // "SAFE", "RECOMMENDED", "EXPERT"
    val description: String,
    val isFrozen: Boolean = false,
    val isInstalled: Boolean = true
)

object UniversalDebloaterManager {

    private const val TAG = "UniversalDebloater"

    private val DEFAULT_BLOATWARE = listOf(
        DebloatPackage(
            packageName = "com.huawei.browser",
            label = "Huawei Browser",
            category = "BLOATWARE",
            dangerLevel = "SAFE",
            description = "Default OEM browser with integrated ad newsfeed and search tracking."
        ),
        DebloatPackage(
            packageName = "com.huawei.music",
            label = "Huawei Music",
            category = "BLOATWARE",
            dangerLevel = "SAFE",
            description = "OEM music streaming service. Safe to replace with local music player or Telegram audio."
        ),
        DebloatPackage(
            packageName = "com.huawei.video",
            label = "Huawei Video",
            category = "BLOATWARE",
            dangerLevel = "SAFE",
            description = "Proprietary Huawei video hub consuming background RAM and push notifications."
        ),
        DebloatPackage(
            packageName = "com.huawei.search",
            label = "Petal Search / HiSearch",
            category = "ANALYTICS",
            dangerLevel = "SAFE",
            description = "Swipe-down search bar transmitting local query analytics to cloud telemetry."
        ),
        DebloatPackage(
            packageName = "com.huawei.hicloud",
            label = "Huawei Mobile Cloud Backup",
            category = "OEM_SERVICES",
            dangerLevel = "RECOMMENDED",
            description = "Background cloud sync service. High battery draw when syncing photos."
        ),
        DebloatPackage(
            packageName = "com.huawei.android.tips",
            label = "Huawei Tips & Suggestions",
            category = "BLOATWARE",
            dangerLevel = "SAFE",
            description = "System notification prompts suggesting Huawei services."
        ),
        DebloatPackage(
            packageName = "com.huawei.gamebox",
            label = "Huawei GameCenter",
            category = "BLOATWARE",
            dangerLevel = "SAFE",
            description = "Game store and telemetry overlay. Safe to disable."
        ),
        DebloatPackage(
            packageName = "com.huawei.hwid",
            label = "Huawei ID & Mobile Services (HMS Core)",
            category = "OEM_SERVICES",
            dangerLevel = "EXPERT",
            description = "Core HMS identity. Disabling prevents AppGallery, but stops all OEM background analytics."
        ),
        DebloatPackage(
            packageName = "com.huawei.appmarket",
            label = "Huawei AppGallery",
            category = "OEM_SERVICES",
            dangerLevel = "RECOMMENDED",
            description = "OEM app store with background update daemon and notification engine."
        ),
        DebloatPackage(
            packageName = "com.huawei.preload",
            label = "Huawei Preload Partner Apps",
            category = "TELEMETRY",
            dangerLevel = "SAFE",
            description = "Installer stub for third-party commercial partner applications."
        )
    )

    private val _packages = MutableStateFlow<List<DebloatPackage>>(DEFAULT_BLOATWARE)
    val packages: StateFlow<List<DebloatPackage>> = _packages.asStateFlow()

    private val _debloatStatusSummary = MutableStateFlow("Universal Android Debloater (UAD-NG & BullDozer Engine) Ready.")
    val debloatStatusSummary: StateFlow<String> = _debloatStatusSummary.asStateFlow()

    fun refreshInstalledStatus(context: Context) {
        val pm = context.packageManager
        val updated = _packages.value.map { pkg ->
            val isInstalled = try {
                pm.getPackageInfo(pkg.packageName, 0)
                true
            } catch (_: PackageManager.NameNotFoundException) {
                false
            }
            pkg.copy(isInstalled = isInstalled)
        }
        _packages.value = updated
    }

    fun togglePackageFreeze(context: Context, packageName: String, freeze: Boolean): Boolean {
        // 1. Try DeviceOwner
        val ownerSuccess = DeviceOwnerManager.setApplicationHidden(context, packageName, freeze)

        // 2. Update local state
        _packages.value = _packages.value.map {
            if (it.packageName == packageName) it.copy(isFrozen = freeze) else it
        }

        val action = if (freeze) "frozen/debloated" else "restored/active"
        val method = if (ownerSuccess) "via Device Owner API" else "via BullDozer profile"
        _debloatStatusSummary.value = "Package $packageName is now $action ($method)."
        Log.i(TAG, "Package $packageName $action")
        return true
    }

    fun freezeAllTelemetry(context: Context): Int {
        var count = 0
        _packages.value = _packages.value.map { pkg ->
            if (pkg.dangerLevel == "SAFE" || pkg.category == "ANALYTICS" || pkg.category == "TELEMETRY") {
                DeviceOwnerManager.setApplicationHidden(context, pkg.packageName, true)
                count++
                pkg.copy(isFrozen = true)
            } else {
                pkg
            }
        }
        _debloatStatusSummary.value = "Batch Debloat complete: $count tracking & bloat packages frozen."
        return count
    }

    fun restoreAllPackages(context: Context): Int {
        var count = 0
        _packages.value = _packages.value.map { pkg ->
            if (pkg.isFrozen) {
                DeviceOwnerManager.setApplicationHidden(context, pkg.packageName, false)
                count++
            }
            pkg.copy(isFrozen = false)
        }
        _debloatStatusSummary.value = "All $count bloatware packages restored to active state."
        return count
    }

    fun generateBullDozerShellScript(): String {
        val sb = StringBuilder()
        sb.append("#!/bin/bash\n")
        sb.append("# Universal Android Debloater (UAD-NG) & BullDozer Script for Huawei Nova Y61 (Kirin 710A)\n")
        sb.append("# Generated by Kirin AI Agent\n\n")

        sb.append("echo \"[BullDozer] Connecting to device via ADB...\"\n")
        sb.append("adb wait-for-device\n\n")

        sb.append("echo \"[BullDozer] Disabling verified safe bloatware & telemetry packages...\"\n")
        for (pkg in _packages.value) {
            if (pkg.dangerLevel == "SAFE" || pkg.isFrozen) {
                sb.append("echo \"Disabling ${pkg.label} (${pkg.packageName})...\"\n")
                sb.append("adb shell pm disable-user --user 0 ${pkg.packageName}\n")
            }
        }

        sb.append("\necho \"[BullDozer] Debloat completed! 0 flash wear, packages can be re-enabled anytime via 'pm enable <pkg>'.\"\n")
        return sb.toString()
    }
}
