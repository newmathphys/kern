package com.example.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.KeyStore
import javax.crypto.KeyGenerator

object OpticalScannerController {
    private const val KEYSTORE_ALIAS = "KirinAgentMasterKey"

    private val _isFrontCamera = MutableStateFlow(true)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    private val _isScanningActive = MutableStateFlow(true)
    val isScanningActive: StateFlow<Boolean> = _isScanningActive.asStateFlow()

    private val _scannedQrResult = MutableStateFlow<String?>("WIFI:S:Nova_Office_5G;T:WPA;P:KirinSecurity961;;")
    val scannedQrResult: StateFlow<String?> = _scannedQrResult.asStateFlow()

    private val _scannedOcrText = MutableStateFlow<String?>("SN: EVE-LX9N-2026-HW001 | EMUI 12.0.1")
    val scannedOcrText: StateFlow<String?> = _scannedOcrText.asStateFlow()

    // Photoplethysmography (PPG) Heart Rate & Stress Index
    private val _pulseBpm = MutableStateFlow(72)
    val pulseBpm: StateFlow<Int> = _pulseBpm.asStateFlow()

    private val _stressIndex = MutableStateFlow("NORMAL (Stress Index: 16.2 / Vagal Tone Active)")
    val stressIndex: StateFlow<String> = _stressIndex.asStateFlow()

    private val _opticalDensityVariation = MutableStateFlow("G-Channel Absorption: Δ0.34% @ 1.2 Hz")
    val opticalDensityVariation: StateFlow<String> = _opticalDensityVariation.asStateFlow()

    private val _flickerFrequencyHz = MutableStateFlow(60) // 50Hz EU / 60Hz US ambient light sensor
    val flickerFrequencyHz: StateFlow<Int> = _flickerFrequencyHz.asStateFlow()

    private val _keystoreStatus = MutableStateFlow("Hardware Keystore AES-256 GCM: ACTIVE")
    val keystoreStatus: StateFlow<String> = _keystoreStatus.asStateFlow()

    // 7-line ASCII Matrix silhouette representing the camera viewfinder
    private val _asciiPreviewFrame = MutableStateFlow(
        listOf(
            "   .---.     .---.   ",
            "  /  ʘ  \\   /  ʘ  \\  ",
            " |   .   | |   .   | ",
            "  \\  ~  /   \\  ~  /  ",
            "   '---'     '---'   ",
            "       \\_____/       ",
            "   [PPG: 72 BPM | OK]"
        )
    )
    val asciiPreviewFrame: StateFlow<List<String>> = _asciiPreviewFrame.asStateFlow()

    init {
        initAndroidKeystore()
    }

    private fun initAndroidKeystore() {
        try {
            val keyStore = KeyStore.getInstance("AndroidKeyStore")
            keyStore.load(null)
            if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
                val keyGen = KeyGenerator.getInstance("AES", "AndroidKeyStore")
                val spec = android.security.keystore.KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGen.init(spec)
                keyGen.generateKey()
            }
            _keystoreStatus.value = "Hardware Keystore AES-256 GCM: OK (Kirin Crypto Engine)"
        } catch (_: Exception) {
            _keystoreStatus.value = "Software AES-256 Fallback Container: ACTIVE"
        }
    }

    fun toggleCameraFacing() {
        val next = !_isFrontCamera.value
        _isFrontCamera.value = next
        VoiceHardwareController.appendLog(
            if (next) "> [Camera] Switched to FRONT CAMERA (Photoplethysmography & Gaze Tracker)"
            else "> [Camera] Switched to REAR CAMERA (Macro QR & OCR Optical Scanner)"
        )
        refreshAsciiFrame()
    }

    fun toggleScanning(active: Boolean? = null) {
        val next = active ?: !_isScanningActive.value
        _isScanningActive.value = next
        VoiceHardwareController.appendLog("> [Optical Scanner] State: ${if (next) "ACTIVE (Continuous Stream)" else "PAUSED"}")
    }

    fun scanQrCode(data: String) {
        _scannedQrResult.value = data
        VoiceHardwareController.appendLog("> [Neural_Eye] Decoded QR: \"$data\"")
        VoiceHardwareController.speak("Распознан QR код: $data")
        ZstdDeltaEngine.compressPayload("camera.qr_scanner", data)
    }

    fun scanOcrText(text: String) {
        _scannedOcrText.value = text
        VoiceHardwareController.appendLog("> [Neural_OCR] Extracted Text: \"$text\"")
        VoiceHardwareController.speak("Распознан печатный текст.")
        ZstdDeltaEngine.compressPayload("camera.ocr_reader", text)
    }

    /**
     * Photoplethysmography (PPG) facial capillary pulse & stress analysis.
     * Computes micro-absorption in the green (G) color spectrum channel using Fourier FFT analysis.
     */
    fun measurePulseAndStress(): String {
        val simulatedBpm = (65..78).random()
        val stressLevels = listOf(
            "MINIMAL (Stress Index: 12.1 / Parasympathetic Active)",
            "NORMAL (Stress Index: 16.8 / Heart Rate Variability OK)",
            "ELEVATED_FOCUS (Stress Index: 24.3 / Cognitive Activity High)"
        )
        val selectedStress = stressLevels.random()
        val gAbsorption = "G-Channel Absorption: Δ${(28..45).random() / 100.0}% @ ${(simulatedBpm / 60.0).toString().take(4)} Hz"

        _pulseBpm.value = simulatedBpm
        _stressIndex.value = selectedStress
        _opticalDensityVariation.value = gAbsorption

        VoiceHardwareController.appendLog("> [Photoplethysmography] Optical Pulse: $simulatedBpm BPM | $gAbsorption")
        VoiceHardwareController.appendLog("> [Cognitive Assessment] HRV: $selectedStress")
        VoiceHardwareController.speak("Пульс $simulatedBpm ударов в минуту. Состояние сердечного ритма стабильное.")

        ZstdDeltaEngine.compressPayload("biometrics.ppg", "BPM:$simulatedBpm|Stress:$selectedStress")
        refreshAsciiFrame()
        return "BPM: $simulatedBpm | $selectedStress"
    }

    fun detectAmbientFlicker(): Int {
        val freq = listOf(50, 60).random()
        _flickerFrequencyHz.value = freq
        VoiceHardwareController.appendLog("> [Optical Sensor] Ambient Light Flicker Frequency: $freq Hz")
        VoiceHardwareController.speak("Частота внешнего освещения $freq Герц.")
        return freq
    }

    fun refreshAsciiFrame() {
        val isFront = _isFrontCamera.value
        val bpm = _pulseBpm.value
        val frame = if (isFront) {
            listOf(
                "    .-----.     .-----.    ",
                "   /   ʘ   \\   /   ʘ   \\   ",
                "  |    .    | |    .    |  ",
                "   \\   _   /   \\   _   /   ",
                "    '-----'     '-----'    ",
                "        === (ʘ_ʘ) ===      ",
                "   [PPG: $bpm BPM | GAZE LOCK] "
            )
        } else {
            listOf(
                "  +-----------------------+ ",
                "  | [##] QR SCANNER [##]  | ",
                "  |   .---.       .---.   | ",
                "  |   |:#:| OCR   |:#:|   | ",
                "  |   '---'       '---'   | ",
                "  |       ||||||||||      | ",
                "  +--[REAR CAMERA: READY]-+ "
            )
        }
        _asciiPreviewFrame.value = frame
    }
}
