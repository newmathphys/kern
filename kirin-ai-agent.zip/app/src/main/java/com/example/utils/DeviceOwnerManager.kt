package com.example.utils

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.services.KirinDeviceAdminReceiver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object DeviceOwnerManager {

    private const val TAG = "DeviceOwnerManager"

    private val _isDeviceOwner = MutableStateFlow(false)
    val isDeviceOwner: StateFlow<Boolean> = _isDeviceOwner.asStateFlow()

    private val _isAdminActive = MutableStateFlow(false)
    val isAdminActive: StateFlow<Boolean> = _isAdminActive.asStateFlow()

    private val _isKioskMode = MutableStateFlow(false)
    val isKioskMode: StateFlow<Boolean> = _isKioskMode.asStateFlow()

    private val _systemShellLocked = MutableStateFlow(false)
    val systemShellLocked: StateFlow<Boolean> = _systemShellLocked.asStateFlow()

    fun getAdminComponent(context: Context): ComponentName {
        return ComponentName(context, KirinDeviceAdminReceiver::class.java)
    }

    fun refreshStatus(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return
        val admin = getAdminComponent(context)
        val adminActive = dpm.isAdminActive(admin)
        val ownerActive = dpm.isDeviceOwnerApp(context.packageName)

        _isAdminActive.value = adminActive
        _isDeviceOwner.value = ownerActive
        KirinDeviceAdminReceiver.updateStatus(adminActive, ownerActive)
    }

    fun getDeviceOwnerAdbCommand(context: Context): String {
        return "adb shell dpm set-device-owner ${context.packageName}/${KirinDeviceAdminReceiver::class.java.canonicalName}"
    }

    fun setKioskMode(activity: Activity, enable: Boolean): Boolean {
        return try {
            val dpm = activity.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            val admin = getAdminComponent(activity)

            if (enable) {
                if (dpm != null && dpm.isDeviceOwnerApp(activity.packageName)) {
                    dpm.setLockTaskPackages(admin, arrayOf(activity.packageName))
                }
                activity.startLockTask()
                _isKioskMode.value = true
                Log.i(TAG, "Kiosk LockTaskMode enabled")
            } else {
                activity.stopLockTask()
                _isKioskMode.value = false
                Log.i(TAG, "Kiosk LockTaskMode disabled")
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle kiosk mode: ${e.message}")
            _isKioskMode.value = false
            false
        }
    }

    fun lockSystemShell(context: Context, lock: Boolean): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
        val admin = getAdminComponent(context)
        if (!dpm.isAdminActive(admin)) return false

        return try {
            if (lock) {
                dpm.setKeyguardDisabledFeatures(
                    admin,
                    DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_ALL
                )
                _systemShellLocked.value = true
                Log.i(TAG, "System shell and lockscreen features restricted")
            } else {
                dpm.setKeyguardDisabledFeatures(
                    admin,
                    DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_NONE
                )
                _systemShellLocked.value = false
                Log.i(TAG, "System shell and lockscreen features restored")
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to lock/unlock system shell: ${e.message}")
            false
        }
    }

    fun setApplicationHidden(context: Context, packageName: String, hidden: Boolean): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager ?: return false
        val admin = getAdminComponent(context)
        if (!dpm.isDeviceOwnerApp(context.packageName)) {
            Log.w(TAG, "Device Owner required to setApplicationHidden")
            return false
        }
        return try {
            dpm.setApplicationHidden(admin, packageName, hidden)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to setApplicationHidden: ${e.message}")
            false
        }
    }
}
