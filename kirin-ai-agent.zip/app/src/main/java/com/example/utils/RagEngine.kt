package com.example.utils

import com.example.data.KnowledgeDocEntity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

data class RagSearchResult(
    val doc: KnowledgeDocEntity,
    val score: Float, // 0.0f .. 1.0f
    val scorePercent: Int, // 0 .. 100
    val matchedSnippet: String,
    val matchedKeywords: List<String>
)

object RagEngine {

    private val STOP_WORDS = setOf(
        "и", "в", "во", "не", "что", "он", "на", "я", "с", "со", "как", "а", "то", "все", "она", "так",
        "его", "но", "да", "ты", "к", "у", "же", "вы", "за", "бы", "по", "только", "ее", "мне", "было",
        "вот", "от", "меня", "еще", "нет", "о", "из", "ему", "теперь", "когда", "даже", "ну", "вдруг",
        "ли", "если", "уже", "или", "ни", "быть", "был", "него", "до", "вас", "нибудь", "опять",
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "with", "is", "are", "was",
        "were", "of", "it", "this", "that", "how", "what", "which", "where", "can"
    )

    fun tokenize(text: String): List<String> {
        return text.lowercase(Locale.ROOT)
            .split(Regex("[\\s.,;:!?()\\[\\]{}\"'/\\\\<>|~`#@*+=_-]+"))
            .filter { it.length > 1 && it !in STOP_WORDS }
    }

    fun search(query: String, docs: List<KnowledgeDocEntity>, topK: Int = 4): List<RagSearchResult> {
        if (docs.isEmpty()) return emptyList()
        val queryTokens = tokenize(query)
        if (queryTokens.isEmpty()) {
            return docs.take(topK).map {
                RagSearchResult(
                    doc = it,
                    score = 0.5f,
                    scorePercent = 50,
                    matchedSnippet = it.content.take(160) + if (it.content.length > 160) "..." else "",
                    matchedKeywords = emptyList()
                )
            }
        }

        val queryLower = query.lowercase(Locale.ROOT).trim()

        val results = docs.mapNotNull { doc ->
            var rawScore = 0f
            val matchedKeywords = mutableListOf<String>()

            val titleLower = doc.title.lowercase(Locale.ROOT)
            val contentLower = doc.content.lowercase(Locale.ROOT)
            val tagsLower = doc.tags.lowercase(Locale.ROOT)

            // 1. Exact phrase match
            if (contentLower.contains(queryLower) || titleLower.contains(queryLower)) {
                rawScore += 0.40f
                matchedKeywords.add(queryLower)
            }

            // 2. Token matches in title, tags, and content
            val docTokens = tokenize(doc.content).toSet()
            val titleTokens = tokenize(doc.title).toSet()
            val tagTokens = tokenize(doc.tags).toSet()

            for (token in queryTokens) {
                var found = false
                if (titleTokens.contains(token) || titleLower.contains(token)) {
                    rawScore += 0.25f
                    found = true
                }
                if (tagTokens.contains(token) || tagsLower.contains(token)) {
                    rawScore += 0.20f
                    found = true
                }
                if (docTokens.contains(token) || contentLower.contains(token)) {
                    rawScore += 0.15f
                    found = true
                }
                if (found) {
                    matchedKeywords.add(token)
                }
            }

            // 3. Recency boost (within 24 hours gets up to +0.05)
            val ageMs = System.currentTimeMillis() - doc.timestamp
            if (ageMs < 86_400_000L) {
                rawScore += 0.05f
            }

            // 4. Pin boost
            if (doc.isPinned) {
                rawScore += 0.10f
            }

            if (rawScore > 0f) {
                val clampedScore = min(rawScore, 1.0f)
                val snippet = extractSnippet(doc.content, queryTokens)
                RagSearchResult(
                    doc = doc,
                    score = clampedScore,
                    scorePercent = (clampedScore * 100).toInt(),
                    matchedSnippet = snippet,
                    matchedKeywords = matchedKeywords.distinct()
                )
            } else {
                null
            }
        }.sortedByDescending { it.score }

        return results.take(topK)
    }

    private fun extractSnippet(content: String, queryTokens: List<String>): String {
        if (content.length <= 180) return content
        val contentLower = content.lowercase(Locale.ROOT)

        var firstIndex = -1
        for (token in queryTokens) {
            val idx = contentLower.indexOf(token)
            if (idx != -1 && (firstIndex == -1 || idx < firstIndex)) {
                firstIndex = idx
            }
        }

        if (firstIndex == -1) {
            return content.take(180) + "..."
        }

        val start = (firstIndex - 50).coerceAtLeast(0)
        val end = (firstIndex + 130).coerceAtMost(content.length)
        val prefix = if (start > 0) "..." else ""
        val suffix = if (end < content.length) "..." else ""
        return prefix + content.substring(start, end).trim() + suffix
    }

    fun buildRagPromptContext(query: String, topResults: List<RagSearchResult>): String {
        if (topResults.isEmpty()) return ""

        val sb = StringBuilder()
        sb.append("\n\n=== [LOCAL RAG KNOWLEDGE BASE CONTEXT (Retrieved from Device Storage)] ===\n")
        sb.append("User Query: \"").append(query).append("\"\n")
        sb.append("Retrieved Knowledge Documents: ").append(topResults.size).append("\n\n")

        topResults.forEachIndexed { index, res ->
            val doc = res.doc
            val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(doc.timestamp))
            sb.append("--- [DOC #").append(index + 1).append("] ")
                .append(doc.title)
                .append(" (Category: ").append(doc.category)
                .append(", Match: ").append(res.scorePercent).append("%, Date: ").append(timeStr).append(") ---\n")
            sb.append(doc.content.trim())
            sb.append("\n\n")
        }

        sb.append("=== [END OF RAG CONTEXT - Use the above authoritative local knowledge base data to provide precise, accurate, hardware-grounded answers] ===\n")
        return sb.toString()
    }

    fun exportAllAsMarkdown(docs: List<KnowledgeDocEntity>): String {
        val sb = StringBuilder()
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        sb.append("# Kirin AI Agent - Full Knowledge Base Export\n")
        sb.append("Generated on: ").append(dateStr).append("\n")
        sb.append("Total Documents: ").append(docs.size).append("\n\n")

        docs.forEachIndexed { index, doc ->
            val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(doc.timestamp))
            sb.append("## ").append(index + 1).append(". ").append(doc.title).append("\n")
            sb.append("- **Category:** `").append(doc.category).append("`\n")
            sb.append("- **Tags:** `").append(doc.tags).append("`\n")
            sb.append("- **Timestamp:** ").append(timeStr).append("\n")
            if (!doc.sourceApp.isNullOrBlank()) {
                sb.append("- **Source App:** `").append(doc.sourceApp).append("`\n")
            }
            sb.append("- **Word Count:** ").append(doc.wordCount).append("\n\n")
            sb.append(doc.content).append("\n\n")
            sb.append("---\n\n")
        }
        return sb.toString()
    }

    fun exportAllAsJson(docs: List<KnowledgeDocEntity>): String {
        val root = JSONObject()
        root.put("exportTime", System.currentTimeMillis())
        root.put("totalDocuments", docs.size)

        val array = JSONArray()
        for (doc in docs) {
            val item = JSONObject()
            item.put("id", doc.id)
            item.put("title", doc.title)
            item.put("category", doc.category)
            item.put("summary", doc.summary)
            item.put("content", doc.content)
            item.put("tags", doc.tags)
            item.put("wordCount", doc.wordCount)
            item.put("timestamp", doc.timestamp)
            item.put("isPinned", doc.isPinned)
            item.put("sourceApp", doc.sourceApp ?: "")
            array.put(item)
        }
        root.put("documents", array)
        return root.toString(2)
    }

    fun getBaselineSeedDocuments(): List<KnowledgeDocEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            KnowledgeDocEntity(
                title = "Huawei Nova Y61 & Kirin 710A SoC Architecture Specification",
                category = "ARCHITECTURE",
                summary = "Full SoC hardware profile: 4x Cortex-A73 + 4x Cortex-A53, Mali-G51 MP4 GPU, 14nm FinFET.",
                content = """
                    # Huawei Nova Y61 & HiSilicon Kirin 710A Technical Specifications
                    - **SoC:** HiSilicon Kirin 710A (SMIC 14nm FinFET)
                    - **CPU Clusters:**
                      - Big Cores: 4x ARM Cortex-A73 @ 2.0 GHz (high-performance vector operations)
                      - LITTLE Cores: 4x ARM Cortex-A53 @ 1.7 GHz (low-power telemetry daemon)
                    - **GPU:** ARM Mali-G51 MP4 (Bifrost architecture, 1000 MHz, supports OpenGL ES 3.2 & Vulkan 1.1)
                    - **RAM & Memory Controller:** 4 GB LPDDR4X dual-channel 1866 MHz
                    - **Flash Storage:** 64 GB eMMC 5.1 (Zstd In-RAM delta compression avoids excessive writes)
                    - **Camera Sensor:** 50 MP f/1.8 Main + 2 MP Macro + 2 MP Depth + 5 MP Selfie
                    - **Battery:** 5000 mAh Li-Polymer with 22.5W Huawei SuperCharge
                    - **Operating System:** EMUI 12.0.0 (Treble VNDK compliant, system-as-root partition)
                """.trimIndent(),
                tags = "kirin710a,cpu,gpu,mali-g51,hardware,novay61,soc,specs",
                wordCount = 135,
                timestamp = now - 3600000,
                isPinned = true
            ),
            KnowledgeDocEntity(
                title = "Mali-G51 V-Sync Deferred Render Queue & Choreographer Sync Protocol",
                category = "ARCHITECTURE",
                summary = "Eliminating shared memory bus collisions between Kirin 710A CPU and Mali-G51 GPU in Telegram/Viber.",
                content = """
                    # Mali-G51 Deferred Render Queue Specification
                    - **Problem:** Mali-G51 shares DDR memory bus with CPU. Direct drawing of UI overlays during active messenger scrolling triggers memory bus saturation, leading to 25-40 ms frame drops.
                    - **Solution:** Choreographer frame-callback inter-frame synchronization.
                    - **Architecture:** 
                      1. Queue buffers upcoming overlay changes into in-memory FIFO.
                      2. Choreographer hooks into hardware V-Sync pulse (16.6ms intervals).
                      3. Frame commits occur strictly in the GPU idle phase between render passes.
                      4. Result: 60.0 FPS locked smooth rendering with zero jank.
                """.trimIndent(),
                tags = "mali-g51,gpu,vsync,choreographer,fps,telegram,rendering",
                wordCount = 98,
                timestamp = now - 3000000,
                isPinned = true
            ),
            KnowledgeDocEntity(
                title = "EMUI 12 Background Daemon Retention & Memory Lock (mlockall)",
                category = "SYSTEM_LOG",
                summary = "Preventing Huawei PowerGenie / iAware daemon killing through foreground service and process affinity.",
                content = """
                    # EMUI 12 PowerGenie Survival & Process Affinity Rules
                    - **Aggressive Killing Mechanism:** Huawei EMUI uses iAware and PowerGenie to terminate processes exceeding 150 MB RAM in background.
                    - **Defense Strategy:**
                      1. Foreground Service with `FOREGROUND_SERVICE_TYPE_DATA_SYNC` and persistent low-priority ongoing notification.
                      2. Process nice level adjusted to -16 (high priority).
                      3. Zstandard RAM page compaction to stay strictly below 85 MB resident set size (RSS).
                      4. Ignore battery optimization whitelist request (`ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`).
                """.trimIndent(),
                tags = "emui,powergenie,iaware,battery,mlockall,ram,retention",
                wordCount = 94,
                timestamp = now - 2000000,
                isPinned = false
            ),
            KnowledgeDocEntity(
                title = "Optical PPG Sensor & Acoustic Direction Finder (TDOA) Specifications",
                category = "TELEMETRY",
                summary = "Real camera-flash photoplethysmography and dual-microphone acoustic sound source localization.",
                content = """
                    # Optical PPG & Acoustic Telemetry Specifications
                    - **Optical Pulse & Stress Measurement:**
                      - Camera flash illuminates capillary bed at fingertip.
                      - Average pixel luminosity variation in red channel corresponds to arterial blood volume pulse.
                      - Peak-to-peak intervals (IBI) calculate real-time Pulse BPM (60-100 BPM) and Baevsky Stress Index.
                    - **Acoustic Sound Locator:**
                      - Evaluates Time-Difference-Of-Arrival (TDOA) and phase discrepancy between top noise-cancelling and bottom voice microphones.
                      - Calculates azimuth angle (0° to 360°) to track speaker direction in real-time.
                """.trimIndent(),
                tags = "ppg,pulse,stress,optical,camera,acoustic,tdoa,microphone",
                wordCount = 92,
                timestamp = now - 1000000,
                isPinned = false
            )
        )
    }
}
