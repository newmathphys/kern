package com.example.utils

enum class ProcessZone(val label: String, val description: String, val colorHex: Long) {
    HOT("Hot Zone (Immunity)", "Protected from EMUI LMK/PowerGenie. Pinned in RAM.", 0xFF00E5FF),
    WARM("Warm Zone (Suspended)", "UID Freezer / cgroups v2 suspended. Zero CPU drain.", 0xFFFFB703),
    COLD("Cold Zone (Pruned)", "Auto-terminated upon minimize to preserve Cortex-A73 RAM.", 0xFFEF4444)
}

data class ZonedProcess(
    val packageName: String,
    val appName: String,
    val zone: ProcessZone,
    val ramEstimateMb: Int,
    val priorityScore: Int // -20 to 19
)

object ProcessZoningManager {

    private val defaultZonedList = mutableListOf(
        ZonedProcess("org.telegram.messenger", "Telegram", ProcessZone.HOT, 220, -16),
        ZonedProcess("com.viber.voip", "Viber", ProcessZone.HOT, 180, -16),
        ZonedProcess("com.vkontakte.android", "VK", ProcessZone.HOT, 210, -10),
        ZonedProcess("com.android.dialer", "Phone & Contacts", ProcessZone.HOT, 90, -18),
        ZonedProcess("com.example.kirinagent", "Kirin AI Agent", ProcessZone.HOT, 110, -20),

        ZonedProcess("com.huawei.soundrecorder", "Huawei Dictaphone", ProcessZone.WARM, 85, 0),
        ZonedProcess("com.google.android.apps.transcribe", "Live Transcribe", ProcessZone.WARM, 95, 0),
        ZonedProcess("com.huawei.camera", "Camera Subsystem", ProcessZone.WARM, 140, -5),

        ZonedProcess("com.android.chrome", "Web Browser Tabs", ProcessZone.COLD, 380, 10),
        ZonedProcess("com.huawei.appmarket", "AppGallery Tracker", ProcessZone.COLD, 120, 15),
        ZonedProcess("com.huawei.gamebox", "Game Center Services", ProcessZone.COLD, 115, 12)
    )

    fun getZonedProcesses(): List<ZonedProcess> = defaultZonedList.toList()

    fun classifyPackage(packageName: String): ProcessZone {
        val found = defaultZonedList.firstOrNull { it.packageName == packageName }
        if (found != null) return found.zone

        return when {
            packageName.contains("telegram") || packageName.contains("viber") || packageName.contains("whatsapp") -> ProcessZone.HOT
            packageName.contains("recorder") || packageName.contains("audio") || packageName.contains("camera") -> ProcessZone.WARM
            else -> ProcessZone.COLD
        }
    }

    fun updateProcessZone(packageName: String, newZone: ProcessZone) {
        val index = defaultZonedList.indexOfFirst { it.packageName == packageName }
        if (index != -1) {
            val old = defaultZonedList[index]
            defaultZonedList[index] = old.copy(zone = newZone)
        }
    }
}
