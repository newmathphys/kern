package com.example.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AppLanguage(val code: String, val displayName: String) {
    RU("ru", "РУС"),
    EN("en", "ENG")
}

object LocalizationManager {
    private val _currentLanguage = MutableStateFlow(AppLanguage.RU)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
        VoiceHardwareController.updateLocale(lang)
        VoiceHardwareController.appendLog(
            if (lang == AppLanguage.RU) "> [Система] Язык интерфейса и голосового модуля: РУССКИЙ (RU)"
            else "> [System] Interface and voice module language: ENGLISH (EN)"
        )
    }

    fun toggleLanguage() {
        val next = if (_currentLanguage.value == AppLanguage.RU) AppLanguage.EN else AppLanguage.RU
        setLanguage(next)
    }

    fun getString(ru: String, en: String): String {
        return if (_currentLanguage.value == AppLanguage.RU) ru else en
    }
}
